#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Train the legacy VDMAF Word2Vec table on MegaVul-Java's train split.

This script deliberately uses the same case-sensitive regular-expression
tokenizer as ``Java/gnn/build_seq.py``.  It does *not* use the lower-cased NLTK
tokenizer found in the historical artifact, because the resulting rows must
line up with ``gnn/dataset/vocab_joint.json`` and its token-id sequences.

Outputs (under ``--output-dir``):

* ``word2vec.model``: the complete gensim model;
* ``embedding_matrix.npy``: float32 matrix indexed by ``vocab_joint.json``;
* ``embedding_metadata.json``: inputs, hyperparameters, and coverage figures.

Only the training parquet is read.  Validation/test functions never contribute
to Word2Vec fitting, which avoids representation leakage.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
from collections import Counter
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import numpy as np
import pandas as pd
from gensim import __version__ as gensim_version
from gensim.models import Word2Vec
from sklearn.utils import murmurhash3_32


HERE = Path(__file__).resolve().parent
JAVA_DIR = HERE.parent

DEFAULT_TRAIN_PARQUET = (
    JAVA_DIR / "megavul" / "train-00000-of-00001.parquet"
)
DEFAULT_VOCAB = JAVA_DIR / "gnn" / "dataset" / "vocab_joint.json"
DEFAULT_OUTPUT_DIR = HERE / "artifacts"

# Keep this expression byte-for-byte equivalent to TOKEN_RE in
# Java/gnn/build_seq.py.  Importing build_seq.py is intentionally avoided: that
# file executes the complete dataset build at import time.
TOKEN_PATTERN = (
    r'[A-Za-z_$][A-Za-z0-9_$]*'            # identifiers/keywords
    r'|\d+\.?\d*[fFdDlL]?'                 # numbers
    r'|"(?:\\.|[^"\\])*"'                  # string literals
    r"|'(?:\\.|[^'\\])*'"                  # char literals
    r'|==|!=|<=|>=|&&|\|\||\+\+|--|<<=|>>=|<<|>>>|>>'
    r'|\+=|-=|\*=|/=|%=|&=|\|=|\^=|->|::'
    r'|[{}()\[\];,.<>+\-*/%=!&|^~?:@]'
)
TOKEN_RE = re.compile(TOKEN_PATTERN)

PAD_TOKEN = "<pad>"
UNK_TOKEN = "<unk>"
PAD_INDEX = 0
UNK_INDEX = 1

# Gensim's historical default is Python's process-randomized ``hash``.  A
# stable, importable function is required for bit-for-bit repeatability and for
# saving/loading the model from a different Python entry point.  Passing the
# sklearn function directly (rather than a function defined under __main__)
# also keeps the serialized gensim model portable.
STABLE_HASH_NAME = "sklearn.utils.murmurhash3_32"
STABLE_HASH_SELF_TEST_TEXT = "vdmaf-reproducibility-check"
STABLE_HASH_SELF_TEST_VALUE = -764103323


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Train case-sensitive Java Word2Vec on MegaVul's train split and "
            "materialize an embedding matrix aligned to vocab_joint.json."
        )
    )
    parser.add_argument(
        "--train-parquet",
        type=Path,
        default=DEFAULT_TRAIN_PARQUET,
        help="MegaVul-Java training parquet (default: %(default)s)",
    )
    parser.add_argument(
        "--vocab",
        type=Path,
        default=DEFAULT_VOCAB,
        help="Joint token-to-id JSON (default: %(default)s)",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_OUTPUT_DIR,
        help="Directory for model, matrix, and metadata (default: %(default)s)",
    )
    parser.add_argument(
        "--text-column",
        default="input",
        help="Parquet column containing Java functions (default: %(default)s)",
    )
    parser.add_argument(
        "--vector-size",
        type=int,
        default=300,
        help="Word2Vec/embedding dimension (default: %(default)s)",
    )
    parser.add_argument(
        "--window",
        type=int,
        default=5,
        help="Word2Vec context window (default: %(default)s)",
    )
    parser.add_argument(
        "--min-count",
        type=int,
        default=5,
        help="Minimum training-corpus token count (default: %(default)s)",
    )
    parser.add_argument(
        "--epochs",
        type=int,
        default=100,
        help="Word2Vec epochs (default: %(default)s)",
    )
    parser.add_argument(
        "--sg",
        type=int,
        choices=(0, 1),
        default=0,
        help="0=CBOW (artifact default), 1=skip-gram (default: %(default)s)",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Word2Vec and deterministic UNK seed (default: %(default)s)",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=1,
        help=(
            "Training workers; keep 1 for reproducible ordering "
            "(default: %(default)s)"
        ),
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite existing output files.",
    )
    return parser.parse_args(argv)


def validate_args(args: argparse.Namespace) -> None:
    positive = {
        "--vector-size": args.vector_size,
        "--window": args.window,
        "--min-count": args.min_count,
        "--epochs": args.epochs,
        "--workers": args.workers,
    }
    for flag, value in positive.items():
        if value <= 0:
            raise ValueError(f"{flag} must be positive, got {value}")
    if not args.train_parquet.is_file():
        raise FileNotFoundError(f"training parquet not found: {args.train_parquet}")
    if not args.vocab.is_file():
        raise FileNotFoundError(f"joint vocabulary not found: {args.vocab}")
    observed_hash = murmurhash3_32(STABLE_HASH_SELF_TEST_TEXT)
    if observed_hash != STABLE_HASH_SELF_TEST_VALUE:
        raise RuntimeError(
            f"stable hash self-test failed: expected {STABLE_HASH_SELF_TEST_VALUE}, "
            f"got {observed_hash}"
        )


def tokenize_java(code: str) -> List[str]:
    """Tokenize Java exactly as the semantic channel's current dataset build."""
    return TOKEN_RE.findall(code)


def load_train_sentences(
    parquet_path: Path, text_column: str
) -> Tuple[List[List[str]], Counter[str], int]:
    """Load and tokenize only the train parquet, retaining reusable sentences."""
    frame = pd.read_parquet(parquet_path, columns=[text_column])
    sentences: List[List[str]] = []
    token_counts: Counter[str] = Counter()
    empty_functions = 0

    for row_number, value in enumerate(frame[text_column]):
        if value is None or (not isinstance(value, str) and pd.isna(value)):
            code = ""
        elif isinstance(value, str):
            code = value
        else:
            raise TypeError(
                f"row {row_number} in column {text_column!r} is "
                f"{type(value).__name__}, expected str"
            )
        tokens = tokenize_java(code)
        if not tokens:
            empty_functions += 1
        sentences.append(tokens)
        token_counts.update(tokens)

    if not token_counts:
        raise ValueError(
            f"no Java tokens found in {parquet_path} column {text_column!r}"
        )
    return sentences, token_counts, empty_functions


def load_joint_vocab(path: Path) -> Dict[str, int]:
    with path.open("r", encoding="utf-8") as handle:
        raw = json.load(handle)
    if not isinstance(raw, dict) or not raw:
        raise ValueError(f"vocabulary must be a non-empty JSON object: {path}")

    vocab: Dict[str, int] = {}
    for token, index in raw.items():
        if not isinstance(token, str):
            raise TypeError(f"vocabulary token is not a string: {token!r}")
        if isinstance(index, bool) or not isinstance(index, int):
            raise TypeError(f"vocabulary id for {token!r} is not an integer: {index!r}")
        vocab[token] = index

    ids = sorted(vocab.values())
    expected = list(range(len(vocab)))
    if ids != expected:
        raise ValueError(
            "vocab ids must be unique and contiguous from 0 to len(vocab)-1; "
            f"observed range {ids[0]}..{ids[-1]} for {len(ids)} entries"
        )
    if vocab.get(PAD_TOKEN) != PAD_INDEX:
        raise ValueError(
            f"expected {PAD_TOKEN!r} at id {PAD_INDEX}, got {vocab.get(PAD_TOKEN)!r}"
        )
    if vocab.get(UNK_TOKEN) != UNK_INDEX:
        raise ValueError(
            f"expected {UNK_TOKEN!r} at id {UNK_INDEX}, got {vocab.get(UNK_TOKEN)!r}"
        )
    return vocab


def deterministic_unk_vector(vector_size: int, seed: int) -> np.ndarray:
    """Use Word2Vec's initialization scale, but a dedicated deterministic RNG."""
    rng = np.random.default_rng(seed)
    return (
        (rng.random(vector_size, dtype=np.float32) - np.float32(0.5))
        / np.float32(vector_size)
    ).astype(np.float32, copy=False)


def build_embedding_matrix(
    vocab: Dict[str, int], model: Word2Vec, seed: int
) -> Tuple[np.ndarray, Dict[str, object]]:
    vector_size = model.wv.vector_size
    unk_vector = deterministic_unk_vector(vector_size, seed)
    matrix = np.repeat(unk_vector[None, :], len(vocab), axis=0)

    covered = 0
    oov_tokens: List[str] = []
    for token, index in vocab.items():
        if index in (PAD_INDEX, UNK_INDEX):
            continue
        if token in model.wv:
            matrix[index] = model.wv[token]
            covered += 1
        elif len(oov_tokens) < 50:
            oov_tokens.append(token)

    matrix[PAD_INDEX] = 0.0
    matrix[UNK_INDEX] = unk_vector
    eligible = max(len(vocab) - 2, 0)
    coverage = {
        "eligible_vocab_rows": eligible,
        "vocab_rows_covered": covered,
        "vocab_rows_oov": eligible - covered,
        "vocab_row_ratio": covered / eligible if eligible else 1.0,
        "oov_sample_first_50_by_vocab_order": oov_tokens,
    }
    return np.asarray(matrix, dtype=np.float32), coverage


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def refuse_accidental_overwrite(paths: Sequence[Path], force: bool) -> None:
    existing = [path for path in paths if path.exists()]
    if existing and not force:
        joined = "\n  ".join(str(path) for path in existing)
        raise FileExistsError(
            "output already exists; pass --force to replace it:\n  " + joined
        )


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv)
    validate_args(args)

    output_dir = args.output_dir.resolve()
    model_path = output_dir / "word2vec.model"
    matrix_path = output_dir / "embedding_matrix.npy"
    metadata_path = output_dir / "embedding_metadata.json"
    refuse_accidental_overwrite(
        (model_path, matrix_path, metadata_path), force=args.force
    )
    output_dir.mkdir(parents=True, exist_ok=True)

    if args.workers != 1:
        print(
            "WARNING: --workers > 1 makes gensim training order-dependent; "
            "use the default --workers 1 for reproducible results.",
            file=sys.stderr,
        )

    print(f"Loading train split only: {args.train_parquet.resolve()}")
    sentences, token_counts, empty_functions = load_train_sentences(
        args.train_parquet, args.text_column
    )
    total_tokens = sum(token_counts.values())
    print(
        f"Tokenized {len(sentences):,} functions, {total_tokens:,} tokens, "
        f"{len(token_counts):,} unique; empty functions: {empty_functions:,}"
    )

    vocab = load_joint_vocab(args.vocab)
    print(f"Joint vocabulary rows: {len(vocab):,}")

    model = Word2Vec(
        vector_size=args.vector_size,
        window=args.window,
        min_count=args.min_count,
        workers=args.workers,
        seed=args.seed,
        sg=args.sg,
        epochs=args.epochs,
        hashfxn=murmurhash3_32,
    )
    model.build_vocab(sentences)
    if not model.wv.key_to_index:
        raise ValueError(
            "Word2Vec vocabulary is empty; lower --min-count or inspect the corpus"
        )
    effective_words, raw_words = model.train(
        sentences,
        total_examples=model.corpus_count,
        epochs=args.epochs,
    )
    print(
        f"Trained {'CBOW' if args.sg == 0 else 'skip-gram'} Word2Vec: "
        f"{len(model.wv):,} tokens, {args.vector_size} dimensions"
    )

    matrix, coverage = build_embedding_matrix(vocab, model, args.seed)
    if matrix.shape != (len(vocab), args.vector_size):
        raise AssertionError(
            f"matrix shape {matrix.shape} != {(len(vocab), args.vector_size)}"
        )
    if matrix.dtype != np.float32:
        raise AssertionError(f"matrix dtype is {matrix.dtype}, expected float32")
    if np.any(matrix[PAD_INDEX] != 0.0):
        raise AssertionError("PAD row is not exactly zero")
    if not np.array_equal(
        matrix[UNK_INDEX], deterministic_unk_vector(args.vector_size, args.seed)
    ):
        raise AssertionError("UNK row is not the deterministic seeded vector")

    covered_train_tokens = sum(
        count for token, count in token_counts.items() if token in model.wv
    )
    coverage["train_tokens_total"] = total_tokens
    coverage["train_tokens_covered"] = covered_train_tokens
    coverage["train_token_ratio"] = covered_train_tokens / total_tokens

    # Force a single-file gensim artifact.  This avoids platform-dependent
    # sidecar .npy files and makes the output contract unambiguous.
    model.save(str(model_path), separately=[])
    np.save(matrix_path, matrix, allow_pickle=False)

    metadata = {
        "schema_version": 1,
        "leakage_policy": "train_split_only",
        "inputs": {
            "train_parquet": str(args.train_parquet.resolve()),
            "train_parquet_sha256": sha256_file(args.train_parquet),
            "text_column": args.text_column,
            "vocab_joint": str(args.vocab.resolve()),
            "vocab_joint_sha256": sha256_file(args.vocab),
        },
        "tokenizer": {
            "name": "vdmaf_java_regex",
            "source_equivalent": "Java/gnn/build_seq.py::TOKEN_RE",
            "pattern": TOKEN_PATTERN,
            "case_sensitive": True,
            "lowercase": False,
            "note": (
                "Aligned with current Java sequences; intentionally differs "
                "from the historical artifact's lower-cased NLTK tokenizer."
            ),
        },
        "corpus": {
            "split": "train",
            "functions": len(sentences),
            "empty_functions": empty_functions,
            "tokens": total_tokens,
            "unique_tokens": len(token_counts),
        },
        "word2vec": {
            "gensim_version": gensim_version,
            "architecture": "cbow" if args.sg == 0 else "skip_gram",
            "sg": args.sg,
            "vector_size": args.vector_size,
            "window": args.window,
            "min_count": args.min_count,
            "epochs": args.epochs,
            "seed": args.seed,
            "workers": args.workers,
            "hash_function": STABLE_HASH_NAME,
            "hash_self_test": {
                "text": STABLE_HASH_SELF_TEST_TEXT,
                "expected_signed_int32": STABLE_HASH_SELF_TEST_VALUE,
            },
            "negative": model.negative,
            "hs": model.hs,
            "sample": model.sample,
            "effective_words_reported_by_gensim": effective_words,
            "raw_words_reported_by_gensim": raw_words,
            "vocab_size": len(model.wv),
        },
        "matrix": {
            "file": matrix_path.name,
            "shape": list(matrix.shape),
            "dtype": str(matrix.dtype),
            "pad_token": PAD_TOKEN,
            "pad_index": PAD_INDEX,
            "pad_is_zero": True,
            "unk_token": UNK_TOKEN,
            "unk_index": UNK_INDEX,
            "unk_seed": args.seed,
            "unk_distribution": "uniform(-0.5/vector_size, 0.5/vector_size)",
            "oov_strategy": "copy_deterministic_unk_vector",
        },
        "coverage": coverage,
        "outputs": {
            "word2vec_model": model_path.name,
            "embedding_matrix": matrix_path.name,
            "metadata": metadata_path.name,
        },
    }
    with metadata_path.open("w", encoding="utf-8", newline="\n") as handle:
        json.dump(metadata, handle, indent=2, ensure_ascii=False)
        handle.write("\n")

    print(
        "Joint-vocab coverage: "
        f"{coverage['vocab_rows_covered']:,}/"
        f"{coverage['eligible_vocab_rows']:,} "
        f"({100.0 * coverage['vocab_row_ratio']:.2f}%)"
    )
    print(
        "Train-token coverage: "
        f"{coverage['train_tokens_covered']:,}/"
        f"{coverage['train_tokens_total']:,} "
        f"({100.0 * coverage['train_token_ratio']:.2f}%)"
    )
    print(f"Saved model:    {model_path}")
    print(f"Saved matrix:   {matrix_path} shape={matrix.shape} dtype={matrix.dtype}")
    print(f"Saved metadata: {metadata_path}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (FileNotFoundError, FileExistsError, KeyError, TypeError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(2)
