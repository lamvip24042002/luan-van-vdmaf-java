# -*- coding: utf-8 -*-
# Aggregate the before/after PCFinder-features experiment:
#  - overall test metrics mean±std per config (from metrics.json)
#  - paired per-seed diffs (on vs off)
#  - access-control CWE subset analysis (from test_probs.npz + labels_all.tsv):
#      AC positives = vul functions whose cwe list intersects AC_CWES;
#      subset PR-AUC computed on AC positives + ALL negatives,
#      recall@val_t on AC positives.
import glob
import json
import os

import numpy as np
from sklearn.metrics import average_precision_score

HERE = os.path.dirname(os.path.abspath(__file__))
LABELS = os.path.join(HERE, "..", "graph", "labels_all.tsv")
SEEDS = [42, 43, 44, 45, 46]
CONFIGS = ["pcf_both_off", "pcf_both_on", "pcf_gnn_off", "pcf_gnn_on"]
AC_CWES = {"CWE-264", "CWE-668", "CWE-862", "CWE-863", "CWE-285",
           "CWE-639", "CWE-284", "CWE-276", "CWE-269"}

fid_cwe = {}
with open(LABELS, encoding="utf-8") as f:
    next(f)
    for line in f:
        p = line.rstrip("\n").split("\t")
        fid_cwe[p[0]] = set(p[4].split(";")) if len(p) > 4 and p[4] else set()


def ac_subset_metrics(npz):
    fids, prob, y, val_t = npz["fids"], npz["prob"], npz["y"], float(npz["val_t"])
    is_ac = np.array([bool(fid_cwe.get(f, set()) & AC_CWES) for f in fids])
    pos_ac = (y == 1) & is_ac
    neg = y == 0
    # subset PR-AUC: AC positives vs all negatives
    mask = pos_ac | neg
    pr_auc_ac = float(average_precision_score(y[mask], prob[mask])) if pos_ac.sum() else float("nan")
    recall_ac = float((prob[pos_ac] > val_t).mean()) if pos_ac.sum() else float("nan")
    return {"n_ac_pos": int(pos_ac.sum()), "pr_auc_ac": pr_auc_ac,
            "recall_ac@val_t": recall_ac}


results = {c: {"pr_auc": [], "f1@val_t": [], "mcc@val_t": [],
               "pr_auc_ac": [], "recall_ac@val_t": [], "n_ac_pos": None}
           for c in CONFIGS}
for c in CONFIGS:
    for s in SEEDS:
        d = os.path.join(HERE, "runs", "%s_s%d" % (c, s))
        mp, pp = os.path.join(d, "metrics.json"), os.path.join(d, "test_probs.npz")
        if not (os.path.isfile(mp) and os.path.isfile(pp)):
            continue
        with open(mp, encoding="utf-8") as f:
            t = json.load(f)["test"]
        results[c]["pr_auc"].append(t["pr_auc"])
        results[c]["f1@val_t"].append(t["f1@val_t"])
        results[c]["mcc@val_t"].append(t["mcc@val_t"])
        ac = ac_subset_metrics(np.load(pp, allow_pickle=True))
        results[c]["pr_auc_ac"].append(ac["pr_auc_ac"])
        results[c]["recall_ac@val_t"].append(ac["recall_ac@val_t"])
        results[c]["n_ac_pos"] = ac["n_ac_pos"]


def ms(vals):
    a = np.array(vals)
    return "%.3f ± %.3f" % (a.mean(), a.std(ddof=1) if len(a) > 1 else 0.0)


METRICS = ["pr_auc", "f1@val_t", "mcc@val_t", "pr_auc_ac", "recall_ac@val_t"]
print("| Config | n | " + " | ".join(METRICS) + " |")
print("|---|---|" + "---|" * len(METRICS))
for c in CONFIGS:
    r = results[c]
    if not r["pr_auc"]:
        continue
    print("| %s | %d | %s |" % (c, len(r["pr_auc"]),
                                " | ".join(ms(r[m]) for m in METRICS)))
print("\nAC positives in test:", results[CONFIGS[0]]["n_ac_pos"])

print("\n=== paired per-seed diffs (on - off) ===")
for pair in [("pcf_both_on", "pcf_both_off"), ("pcf_gnn_on", "pcf_gnn_off")]:
    a, b = pair
    for m in METRICS:
        if not results[a][m] or len(results[a][m]) != len(results[b][m]):
            continue
        d = np.array(results[a][m]) - np.array(results[b][m])
        print("%s - %s | %-16s mean %+0.4f | per-seed %s | wins %d/%d"
              % (a, b, m, d.mean(), np.round(d, 3).tolist(),
                 int((d > 0).sum()), len(d)))

out = {c: {m: results[c][m] for m in METRICS} for c in CONFIGS}
out["n_ac_pos_test"] = results[CONFIGS[0]]["n_ac_pos"]
with open(os.path.join(HERE, "pcf_experiment_summary.json"), "w", encoding="utf-8") as f:
    json.dump(out, f, indent=2)
print("\nsaved -> pcf_experiment_summary.json")
