# -*- coding: utf-8 -*-
# Task 2: inspect node2vec_model-300.model to reverse-engineer its format
import random
from gensim.models import Word2Vec

n2v = Word2Vec.load("node2vec_model-300.model")
w2v = Word2Vec.load("Reveal_word2vec_5-100-300.model")

n2v_keys = list(n2v.wv.key_to_index.keys())
w2v_keys = set(w2v.wv.key_to_index.keys())

print("=== node2vec model ===")
print("vector_size:", n2v.wv.vector_size)
print("vocab size :", len(n2v_keys))
print("window     :", n2v.window)
print("sg         :", n2v.sg)
print("min_count  :", n2v.min_count)
print("epochs     :", n2v.epochs)

print("\n=== 60 sample keys (random) ===")
random.seed(0)
for k in random.sample(n2v_keys, 60):
    print(repr(k))

print("\n=== key length stats ===")
lens = [len(k) for k in n2v_keys]
print("min/max/mean len:", min(lens), max(lens), sum(lens) / len(lens))
multiword = sum(1 for k in n2v_keys if (" " in k or "\t" in k))
print("keys containing whitespace:", multiword)

print("\n=== overlap with w2v vocab ===")
print("w2v vocab size:", len(w2v_keys))
common = w2v_keys.intersection(n2v_keys)
print("common tokens :", len(common))
print("pct of w2v covered: %.1f%%" % (100.0 * len(common) / len(w2v_keys)))
