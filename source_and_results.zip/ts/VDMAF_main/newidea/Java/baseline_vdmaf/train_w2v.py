# -*- coding: utf-8 -*-
# Artifact-faithful word2vec for MegaVul Java: same preprocessing as the
# authors' train_w2vmodel.py (LOWERCASED corpus, nltk sent/word tokenize,
# CBOW vector_size=300 min_count=5 epochs=100). The lowercasing quirk is kept
# on purpose — it is part of the artifact being baselined.
import os.path
import pickle
import nltk
from gensim.models import Word2Vec

print("Loading corpus")
with open('corpus', 'r', encoding="utf-8") as file:
    data = file.read().lower().replace('\n', ' ')
print("chars:", len(data))

if os.path.isfile('corpus_processed'):
    with open('corpus_processed', 'rb') as fp:
        all_words = pickle.load(fp)
    print("loaded processed corpus.")
else:
    print("tokenizing...")
    all_sentences = nltk.sent_tokenize(data)
    all_words = [nltk.word_tokenize(sent) for sent in all_sentences]
    with open('corpus_processed', 'wb') as fp:
        pickle.dump(all_words, fp)
print("sentences:", len(all_words))

fname = "MegaVulJava_word2vec_5-100-300.model"
if os.path.isfile(fname):
    print("model already exists.")
else:
    print("training w2v (min_count=5, epochs=100, size=300)...")
    model = Word2Vec(all_words, vector_size=300, min_count=5, epochs=100,
                     workers=6)
    print("vocab:", len(model.wv.key_to_index))
    model.save(fname)
    print("saved ->", fname)
