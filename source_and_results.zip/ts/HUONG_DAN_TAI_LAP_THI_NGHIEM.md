# Hướng dẫn tái lập toàn bộ thí nghiệm trong luận văn

Tài liệu này hướng dẫn chạy lại từng thí nghiệm đã trình bày ở Chương 5 của luận văn, theo
đúng thứ tự phụ thuộc. Mọi đường dẫn/tên script bên dưới đều là file có thật trong dự án.

**Quy ước chung:**
- Thư mục gốc dự án (viết tắt `$ROOT`): `C:\Users\ADMIN\Desktop\ts\VDMAF_main\newidea`
- Joern cài tại: `C:\tools\joern-cli`
- Hai môi trường conda: `vdmaf` (TensorFlow, cho artifact) và `vdmaf-gnn` (PyTorch+PyG,
  cho mô hình đề xuất).
- Cách chạy 1 script Python trong một env, ví dụ:
  `conda run -n vdmaf-gnn python -u <script.py>` (cờ `-u` để log không bị đệm).
- Các job dài (train, sinh CPG) nên chạy **nền + có watchdog RAM** (xem Mục 0.3).

---

## 0. CHUẨN BỊ MÔI TRƯỜNG (làm 1 lần)

### 0.1. Hai môi trường conda

**Env `vdmaf`** (đã dựng từ trước — TF 2.10.1 + GPU + gensim/nltk). Nếu chưa có, tạo lại:
```
conda create -n vdmaf python=3.9 -y
conda activate vdmaf
pip install tensorflow==2.10.1 numpy==1.23.5 gensim==4.* nltk scikit-learn pandas
conda install -c conda-forge cudatoolkit=11.2 cudnn=8.1.0 -y
```
NLTK cần cả `punkt` và `punkt_tab` (nếu `nltk.download` lỗi SSL thì tải zip thủ công vào
`C:\Users\ADMIN\nltk_data\tokenizers\`).

**Env `vdmaf-gnn`** — chạy sẵn script tự động:
```
powershell -File $ROOT\Java\gnn\env_setup.ps1
```
Script này tạo env python 3.10, cài `torch 2.5.1+cu121`, `torch_geometric 2.8.0`,
pandas/pyarrow/sklearn/gensim/tqdm, rồi in dòng kiểm tra (`torch ... cuda True ... pyg ...`).
Bổ sung matplotlib cho phần vẽ hình (Mục 8):
```
conda run -n vdmaf-gnn pip install matplotlib
```

### 0.2. Kiểm tra GPU
```
conda run -n vdmaf-gnn python -c "import torch; print(torch.cuda.is_available())"
```
Phải in `True`. Driver NVIDIA cần hỗ trợ CUDA 12.x (bản dùng trong luận văn: 560.94).

### 0.3. Watchdog RAM (BẮT BUỘC cho mọi job dài — tránh treo máy 32GB)
Mỗi thí nghiệm dài đều có sẵn 1 file watchdog đi kèm (ví dụ `watchdog_train.ps1`,
`watchdog_acx.ps1`...). Luôn khởi động watchdog **song song** với job chính; nó ghi RAM mỗi
30 giây và tự `Stop-Process` python nếu RAM trống < 3GB. Mẫu khởi động nền (Windows):
```
Start-Process powershell -ArgumentList "-NoProfile","-ExecutionPolicy","Bypass","-File","<driver>.ps1" `
  -RedirectStandardOutput "<driver>.log" -RedirectStandardError "<driver>.err" -WindowStyle Hidden
Start-Process powershell -ArgumentList "-NoProfile","-ExecutionPolicy","Bypass","-File","<watchdog>.ps1" -WindowStyle Hidden
```

---

## 1. BASELINE — TÁI LẬP VDMAF TRÊN 3 TẬP GỐC (→ Bảng 5.1)

Mục tiêu: ra số Reveal F1 31,8 / Devign F1 51,8 / Bagheri 7 mode TB 95,9.

### 1.1. Reveal (C) — đã có sẵn dataset trong repo
Trong `$ROOT\Reveal\code\`:
1. Sinh corpus + train word2vec (nếu `Reveal_word2vec_5-100-300.model` chưa có):
   `conda run -n vdmaf python -u get_corpus.py` rồi `... train_w2vmodel.py`.
2. node2vec đã kèm sẵn (`node2vec_model-300.model`).
3. Đánh giá model đã train trên split đã lưu:
   `conda run -n vdmaf python -u evaluate.py`
   → xuất `baseline_metrics_reveal.json` (finaltest F1 ≈ 0,318).

### 1.2. Devign (C)
1. Tải dataset: chạy `Devign\dataset\download_dataset.py` (HuggingFace
   `google/code_x_glue_cc_defect_detection`) → file `function`.
2. Corpus + w2v: trong `Devign\code\`: `get_corpus.py` → `train_w2v_needed.py`.
3. Sinh node2vec qua Joern (Mục 1.4).
4. Train + chốt số (chạy nền + watchdog):
   driver `$ROOT\train_devign.ps1`, watchdog `$ROOT\ram_watchdog.ps1`.
   → `Devign\code\baseline_metrics_devign.json` (finaltest F1 ≈ 0,518).

### 1.3. Bagheri/VUDENC (Python, 7 mode)
1. Tải dataset VUDENC (Zenodo 3559841) → các file `plain_sql`, `plain_xss`, ... vào
   `Bagheri\dataset\`.
2. Chạy TỰ ĐỘNG cả 7 mode bằng driver:
   `$ROOT\run_bagheri_modes.ps1` (mode `sql` đã chạy riêng trước; driver này chạy 6 mode
   còn lại: xss, xsrf, command_injection, open_redirect, path_disclosure,
   remote_code_execution). Mỗi mode: get_corpus → train_w2v_needed → build_node2vec_tokens
   → makemodel. Watchdog: `$ROOT\ram_watchdog_batch.ps1`.
   → 7 file `Bagheri\train_model\baseline_metrics_bagheri_<mode>.json`.

> Lưu ý phát hiện quan trọng (viết trong luận văn): nguồn VUDENC bị làm phẳng xuống dòng nên
> KHÔNG parse được thành Python hợp lệ → không sinh được CPG thật; luận văn thay bằng đồ thị
> kề token (`Bagheri\graph\build_node2vec_tokens.py`).

### 1.4. Pipeline node2vec qua Joern (dùng chung cho Devign)
Trong `Devign\graph\`: `make_src_files.py` → `run_batches.ps1` (gọi `c2cpg` + script
`dump_graph.sc`) → `build_node2vec.py`. Lưu ý: dump PHẢI chạy trên CPG mới sinh; tham số
Joern trên Windows dùng cú pháp `--param """key=value"""`.

---

## 2. PIPELINE ĐỒ THỊ JAVA — MEGAVUL (→ Bảng 5.2)

### 2.1. Tải + khảo sát dataset
Trong `$ROOT\Java\megavul\`: tải 3 file parquet (train/validation/test) từ HuggingFace
`athrv/megavul-vulnerability-detection-java`, rồi:
```
conda run -n vdmaf-gnn python -u inspect_megavul.py
```
→ in schema, thống kê nhãn (41.949 hàm, 5,8% dương), phân bố CWE; xuất 200 file mẫu.

### 2.2. Sinh CPG/PDG toàn bộ 41.949 hàm
Trong `$ROOT\Java\graph\`:
1. Xuất hàm ra file .java theo batch: `conda run -n vdmaf-gnn python -u export_all.py`
   → thư mục `src_all\batch_00..20` + `labels_all.tsv`.
2. Sinh CPG + dump (chạy nền + watchdog):
   driver `run_batches_java.ps1`, watchdog `watchdog_java.ps1`.
   **Bản v2** (khuyến nghị — có cột `nodeKind` cần cho Mục 6): driver đã cấu hình xuất vào
   `dumps_v2\`. Toàn bộ 21 batch ~12 phút.
3. Kiểm tra độ phủ:
   `conda run -n vdmaf-gnn python -u coverage_stats.py`
   → phải ra 41.949/41.949 = 100%, 0 lỗi parse.

---

## 3. DỰNG TẬP HUẤN LUYỆN PYTORCH GEOMETRIC

Trong `$ROOT\Java\gnn\`:
```
conda run -n vdmaf-gnn python -u build_dataset_v2.py    # dump_v2 → dataset_v2/ (đồ thị + 4 cờ node)
conda run -n vdmaf-gnn python -u build_seq.py           # chuỗi token kênh ngữ nghĩa + vocab hợp nhất
```
(Nếu chỉ cần bản không có cờ PCFinder thì dùng `build_dataset.py` → `dataset/`.)
Kết quả: `dataset_v2/{train,validation,test}.pt`, `dataset/seq_*.pt`, `dataset/vocab*.json`.

---

## 4. MÔ HÌNH ĐỀ XUẤT + ABLATION (→ Bảng 5.3)

Script lõi: `train_v1.py` (tham số hóa đầy đủ). Chạy 4 cấu hình đơn seed để hiểu tham số:
```
cd $ROOT\Java\gnn
conda run -n vdmaf-gnn python -u train_v1.py --channels both --edges all     --out runs/v1_both
conda run -n vdmaf-gnn python -u train_v1.py --channels gnn  --edges all     --out runs/v1_gnn
conda run -n vdmaf-gnn python -u train_v1.py --channels seq  --edges all     --out runs/v1_seq
conda run -n vdmaf-gnn python -u train_v1.py --channels both --edges cdg_ddg --out runs/v1_both_cdgddg
```
Mỗi run xuất `runs/<tên>/metrics.json`. Để lấy **mean±std 5 seed** như Bảng 5.3, dùng
driver đa seed ở Mục 5.

**Ý nghĩa các cờ `train_v1.py`:**
- `--channels {both|gnn|seq}` — dùng cả 2 kênh / chỉ đồ thị / chỉ ngữ nghĩa.
- `--edges {all|cdg_ddg}` — 4 loại cạnh / chỉ CDG+DDG.
- `--pcf` — bật 4 đặc trưng node kiểu PCFinder (cần `--ds dataset_v2`).
- `--ac_only` — giới hạn bài toán về nhãn access-control.
- `--ds <thư mục>` — chọn tập dữ liệu (`dataset` / `dataset_v2` / `dataset_juliet_ac`).
- `--seed`, `--epochs`, `--patience`, `--out`.

---

## 5. SO SÁNH TRƯỚC/SAU + ĐA SEED (→ Bảng 5.4, kết quả chính +49% PR-AUC)

### 5.1. Chạy artifact VDMAF trên MegaVul Java (bên "trước")
Trong `$ROOT\Java\baseline_vdmaf\` (chạy nền + watchdog `watchdog_baseline.ps1`):
```
powershell -File $ROOT\Java\baseline_vdmaf\run_baseline.ps1
```
Driver này: `export_texts.py` (env gnn) → `train_w2v.py` (env vdmaf) → build_node2vec token
(dùng builder của Devign) → `makemodel_megavul.py` (env vdmaf). Mỗi seed xuất
`baseline_metrics_megavul_java_seed<seed>.json`.

### 5.2. Chạy đa seed cho CẢ artifact và 4 cấu hình đề xuất
```
powershell -File $ROOT\Java\run_multiseed.ps1        # seed 43-46 (42 chạy ở bước trên)
```
watchdog: `$ROOT\Java\watchdog_multiseed.ps1`.

### 5.3. Tổng hợp mean±std
```
conda run -n vdmaf-gnn python -u $ROOT\Java\aggregate_multiseed.py
```
→ `multiseed_summary.json` + bảng markdown in ra màn hình (đây chính là Bảng 5.3 và 5.4).

---

## 6. THÍ NGHIỆM PCFINDER 1 — BÀI TOÁN TỔNG QUÁT (→ Bảng 5.5)

Trong `$ROOT\Java\gnn\` (chạy nền + watchdog `watchdog_pcf.ps1`):
```
powershell -File $ROOT\Java\gnn\run_pcf_experiment.ps1     # 4 cấu hình × 5 seed, ±cờ
conda run -n vdmaf-gnn python -u analyze_pcf.py            # → pcf_experiment_summary.json
```
`analyze_pcf.py` in cả bảng toàn tập lẫn tập con access-control + paired diff.

---

## 7. THÍ NGHIỆM PCFINDER 2 — ACCESS-CONTROL + KIỂM ĐỊNH (→ Bảng 5.6, Hình 5.1)

### 7.1. Vòng 5 seed đầu (42–46)
```
powershell -File $ROOT\Java\gnn\run_ac_experiment.ps1     # ±cờ × fusion/gnn × 5 seed, --ac_only
```
watchdog: `watchdog_ac.ps1`.

### 7.2. Mở rộng thêm 10 seed (47–56) cho cặp GNN±cờ
```
powershell -File $ROOT\Java\gnn\run_ac_more_seeds.ps1
```
watchdog: `watchdog_acx.ps1`.

### 7.3. Tổng hợp 15 seed + sign-test/Wilcoxon
```
conda run -n vdmaf-gnn python -u analyze_ac.py            # → ac_experiment_summary.json
```
(Nếu thiếu `scipy`: `conda run -n vdmaf-gnn pip install scipy`.) In ra sign-test p=0,30,
Wilcoxon p=0,45 — đúng số ở Bảng 5.6.

---

## 8. THÍ NGHIỆM PCFINDER 3 — ĐỐI CHỨNG JULIET (→ Bảng 5.7, Phụ lục D)

### 8.1. Chuẩn bị dữ liệu Juliet access-control
1. Tải Juliet Java 1.3 (NIST SARD) giải nén vào `$ROOT\Java\juliet\`.
2. Gom 2 CWE access-control (566 + 601) ~600 file vào `$ROOT\Java\juliet_ac\src\`
   (bỏ file template `Main.java`/`ServletMain.java` vì không parse được).
3. Sinh CPG + dump v2 (dùng `dump_graph_java.sc`) → `juliet_ac\graph_juliet_ac.txt`.
4. Dựng dataset PyG: `conda run -n vdmaf-gnn python -u build_juliet_ac.py`
   → `dataset_juliet_ac/` (1.760 method, nhãn bad/good).

### 8.2. Chạy + tổng hợp
```
powershell -File $ROOT\Java\gnn\run_jac_experiment.ps1    # ±cờ × fusion/gnn × 5 seed
conda run -n vdmaf-gnn python -u analyze_jac.py           # → jac_experiment_summary.json
```
watchdog: `watchdog_jac.ps1`. Kết quả PR-AUC ~0,966 mọi cấu hình (hiệu ứng trần).

---

## 9. VẼ LẠI 3 HÌNH MINH HỌA

```
cd $ROOT\Java\gnn
conda run -n vdmaf-gnn python -u make_fig1_architecture.py     # → figures/fig1_...
conda run -n vdmaf-gnn python -u make_fig2_fusion_compare.py   # → figures/fig2_...
conda run -n vdmaf-gnn python -u make_fig3_boxplot.py          # → figures/fig3_... (đọc ac_experiment_summary.json)
```
Mỗi hình xuất cả `.png` (xem nhanh) và `.svg` (vector, nhúng LaTeX/Word). Hình 3 phải chạy
SAU Mục 7 vì nó đọc số liệu 15 seed từ `ac_experiment_summary.json`.

---

## 10. THỨ TỰ PHỤ THUỘC (tóm tắt)

```
0 (env)
├─ 1 baseline 3 tập gốc  ──────────────► Bảng 5.1   (độc lập, có thể làm song song)
└─ 2 CPG Java ─► 3 dataset PyG ─┬─► 4 ablation ──────────► Bảng 5.3
                                ├─► 5 trước/sau + đa seed ► Bảng 5.4  (cần cả env vdmaf ở 5.1)
                                ├─► 6 PCFinder tổng quát ─► Bảng 5.5
                                ├─► 7 PCFinder AC + 15seed► Bảng 5.6 ─► 9 Hình 5.1
                                └─► 8 Juliet (cần dữ liệu Juliet riêng) ► Bảng 5.7
```

## 11. THỜI GIAN THAM KHẢO (trên RTX 3060, 32GB RAM)
| Bước | Thời gian |
|---|---|
| Sinh CPG toàn bộ MegaVul (Mục 2.2) | ~12 phút |
| Dựng dataset PyG (Mục 3) | ~2 phút |
| 1 lần train `train_v1.py` (MegaVul) | ~4–7 phút |
| Đa seed trước/sau (Mục 5.2, 20 run) | ~66 phút |
| PCFinder tổng quát (Mục 6, 20 run) | ~62 phút |
| PCFinder AC 5 seed + mở rộng 10 seed | ~60 phút + ~35 phút |
| Juliet (Mục 8, 20 run) | ~6 phút (dữ liệu nhỏ) |
| Baseline Bagheri 6 mode (Mục 1.3) | ~3 giờ (dựng block chiếm phần lớn) |

## 12. XỬ LÝ SỰ CỐ THƯỜNG GẶP
- **Treo RAM khi chạy artifact:** đảm bảo dùng bản `makemodel` đã sửa (int32 index + frozen
  Embedding). Luôn bật watchdog.
- **`conda run` không thấy log:** thêm `python -u`; nếu vẫn buffer, chạy qua driver .ps1 với
  redirect (Mục 0.3) thay vì `conda run` trực tiếp.
- **Joern báo overlay/corrupt:** luôn dump trên CPG MỚI sinh, không tái dùng
  `joern-export`; dọn thư mục `workspace\` giữa các batch (driver đã làm sẵn).
- **Thiếu `scipy`/`matplotlib`:** `conda run -n vdmaf-gnn pip install scipy matplotlib`.
- **Số liệu lệch nhẹ giữa các lần chạy:** bình thường với nhãn 5,8% dương — luôn báo cáo
  mean±std nhiều seed, không dựa 1 lần chạy (đây chính là bài học phương pháp ở Mục 5.5.2).
