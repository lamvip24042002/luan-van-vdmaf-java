"""Audit all 45 recorded runs without loading PyTorch tensors or training models.

This recomputes metrics from saved validation/test predictions. It is not fresh
model inference; use evaluate.py for that. Historical absolute paths are retained
as provenance and are never used to locate files in this portable package.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path, PurePosixPath
import statistics
import sys

import numpy as np
from sklearn.metrics import (average_precision_score, f1_score,
                             matthews_corrcoef, precision_score,
                             recall_score, roc_auc_score)

ARMS = [
    ("all_full", "all", "both", "attention", "all"),
    ("train_full", "train", "both", "attention", "all"),
    ("train_seq", "train", "seq", "attention", "all"),
    ("train_gnn", "train", "gnn", "attention", "all"),
    ("train_concat", "train", "both", "concat", "all"),
    ("train_cdg_ddg", "train", "both", "attention", "cdg_ddg"),
    ("train_untyped", "train", "both", "attention", "untyped"),
    ("train_no_cdg", "train", "both", "attention", "no_cdg"),
    ("train_no_ddg", "train", "both", "attention", "no_ddg"),
]
SEEDS = list(range(42, 47))
METRICS = ("ap", "roc_auc", "f1@val_t", "p@val_t", "r@val_t", "mcc@val_t")
EXP = "output/seminar_20261011"
LABELS = "ts/VDMAF_main/newidea/Java/graph/labels_all.tsv"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def same(actual, expected, context):
    require(np.isfinite(actual) and np.isfinite(expected)
            and np.isclose(actual, expected, rtol=1e-8, atol=1e-10),
            f"{context}: {actual!r} differs from {expected!r}")


class Evidence:
    def __init__(self, root):
        self.root = Path(root).resolve()
        document = json.loads((self.root / "MANIFEST.json").read_text(encoding="utf-8"))
        rows = document if isinstance(document, list) else document["files"]
        self.entries = {}
        self.checked = {}
        for row in rows:
            name = row["path"]
            parts = PurePosixPath(name)
            require(not parts.is_absolute() and ".." not in parts.parts
                    and "\\" not in name and ":" not in name,
                    f"Unsafe manifest path: {name}")
            require(name not in self.entries, f"Duplicate manifest path: {name}")
            self.entries[name] = row

    def path(self, relative):
        relative = str(relative).replace("\\", "/")
        require(relative in self.entries, f"Evidence absent from MANIFEST.json: {relative}")
        path = (self.root / relative).resolve()
        require(path.is_relative_to(self.root), f"Evidence escapes package: {relative}")
        if relative not in self.checked:
            row = self.entries[relative]
            require(path.is_file(), f"Missing evidence: {relative}")
            require(path.stat().st_size == row["size"], f"Size mismatch: {relative}")
            digest = sha256(path)
            require(digest == row["sha256"], f"SHA-256 mismatch: {relative}")
            self.checked[relative] = digest
        return path

    def json(self, relative):
        return json.loads(self.path(relative).read_text(encoding="utf-8"))


def predictions(path):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    require(bool(rows), f"Empty predictions: {path}")
    required = {"fid", "y", "prob", "pred_0.5", "pred_val_t", "val_t"}
    require(required <= rows[0].keys(), f"Missing prediction columns: {path}")
    ids = [row["fid"] for row in rows]
    require(len(ids) == len(set(ids)), f"Duplicate sample IDs: {path}")
    labels = np.asarray([int(row["y"]) for row in rows], dtype=np.int64)
    # Match trainer float32 sigmoid output, including strict > threshold ties.
    probs = np.asarray([float(row["prob"]) for row in rows], dtype=np.float32)
    thresholds = np.asarray([float(row["val_t"]) for row in rows], dtype=np.float64)
    require(set(labels.tolist()) == {0, 1}, f"Invalid labels or missing class: {path}")
    require(np.isfinite(probs).all() and ((0 <= probs) & (probs <= 1)).all(),
            f"Invalid probabilities: {path}")
    require(np.isfinite(thresholds).all() and np.all(thresholds == thresholds[0]),
            f"Nonconstant or invalid validation threshold: {path}")
    threshold = float(thresholds[0])
    for key, value in (("pred_0.5", 0.5), ("pred_val_t", threshold)):
        require(np.array_equal(probs > value, [int(row[key]) for row in rows]),
                f"Saved classification inconsistent with probabilities: {path}/{key}")
    fingerprint = hashlib.sha256(json.dumps(list(zip(ids, labels.tolist())),
        ensure_ascii=False, separators=(",", ":")).encode("utf-8")).hexdigest()
    return ids, labels, probs, threshold, fingerprint


def threshold_from_validation(labels, probs):
    best_f1, threshold = 0.0, 0.5
    for candidate in np.linspace(0.05, 0.95, 19):
        score = float(f1_score(labels, probs > candidate, zero_division=0))
        if score > best_f1:
            best_f1, threshold = score, float(candidate)
    return threshold


def metrics(labels, probs, threshold):
    pred = probs > threshold
    return {
        "ap": float(average_precision_score(labels, probs)),
        "roc_auc": float(roc_auc_score(labels, probs)),
        "f1@val_t": float(f1_score(labels, pred, zero_division=0)),
        "p@val_t": float(precision_score(labels, pred, zero_division=0)),
        "r@val_t": float(recall_score(labels, pred, zero_division=0)),
        "mcc@val_t": float(matthews_corrcoef(labels, pred)),
        "f1@0.5": float(f1_score(labels, probs > 0.5, zero_division=0)),
        "p@0.5": float(precision_score(labels, probs > 0.5, zero_division=0)),
        "r@0.5": float(recall_score(labels, probs > 0.5, zero_division=0)),
        "mcc@0.5": float(matthews_corrcoef(labels, probs > 0.5)),
        "n": len(labels), "positive": int(labels.sum()), "val_t": threshold,
    }


def audit(root):
    evidence = Evidence(root)
    protocol = evidence.json(f"{EXP}/protocol.json")["specification"]
    require(protocol["arms"] == [list(arm) for arm in ARMS]
            and protocol["seeds"] == SEEDS and protocol["planned_runs"] == 45,
            "Protocol must be the prescribed 9 arms x 5 seeds")
    trainer = evidence.path("scripts/train_seminar_20261011.py")
    require(sha256(trainer) == protocol["trainer_sha256"], "Trainer differs from protocol")
    labels_path = evidence.path(LABELS)
    original = {}
    with labels_path.open(encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            require(row["fid"] not in original, "Duplicate ID in original labels")
            original[row["fid"]] = (row["split"], int(row["label"]))
    inputs = {}
    input_hashes = {}
    for scope in ("all", "train"):
        relative = f"{EXP}/inputs/{scope}/manifest.json"
        inputs[scope] = evidence.json(relative)
        require(evidence.checked[relative] == protocol["input_manifests"][scope],
                f"Original input manifest differs: {scope}")
        require(inputs[scope]["vocab_scope"] == scope and all(inputs[scope]["invariants"].values()),
                f"Input scope/invariants invalid: {scope}")
        source_hashes = {row["sha256"] for row in inputs[scope]["sources"]
                         if row["path"].replace("\\", "/").endswith("/" + LABELS)}
        require(source_hashes == {evidence.checked[LABELS]}, "Labels differ from input provenance")
        names = ["vocab_joint.json"] + [f"{prefix}{split}.pt"
                 for split in ("train", "validation", "test") for prefix in ("", "seq_")]
        input_hashes[scope] = {name: inputs[scope]["artifacts"][name]["sha256"] for name in names}
        # Validate vocabulary, but leave tensor loading/inference to evaluate.py.
        vocabulary = evidence.path(f"{EXP}/inputs/{scope}/vocab_joint.json")
        require(sha256(vocabulary) == input_hashes[scope]["vocab_joint.json"],
                f"Vocabulary differs: {scope}")
    records, references = [], {}
    train_inventory = None
    for arm, scope, channels, fusion, edges in ARMS:
        for seed in SEEDS:
            name = f"{arm}_s{seed}"
            directory = f"{EXP}/runs/{name}"
            spec = evidence.json(f"{directory}/run_spec.json")
            saved = evidence.json(f"{directory}/metrics.json")
            checkpoint = evidence.json(f"{directory}/best_checkpoint.json")
            require(spec["status"] == "completed", f"Incomplete run: {name}")
            expected = dict(seed=seed, channels=channels, fusion=fusion, edges=edges,
                            pcf=False, device="cuda")
            expected.update({k: v for k, v in protocol["hyperparameters"].items() if k != "weight_decay"})
            require(all(spec["config"].get(k) == v for k, v in expected.items()),
                    f"Run configuration differs from protocol: {name}")
            require(saved["config"] == spec["config"] and saved["splits"] == spec["splits"],
                    f"Metrics configuration differs: {name}")
            require(spec["script_sha256"] == protocol["trainer_sha256"]
                    and spec["input_sha256"] == input_hashes[scope]
                    and spec["data_manifests"]["manifest.json"]["sha256"] == protocol["input_manifests"][scope],
                    f"Run source/input provenance differs: {name}")
            require(spec["optimizer"] == {"name": "AdamW", "lr": protocol["hyperparameters"]["lr"],
                    "weight_decay": protocol["hyperparameters"]["weight_decay"]},
                    f"Optimizer differs: {name}")
            require(spec["warm_start"] is None and spec["selection"]["test_threshold_search"] is False,
                    f"Unexpected warm start or test threshold selection: {name}")
            require(saved["parameter_count"] == spec["parameter_count"]
                    and saved["epochs_completed"] == spec["epochs_completed"]
                    and 1 <= checkpoint["epoch"] == saved["best_epoch"] == spec["best_epoch"]
                    <= saved["epochs_completed"] <= protocol["hyperparameters"]["epochs"],
                    f"Invalid epochs/parameter count: {name}")
            require(checkpoint["vocab_sha256"] == saved["vocab_sha256"] == input_hashes[scope]["vocab_joint.json"],
                    f"Checkpoint vocabulary differs: {name}")
            if train_inventory is None:
                train_inventory = spec["splits"]["train"]
            require(spec["splits"]["train"] == train_inventory, f"Training IDs/labels differ: {name}")
            result = {"run": name, "arm": arm, "seed": seed}
            selected_threshold = None
            for split, key in (("validation", "val"), ("test", "test")):
                ids, labels, probs, threshold, fingerprint = predictions(
                    evidence.path(f"{directory}/{split}_predictions.csv"))
                require(fingerprint == spec["splits"][split]["ordered_fid_label_sha256"],
                        f"Sample fingerprint differs: {name}/{split}")
                require(all(original.get(fid) == (split, int(label)) for fid, label in zip(ids, labels)),
                        f"Samples differ from original labels: {name}/{split}")
                inventory = inputs[scope]["splits"][split]
                require(len(ids) == inventory["samples"] and int(labels.sum()) == inventory["positive"],
                        f"Incomplete split: {name}/{split}")
                if split not in references:
                    references[split] = (ids, labels)
                require(ids == references[split][0] and np.array_equal(labels, references[split][1]),
                        f"Samples differ across runs: {name}/{split}")
                recalculated = metrics(labels, probs, threshold)
                for metric, value in recalculated.items():
                    same(value, saved[key][metric], f"{name}/{split}/{metric}")
                same(recalculated["ap"], saved[key]["pr_auc"], f"{name}/{split}/AP alias")
                if split == "validation":
                    selected_threshold = threshold_from_validation(labels, probs)
                    same(threshold, selected_threshold, f"{name}/validation threshold")
                    same(threshold, checkpoint["val_t"], f"{name}/checkpoint threshold")
                    same(recalculated["ap"], checkpoint["validation_ap"], f"{name}/checkpoint AP")
                else:
                    same(threshold, selected_threshold, f"{name}/test threshold")
                result[key] = recalculated
            records.append(result)
    summary = {}
    for arm, *_ in ARMS:
        subset = [row for row in records if row["arm"] == arm]
        summary[arm] = {metric: {"mean": statistics.mean(row["test"][metric] for row in subset),
            "sample_sd": statistics.stdev(row["test"][metric] for row in subset)} for metric in METRICS}
    return {"status": "passed", "mode": "recorded_predictions_audit", "completed_runs": len(records),
            "scope": "Recomputed recorded validation/test predictions; no fresh model inference or retraining.",
            "primary_metric": "average precision (AP), not trapezoidal PR area",
            "sd_definition": "sample SD across five optimization seeds on one fixed split",
            "primary": summary, "runs": records, "verified_files": evidence.checked}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--out", type=Path, default=Path("evaluation/recorded_metrics.json"))
    args = parser.parse_args()
    root = args.root.resolve()
    out = args.out.resolve()
    evidence_roots = (root / "output", root / "ts", root / "scripts")
    require(not any(out.is_relative_to(path) for path in evidence_roots),
            "Output must be outside original evidence/source directories")
    require(not out.exists(), f"Output already exists; choose a new --out: {out}")
    report = audit(root)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(report, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")
    print(f"PASS: all {report['completed_runs']}/45 recorded runs; saved {out}")
    for arm, row in report["primary"].items():
        print(f"{arm:18} test AP = {row['ap']['mean']:.9f} +/- {row['ap']['sample_sd']:.9f}")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, KeyError, FileNotFoundError, json.JSONDecodeError) as error:
        print(f"AUDIT FAILED: {error}", file=sys.stderr)
        sys.exit(1)
