# -*- coding: utf-8 -*-
# Inspect MegaVul-Java parquet (HF: athrv/megavul-vulnerability-detection-java):
# schema, label balance, CWE distribution, function-length stats; then export a
# pilot sample of functions as .java files (wrapped in a dummy class) for the
# javasrc2cpg -> CDG/DDG pipeline test.
import os
import pandas as pd

d = os.path.dirname(os.path.abspath(__file__))
splits = {
    "train": "train-00000-of-00001.parquet",
    "validation": "validation-00000-of-00001.parquet",
    "test": "test-00000-of-00001.parquet",
}
dfs = {k: pd.read_parquet(os.path.join(d, v)) for k, v in splits.items()}

df = pd.concat(dfs.values(), ignore_index=True)
print("columns:", list(df.columns))
print("total rows:", len(df))
for k, v in dfs.items():
    n = len(v)
    nv = int(v["is_vulnerable"].sum())
    print("%-10s n=%6d  vul=%5d (%.2f%%)" % (k, n, nv, 100.0 * nv / n))

print("\n--- one vulnerable example (truncated) ---")
ex = df[df["is_vulnerable"] == True].iloc[0]
for c in ["cve_id", "cwe_ids", "severity", "cvss_score", "repo_name", "func_name", "file_path"]:
    print("%-12s %s" % (c, str(ex[c])[:100]))
print("instruction:", str(ex["instruction"])[:200].replace("\n", " | "))
print("input[:400]:", str(ex["input"])[:400].replace("\n", " | "))
print("output[:200]:", str(ex["output"])[:200].replace("\n", " | "))

print("\n--- top-10 CWE (vulnerable rows) ---")
vul = df[df["is_vulnerable"] == True]
print(vul["cwe_ids"].astype(str).value_counts().head(10).to_string())

code_col = "input"
lens = df[code_col].str.len()
print("\nfunc length (chars): min=%d p50=%d p90=%d max=%d" %
      (lens.min(), lens.quantile(0.5), lens.quantile(0.9), lens.max()))

# export pilot sample: 100 vul + 100 non-vul from train
outdir = os.path.join(d, "sample_src")
os.makedirs(outdir, exist_ok=True)
tr = dfs["train"]
sample = pd.concat([
    tr[tr["is_vulnerable"] == True].head(100),
    tr[tr["is_vulnerable"] == False].head(100),
]).reset_index(drop=True)
labels = []
for i, row in sample.iterrows():
    code = row[code_col]
    with open(os.path.join(outdir, "S%03d.java" % i), "w", encoding="utf-8") as f:
        f.write("public class S%03d {\n%s\n}\n" % (i, code))
    labels.append("S%03d\t%d\t%s" % (i, int(row["is_vulnerable"]), row["func_name"]))
with open(os.path.join(d, "sample_labels.tsv"), "w", encoding="utf-8") as f:
    f.write("\n".join(labels))
print("\nexported %d sample files -> %s" % (len(sample), outdir))
