"""Focused CPU smoke checks; no dataset training or GPU allocation.

Run: python scripts/test_train_seminar_20261011.py
"""
import ast
import csv
from pathlib import Path
import tempfile
import unittest

import numpy as np
import torch

import train_seminar_20261011 as trainer


def sample(fid, label, no_edges=False):
    item = {"fid": fid, "y": label, "x": torch.tensor([2, 3, 4]),
            "edge_index": torch.tensor([[0, 0, 1, 2], [1, 2, 2, 0]]),
            "edge_type": torch.tensor([0, 1, 2, 3])}
    if no_edges:
        item["edge_index"] = torch.empty((2, 0), dtype=torch.long)
        item["edge_type"] = torch.empty(0, dtype=torch.long)
    return item, torch.tensor([2, 3, 4, 5])


class SeminarTrainerTests(unittest.TestCase):
    def test_swapped_reserved_ids_fail_despite_contiguous_vocabulary(self):
        with self.assertRaisesRegex(ValueError, "reserve <pad>=0 and <unk>=1"):
            trainer.validate_vocabulary({"<pad>": 1, "<unk>": 0, "token": 2})

    def test_modified_input_cannot_reuse_a_stale_manifest(self):
        with tempfile.TemporaryDirectory(prefix="seminar-manifest-test-") as temporary:
            directory = Path(temporary)
            path = directory / "train.pt"
            path.write_bytes(b"original-input")
            manifest = {"artifacts": {"train.pt": {"sha256": trainer.sha256_file(path)}}}
            path.write_bytes(b"modified-input")
            actual_inputs = {"train.pt": trainer.sha256_file(path)}
            with self.assertRaisesRegex(ValueError, "SHA256 mismatch for train.pt"):
                trainer.verify_manifest_artifacts(directory, manifest, actual_inputs)

    def test_manifest_cannot_omit_a_consumed_input(self):
        with tempfile.TemporaryDirectory(prefix="seminar-manifest-test-") as temporary:
            with self.assertRaisesRegex(ValueError, "omits required input hashes"):
                trainer.verify_manifest_artifacts(Path(temporary), {"artifacts": {}},
                                                  {"test.pt": "unused-fixture-hash"})

    def test_attention_architecture_exactly_matches_original(self):
        # Extract just the class; importing the old script would train at import.
        path = (Path(__file__).resolve().parents[1] / "ts/VDMAF_main/newidea/Java"
                / "gnn/train_v1.py")
        original = ast.parse(path.read_text(encoding="utf-8"))
        class_node = next(node for node in original.body
                          if isinstance(node, ast.ClassDef) and node.name == "FusionModel")
        namespace = {"torch": torch, "nn": trainer.nn,
                     "RGCNConv": trainer.RGCNConv,
                     "global_mean_pool": trainer.global_mean_pool,
                     "to_dense_batch": trainer.to_dense_batch}
        exec(compile(ast.Module(body=[class_node], type_ignores=[]),
                     str(path), "exec"), namespace)
        graph, sequence, _ = trainer.collate([sample("a", 0), sample("b", 1)])
        for channel in ("both", "gnn", "seq"):
            with self.subTest(channel=channel):
                torch.manual_seed(42)
                old = namespace["FusionModel"](12, 8, channel, 4, 0.3).eval()
                torch.manual_seed(42)
                new = trainer.FusionModel(12, 8, channel, 4, 0.3).eval()
                self.assertEqual(list(old.state_dict()), list(new.state_dict()))
                for key, value in old.state_dict().items():
                    torch.testing.assert_close(value, new.state_dict()[key], rtol=0, atol=0)
                with torch.no_grad():
                    torch.testing.assert_close(old(graph, sequence), new(graph, sequence),
                                               rtol=0, atol=0)

    def test_edge_ablation_keeps_all_samples_and_remaps_relations(self):
        expected = {"all": [0, 1, 2, 3], "cdg_ddg": [0, 1],
                    "no_ast": [0, 1, 2], "no_cfg": [0, 1, 2],
                    "no_cdg": [0, 1, 2], "no_ddg": [0, 1, 2],
                    "untyped": [0, 0, 0, 0]}
        for mode, relations in expected.items():
            with self.subTest(mode=mode):
                graph, sequence, labels = trainer.collate(
                    [sample("a", 0), sample("b", 1, no_edges=True)], mode)
                self.assertEqual(graph.num_graphs, 2)
                self.assertEqual(graph.num_nodes, 6)
                self.assertEqual(graph.edge_type.tolist(), relations)
                self.assertEqual(labels.tolist(), [0, 1])
                self.assertEqual(sequence.shape[0], 2)
                old_sources = {"no_ast": [0, 1, 2], "no_cfg": [0, 1, 2],
                               "no_cdg": [0, 0, 2], "no_ddg": [0, 0, 1],
                               "cdg_ddg": [1, 2]}
                if mode in old_sources:
                    self.assertEqual(graph.edge_index[0].tolist(), old_sources[mode])

    def test_every_ablation_produces_finite_logits_with_edgeless_graph(self):
        for mode in trainer.EDGE_MODES:
            for fusion in ("attention", "concat"):
                with self.subTest(edges=mode, fusion=fusion):
                    graph, sequence, _ = trainer.collate(
                        [sample("a", 0), sample("b", 1, no_edges=True)], mode)
                    model = trainer.FusionModel(12, 8, "both", trainer.relation_count(mode),
                                                0.3, fusion=fusion).eval()
                    with torch.no_grad():
                        output = model(graph, sequence)
                    self.assertEqual(tuple(output.shape), (2,))
                    self.assertTrue(torch.isfinite(output).all())

    def test_missing_sequence_fails_instead_of_changing_sample_cohort(self):
        with tempfile.TemporaryDirectory(prefix="seminar-trainer-test-") as temporary:
            directory = Path(temporary)
            first, seq = sample("a", 0)
            second, _ = sample("b", 1)
            torch.save([first, second], directory / "train.pt")
            torch.save({"a": seq}, directory / "seq_train.pt")
            with self.assertRaisesRegex(ValueError, "sequence missing for b"):
                trainer.load_split(directory, "train", 12)

    def test_test_metrics_only_use_supplied_validation_threshold(self):
        val_y = np.array([0, 0, 1, 1])
        val_p = np.array([0.1, 0.2, 0.35, 0.4])
        threshold, value = trainer.select_validation_threshold(val_y, val_p)
        self.assertEqual(value, 1.0)
        test_y, test_p = np.array([0, 1, 0, 1]), np.array([0.7, 0.8, 0.85, 0.9])
        metrics = trainer.metrics_at_thresholds(test_y, test_p, threshold)
        self.assertAlmostEqual(metrics["f1@val_t"], 2 / 3)
        self.assertEqual(metrics["val_t"], threshold)
        self.assertFalse(any("best" in key for key in metrics))
        with tempfile.TemporaryDirectory(prefix="seminar-predictions-test-") as temporary:
            output = Path(temporary) / "test_predictions.csv"
            items = [sample(str(index), int(label)) for index, label in enumerate(test_y)]
            trainer.write_predictions(output, items, test_y, test_p, threshold)
            with output.open(encoding="utf-8", newline="") as handle:
                rows = list(csv.DictReader(handle))
            self.assertEqual([row["fid"] for row in rows], ["0", "1", "2", "3"])
            self.assertEqual([float(row["val_t"]) for row in rows], [threshold] * 4)

    def test_csv_predictions_match_array_comparison_at_float32_threshold(self):
        probability = np.array([0.4, 0.9], dtype=np.float32)
        labels = np.array([0, 1])
        items = [sample("a", 0), sample("b", 1)]
        with tempfile.TemporaryDirectory(prefix="seminar-prediction-boundary-") as temporary:
            path = Path(temporary) / "predictions.csv"
            for threshold in (0.4, 0.9):
                trainer.write_predictions(path, items, labels, probability, threshold)
                with path.open(encoding="utf-8", newline="") as handle:
                    rows = list(csv.DictReader(handle))
                self.assertEqual([int(row["pred_val_t"]) for row in rows],
                                 (probability > threshold).astype(int).tolist())


if __name__ == "__main__":
    torch.set_num_threads(1)
    unittest.main(verbosity=2)
