# Pilot pipeline Java: Joern javasrc2cpg → CDG/DDG

Ngày: 2026-07-04. Joern tại `C:\tools\joern-cli` (có sẵn `javasrc2cpg.bat`).

## 1. Sanity test (2 file tự viết, `Java/pilot/src/`)

- `UserDao.java`: findUser (CWE-89 SQL injection qua ghép chuỗi) + findUserSafe (PreparedStatement).
- `PathReader.java`: readFile (CWE-22 path traversal) + classify (nhiều rẽ nhánh/vòng lặp).
- `javasrc2cpg`: 7.8s (chủ yếu JVM startup). `dump_graph.sc` của Devign **dùng lại nguyên vẹn**
  (schema CPG chung): 7 method, 172 node, cạnh AST 222 / CFG 155 / **CDG 55** / **REACHING_DEF 372**.
- **Kiểm chứng taint-flow** (`taint_check.sc`): Joern lần ra đúng 2 luồng
  `username → "SELECT...'" + username + "'" → query → stmt.executeQuery` trong method lỗi.
  → DDG theo từng hàm có thật và đúng — khác hẳn bảng tra token của artifact VDMAF.

## 2. Scale test (Juliet Java 1.3, CWE89_SQL_Injection/s01)

| Chỉ số | Giá trị |
|---|---|
| File Java | 980 (978 parse OK; 2 file fail là template build, không phải code) |
| javasrc2cpg | 22.0s (~45 file/s) |
| joern import + ossdataflow + dump | 13.9s |
| Method trích được | 5,752 |
| Node (token-mapped) | 392,983 |
| Cạnh | REACHING_DEF 885,811 / AST 492,789 / CFG 388,948 / CDG 347,157 |

Ngoại suy: CWE89 đầy đủ (3,682 file) ≈ 2–3 phút; toàn bộ Juliet Java ≈ 20–30 phút;
dataset function-level thực tế (~10–50k hàm) hoàn toàn trong tầm với của RTX 3060 + 32GB RAM.
Juliet tải sẵn ở `Java/juliet/` (73MB zip, NIST SARD).

## 3. Đề xuất dataset Java chính

| Dataset | Bản chất | Vai trò đề xuất |
|---|---|---|
| **MegaVul (Java subset)** | CVE thực tế, function-level (giống Devign/Reveal) | **Dataset chính** — so sánh cross-language nhất quán với baseline C |
| **Juliet Java 1.3** (đã có) | Synthetic NIST, label method-level sạch (bad/good*) | Tập đối chứng có kiểm soát + ablation CDG/DDG (bad vs good khác nhau đúng ở luồng dữ liệu) |
| CVEfixes (Java) | CVE thực tế đa ngôn ngữ | Phương án thay thế/bổ sung cho MegaVul |
| Vul4J (79 CVE) | Nhỏ, tái lập được | Case study minh họa, không đủ train |

Lý do chọn MegaVul Java làm chính: (1) function-level khớp đơn vị mẫu của VDMAF;
(2) dữ liệu thật → kết quả thuyết phục hơn synthetic; (3) đủ lớn để train;
(4) giữ được tính so sánh với Devign/Reveal trong cùng bảng kết quả.

## 4. MegaVul Java — khảo sát + chạy thử (2026-07-04, phần bổ sung)

Nguồn: HF `athrv/megavul-vulnerability-detection-java` (parquet, 15.6MB) — bản dẫn xuất từ
MegaVul chính thức (Icyrockton/MegaVul, phân phối gốc qua OneDrive).

- **41,949 hàm** = 2,433 vul + 39,516 non-vul, chia sẵn train/val/test
  (31,461 / 4,195 / 6,293; tỷ lệ dương 5.84 / 5.44 / 5.86%) — mất cân bằng kiểu Reveal.
- Trường: `input` = mã hàm Java thô (giữ annotation), `is_vulnerable`, `cwe_ids`, `cve_id`,
  `severity`, `cvss_score`, `repo_name`, `func_name`, `file_path`, `commit_hash`
  (+ `instruction`/`output` kiểu instruction-tuning, bỏ qua).
- Top CWE: **79 (XSS), 611 (XXE), 89 (SQLi), 22 (path traversal), 502 (deserialization)** —
  đúng nhóm lỗi Java API-centric → củng cố thiết kế chuẩn hóa giữ tên API.
- Độ dài hàm: median 298 ký tự, p90 1,465 — hợp với cap 200 token của VDMAF.
- **Chạy thử pipeline**: 200 hàm (100 vul + 100 sạch) bọc class giả → javasrc2cpg 8.5s +
  dump 8.2s → **độ phủ 200/200 hàm đích**, cạnh REACHING_DEF 34,931 / CDG 7,770.
- Ước lượng full 41,949 hàm (batch như Devign): **~1.5–2 giờ, một lần duy nhất**.

Việc cần làm khi chạy thật: (1) thêm `m.filename` vào dump_graph.sc để join nhãn theo file;
(2) lọc method `<init>/<clinit>/lambda`; (3) cân nhắc tải bản gốc OneDrive
(`megavul_simple.json`) để trích dẫn chính thức trong luận văn; (4) kiểm tra trùng lặp hàm.

## 5. Chạy FULL MegaVul Java (2026-07-05, bước 1 của kênh cấu trúc mới)

Pipeline: `export_all.py` (41,949 hàm → 21 batch × 2,000 file bọc class) →
`run_batches_java.ps1` (javasrc2cpg → `dump_graph_java.sc` có cột filename, resumable,
watchdog RAM) → `coverage_stats.py`.

| Chỉ số | Giá trị |
|---|---|
| Thời gian toàn bộ | **11.5 phút** (08:37–08:48, ~30-36s/batch) |
| Độ phủ (has graph / name match) | **41,949/41,949 = 100.00%** ở cả train/val/test |
| Hàm lỗi có đồ thị | 2,433/2,433 (100%) |
| Lỗi parse | 0 |
| Method dump được (kể cả init/lambda) | 88,714 |
| Node (token-mapped) | 1,900,154 |
| Cạnh | REACHING_DEF 4,594,816 / AST 2,513,541 / CFG 1,749,438 / CDG 1,009,077 |
| Dung lượng dumps | 379 MB (`Java/graph/dumps/graph_batch_*.txt`) |

→ Khớp tuyên bố "100% graph success cho Java" của MegaVul, tái lập bằng pipeline tự xây.
Nguyên liệu cho GNN: node theo token + cạnh CDG/REACHING_DEF theo từng hàm + nhãn/split
trong `labels_all.tsv` (join qua filename `Fnnnnnn.java`).

## 6. Bước 2: env GNN + dataset PyG (2026-07-05)

- Env conda **`vdmaf-gnn`**: python 3.10, **torch 2.5.1+cu121 (CUDA OK trên driver 560.94),
  PyG 2.8.0**, + pandas/pyarrow/sklearn/gensim. Tách hoàn toàn khỏi env `vdmaf` (TF 2.10).
- **`Java/gnn/build_dataset.py`**: dump → `dataset/{train,validation,test}.pt` + `vocab.json`.
  Đơn vị = 1 hàm MegaVul (gộp mọi method của file trừ `<init>/<clinit>` → giữ lambda/anonymous
  class làm thành phần rời). Node = id token trong vocab (embedding tra trong model — pattern
  RAM-safe như baseline); cạnh có `edge_type`: AST=0, CFG=1, CDG=2, DDG(REACHING_DEF)=3.
- Kết quả: 41,934 đồ thị (15 rỗng bị loại, 1 bị cap 2000 node); vocab 29,667 (min_count 5,
  UNK 8.46% — chủ yếu literal hiếm; có thể giảm bằng bucket `<str>/<num>` nếu cần);
  node p50/p90/p99 = 21/104/296; cạnh: DDG 3.33M / CFG 1.50M / AST 1.32M / CDG 0.95M.
  Tỷ lệ nhãn giữ nguyên theo split (5.84/5.44/5.86% dương).
- **Smoke test PASS**: DataLoader batch 64 đồ thị → Embedding → RGCNConv(num_relations=4)
  → global_mean_pool → sigmoid, chạy trên CUDA.

## 7. Bước 3: kết quả v1 mô hình đề xuất (2026-07-05, 4 run × ~4-7 phút, seed 42)

Kiến trúc (`Java/gnn/train_v1.py`, ~5.2M tham số): embedding chung (vocab 35,909) →
kênh ngữ nghĩa BiLSTM(128) trên ≤200 token + kênh cấu trúc R-GCN 2 lớp phân biệt loại cạnh
→ **fusion cross-attention học end-to-end** (query=token, key/value=node PDG) → MLP.
BCEWithLogits pos_weight≈16.1, AdamW 1e-3, early stop theo val PR-AUC (patience 5),
ngưỡng quyết định tinh chỉnh trên validation.

Test MegaVul Java (6,293 hàm, 5.86% dương; mốc ngẫu nhiên PR-AUC = 0.059):

| Cấu hình | PR-AUC | ROC-AUC | F1@0.5 | F1@val_t | MCC@val_t |
|---|---|---|---|---|---|
| **v1_both** (đề xuất đầy đủ, 4 loại cạnh) | **0.512** | 0.882 | **0.491** | 0.490 | 0.460 |
| v1_gnn (chỉ cấu trúc) | 0.465 | 0.853 | 0.454 | 0.503 | 0.478 |
| v1_seq (chỉ ngữ nghĩa) | 0.463 | 0.873 | 0.488 | 0.486 | 0.455 |
| v1_both_cdgddg (fusion, chỉ CDG+DDG) | 0.487 | **0.885** | 0.446 | 0.486 | 0.453 |

Đọc kết quả:
1. **Fusion thắng cả hai kênh đơn về PR-AUC** (+4.7 điểm so với từng kênh riêng) — đúng luận
   điểm trung tâm của đề tài: ngữ nghĩa + cấu trúc bổ trợ nhau.
2. **Chỉ CDG+DDG đã gánh phần lớn tín hiệu cấu trúc** (0.487/0.512 ≈ 95% lợi ích fusion với
   chỉ 2/4 loại cạnh) — phụ thuộc điều khiển & dữ liệu là cốt lõi, AST/CFG bổ sung thêm ít.
3. F1 sau tinh chỉnh ngưỡng dao động giữa các run (0.486–0.503) — cần chạy đa seed để kết
   luận chi tiết; PR-AUC là thước đo ổn định hơn ở nhãn 5.9% dương.

Metrics + checkpoint trong `Java/gnn/runs/<tên_run>/`. Việc tiếp theo cho chương thí nghiệm:
(a) chạy 3-5 seed lấy mean±std; (b) chạy **baseline VDMAF-artifact trên chính MegaVul Java**
(w2v + node2vec lookup + fusion tĩnh + BiLSTM) để có số "trước/sau" trên cùng dataset;
(c) cải tiến: bucket literal `<str>/<num>`, GGNN/GAT thay R-GCN, khởi tạo embedding từ w2v.

## 8. Baseline VDMAF-artifact trên MegaVul Java — bảng "trước/sau" (2026-07-05)

Pipeline `Java/baseline_vdmaf/` (chạy 10:02–10:16, ~14 phút): tái tạo trung thực artifact —
corpus nối cả 3 split → w2v **lowercase**+nltk 5-100-300 (vocab 29,971) → node2vec token-keyed
từ chính CPG dumps (vocab 109,158; walks 2×20, sg=1/w10/mc5/300d/5ep) → giao từ vựng chỉ còn
**3,944 token** (quirk lowercase-vs-case-sensitive, giống Reveal 3,416) → MHA **không huấn
luyện** → reduce_sum → bảng tra tĩnh → BiLSTM 4 tầng (dropout 0.4, DWCE, class_weight, 50
epoch, batch 1024). Cùng split cố định với mô hình đề xuất; seed 42.

**So sánh trên test MegaVul Java (6,293 hàm, 5.86% dương):**

| Mô hình | PR-AUC | ROC-AUC | F1@0.5 | MCC@0.5 |
|---|---|---|---|---|
| VDMAF-artifact (baseline) | 0.318 | 0.705 | 0.412 | 0.374 |
| **Đề xuất v1 (fusion học được)** | **0.512** | **0.882** | **0.491** | **0.460** |
| Δ | **+0.194 (+61%)** | +0.177 | +0.079 | +0.086 |

Phân rã nguồn cải thiện (từ bảng ablation mục 7):
- Chỉ riêng kênh ngữ nghĩa học được (v1_seq, PR-AUC 0.463) đã vượt xa artifact (0.318) →
  embedding/loss/threshold được huấn luyện tử tế đóng góp phần lớn;
- Fusion cấu trúc học được thêm +4.9 điểm PR-AUC nữa (0.463 → 0.512), trong đó CDG/DDG là
  thành phần cốt lõi (mục 7).
- Quirk giao-từ-vựng của artifact (3,944/29,971 token dùng được ≈ 13%) tự nó vứt bỏ 87% từ
  vựng — minh họa định lượng cho khiếm khuyết thiết kế "hai bảng tra rời rạc".

File: `baseline_metrics_megavul_java.json`, model `model_megavul_java.h5`.

## 9. Kết quả đa seed (5 seeds 42–46, test MegaVul Java) — bảng chuẩn cho luận văn

Chạy 2026-07-05 (`run_multiseed.ps1`, 66 phút cho 20 run mới; `multiseed_summary.json`):

| Mô hình | PR-AUC | ROC-AUC | F1@0.5 | MCC@0.5 | F1@val_t |
|---|---|---|---|---|---|
| VDMAF-artifact | 0.338 ± 0.030 | 0.702 ± 0.048 | 0.413 ± 0.020 | 0.390 ± 0.018 | 0.414 ± 0.012 |
| **v1_both (đề xuất)** | **0.504 ± 0.016** | 0.878 ± 0.010 | 0.463 ± 0.026 | 0.440 ± 0.020 | 0.502 ± 0.012 |
| v1_gnn | 0.459 ± 0.012 | 0.861 ± 0.008 | 0.442 ± 0.046 | 0.416 ± 0.039 | 0.485 ± 0.012 |
| v1_seq | 0.486 ± 0.018 | 0.874 ± 0.005 | 0.492 ± 0.020 | 0.461 ± 0.019 | 0.501 ± 0.009 |
| v1_both_cdgddg | 0.499 ± 0.011 | **0.880 ± 0.006** | 0.443 ± 0.018 | 0.422 ± 0.011 | 0.505 ± 0.019 |

Phân tích theo cặp từng seed (paired, 5 seeds):

| So sánh | Δ PR-AUC | Thắng | Kết luận |
|---|---|---|---|
| v1_both vs artifact | **+0.166** | **5/5** (min +0.112) | Cải thiện chắc chắn, ~5–10σ; F1@val_t +8.8 điểm, 5/5 |
| v1_both vs v1_gnn | +0.045 | 5/5 | Fusion > cấu trúc đơn, nhất quán |
| v1_both vs v1_seq | +0.019 | 3/5 | Fusion > ngữ nghĩa đơn về trung bình nhưng CHƯA vững qua seed |
| v1_both vs v1_both_cdgddg | +0.005 | 3/5 | Không phân biệt được → CDG+DDG là đủ, AST/CFG không thêm gì |

**Diễn giải trung thực cho luận văn:**
1. Khoảng cách với artifact (+0.166 PR-AUC, thắng 5/5 seed) là kết quả chính, không thể bàn cãi.
2. Trong v1, phần lớn cải thiện đến từ việc các thành phần được HUẤN LUYỆN tử tế (v1_seq đơn
   thuần đã đạt 0.486); kênh cấu trúc thêm +1.9 điểm trung bình nhưng chưa vững qua seed →
   đây chính là dư địa cho v2 (GGNN/GAT, bucket literal, w2v-init, fusion sâu hơn) và cho
   thí nghiệm đối chứng Juliet (bad/good khác nhau đúng ở luồng dữ liệu).
3. CDG+DDG tương đương đủ 4 loại cạnh → ủng hộ trọng tâm "phụ thuộc điều khiển + dữ liệu"
   của đề tài; đồ thị có thể gọn hơn một nửa mà không mất chất lượng.

## 10. Thí nghiệm trước/sau đặc trưng PCFinder (2026-07-05, 20 run, 62 phút)

Thiết kế: khác biệt DUY NHẤT là 4 cờ node PCFinder-inspired (cùng vocab/seq/split/seed/
siêu tham số). Cờ: `is_credential_like` 4.29% node, `is_privileged_op` 0.24%,
`is_interruption` 2.40%, `flows_from_param` 51.73%. Hai cặp: fusion±cờ, GNN±cờ; đánh giá
2 tầng: toàn tập + riêng nhóm CWE access-control (**43 dương** trong test).

| Cấu hình | PR-AUC | F1@val_t | MCC@val_t | PR-AUC (AC) | Recall (AC) |
|---|---|---|---|---|---|
| fusion, KHÔNG cờ | 0.504 ± 0.016 | 0.506 ± 0.015 | 0.478 ± 0.014 | 0.069 ± 0.015 | 0.335 ± 0.045 |
| fusion, CÓ cờ | 0.502 ± 0.021 | 0.511 ± 0.021 | 0.485 ± 0.023 | 0.075 ± 0.018 | 0.349 ± 0.079 |
| GNN, KHÔNG cờ | 0.466 ± 0.018 | 0.489 ± 0.013 | 0.457 ± 0.014 | 0.067 ± 0.009 | 0.367 ± 0.019 |
| GNN, CÓ cờ | 0.461 ± 0.019 | 0.492 ± 0.009 | 0.462 ± 0.009 | 0.066 ± 0.007 | 0.335 ± 0.021 |

Paired per-seed (on − off): fusion PR-AUC toàn tập thắng 2/5 (mean −0.003) → **không phân
biệt được**. Tín hiệu dương nhất quán DUY NHẤT: fusion PR-AUC trên tập con AC thắng **4/5**
(mean +0.005) — đúng địa hạt PCFinder nhưng biên độ nhỏ, subset chỉ 43 dương.

**Kết luận trung thực (kết quả âm tính sạch, đáng viết):** cờ PCFinder KHÔNG tạo khác biệt
rõ trên bài toán phát hiện lỗ hổng tổng quát. Ba lý do: (1) access-control là thiểu số
(43/369 dương test) → pha loãng ở chỉ số toàn tập; (2) **GNN đã tự học được thứ cờ mã hóa
thủ công** — CDG/DDG vốn nằm trong đồ thị, thêm cờ là dư thừa (luận cứ "học biểu diễn thay
đặc trưng thủ công"); (3) cờ bị pha loãng kỹ thuật (4 chiều/128; flows_from_param 51.7% ≈
nhiễu, privileged_op 0.24% quá thưa). Muốn thấy khác biệt rõ phải chuyển bài toán về đúng
địa hạt access-control — xem mục 11. File: `pcf_experiment_summary.json`, `runs/pcf_*_s*/`.

## 11. Thí nghiệm trước/sau PCFinder trên bài toán ACCESS-CONTROL (2026-07-05, 20 run)

Reframe về đúng địa hạt PCFinder: dương = hàm lỗi thuộc CWE access-control (264/668/862/
863/285/639/284/276/269/306/732/601/522/425), âm = mã an toàn, loại bỏ lỗ hổng non-AC.
Quy mô: train 265 dương / 29.625 âm, val 39, **test 48 dương / 5.924 âm** (mốc ngẫu nhiên
PR-AUC = 0.008). Cùng khung ±cờ × fusion/GNN × 5 seeds.

| Cấu hình | PR-AUC | ROC-AUC | F1@val_t | MCC@val_t | Recall@val_t |
|---|---|---|---|---|---|
| fusion, KHÔNG cờ | 0.246 ± 0.053 | 0.842 | 0.301 ± 0.017 | 0.305 | 0.300 |
| fusion, CÓ cờ | 0.243 ± 0.066 | 0.844 | 0.299 ± 0.046 | 0.293 | 0.296 |
| GNN, KHÔNG cờ | 0.227 ± 0.030 | 0.838 | 0.289 ± 0.039 | 0.295 | 0.242 |
| **GNN, CÓ cờ** | 0.240 ± 0.019 | 0.836 | **0.314 ± 0.027** | 0.314 | 0.283 |

Paired per-seed (on − off):
- **Kênh GNN thuần: cờ giúp** — PR-AUC +0.013 (thắng 4/5), F1 +0.024 (4/5), Recall +0.042
  (3/5). Khi cấu trúc đứng một mình, đặc trưng PCFinder bổ sung tín hiệu thật.
- **Kênh fusion: cờ KHÔNG giúp** — PR-AUC −0.004 (thắng 1/5). Vì kênh ngữ nghĩa (BiLSTM
  trên token, đã giữ nguyên tên định danh) đã mang sẵn thông tin credential mà cờ mã hóa
  → cộng thêm là dư thừa.

**[CẬP NHẬT 15 SEEDS — kết luận 5-seed KHÔNG tái lập]** Vì xu hướng GNN+cờ (4/5 seed) chưa
đủ ý nghĩa thống kê, cặp GNN±cờ được chạy thêm 10 seed (47–56, `run_ac_more_seeds.ps1`).
Kết quả 15 seeds: PR-AUC diff mean **+0.0009**, thắng 9/15, **sign-test p=0.30, Wilcoxon
p=0.45** — chênh lệch từng seed dao động −0.071…+0.060 quanh 0 (nhiễu thuần). F1/MCC/recall
cũng không có ý nghĩa (một số hơi âm). GNN 15-seed: không cờ 0.233±0.036 vs có cờ
0.234±0.022.

**Kết luận cuối cùng (đã kiểm định):** đặc trưng thủ công kiểu PCFinder **không tạo cải
thiện có ý nghĩa thống kê** ngay cả trên bài toán access-control chuyên biệt với kênh GNN
thuần — xu hướng 4/5 của 5 seed đầu là may rủi mẫu nhỏ, đúng loại kết luận sai mà việc
tăng seed + sign test được thiết kế để chặn. Kết hợp cả 3 thí nghiệm: **học biểu diễn trên
CDG/DDG đã bao trùm tri thức chuyên gia mà PCFinder mã hóa thủ công** — một kết quả âm
tính nghiêm ngặt, phương pháp luận chặt (15 seeds, kiểm định phi tham số), rất đáng viết
thành mục "bài học" trong luận văn. File: `ac_experiment_summary.json`, `runs/ac_*_s*/`.

## 12. Tập đối chứng Juliet access-control (CWE-566+601) — kiểm tra bằng synthetic

Mục đích: tăng số mẫu dương để củng cố thống kê (test 88 dương vs 48 ở MegaVul AC). Juliet
Java chỉ có 2 CWE access-control: CWE-566 (auth bypass SQL primary key, 64 file) + CWE-601
(open redirect, 544 file — PCFinder xử lý redirect trực tiếp). 600 file → 1.760 method có
nhãn (bad=1/good=0), train 436 / val 86 / test 88 dương (~35%). Cùng khung ±cờ × fusion/GNN
× 5 seeds. Chạy 6 phút.

| Cấu hình | PR-AUC | ROC-AUC | F1@val_t | MCC@val_t |
|---|---|---|---|---|
| fusion, KHÔNG cờ | 0.964 ± 0.002 | 0.982 | 0.882 ± 0.008 | 0.822 |
| fusion, CÓ cờ | 0.964 ± 0.003 | 0.983 | 0.884 ± 0.006 | 0.827 |
| GNN, KHÔNG cờ | 0.966 ± 0.002 | 0.983 | 0.883 ± 0.006 | 0.824 |
| GNN, CÓ cờ | 0.967 ± 0.002 | 0.983 | 0.880 ± 0.009 | 0.820 |

Paired: mọi chênh lệch ±cờ đều **< 0.003** (GNN PR-AUC thắng 5/5 nhưng chỉ +0.001).

**Kết luận trung thực — hiệu ứng TRẦN (ceiling), một bài học phương pháp:** Juliet KHÔNG
làm khác biệt trước/sau hiện rõ hơn, vì mô hình gốc đã đạt PR-AUC 0.966 / ROC 0.983 — bài
toán synthetic quá dễ (bad/good theo khuôn mẫu cố định), **không còn dư địa** để đặc trưng
bổ sung thể hiện. Đây chính là lý do phổ biến khiến benchmark synthetic không phân biệt
được đóng góp của thành phần: nó bão hòa. Hệ quả: **bằng chứng "trước/sau" mạnh nhất vẫn là
thí nghiệm MegaVul-AC (mục 11, dữ liệu thật, GNN thuần thắng 4/5)** dù mẫu nhỏ; muốn củng
cố thống kê nên chạy thêm seed trên đó, KHÔNG nên dựa vào synthetic. File:
`jac_experiment_summary.json`, `runs/jac_*_s*/`.

## 12b. Tập AC MỞ RỘNG theo OWASP A01/A07 — tăng mẫu dương thật (2026-07-07)

Động cơ: tập AC chặt chỉ 48 dương test → sức mạnh thống kê yếu. Đã khảo sát nguồn ngoài
(CVEfixes HF, CWE-Bench-Java) nhưng đều KHÔNG dùng được ở mức hàm (CVEfixes mirror là hunk
diff — chỉ 2/24 hàng Java-AC có code hàm hoàn chỉnh; CWE-Bench-Java chỉ có 4 CWE injection).
Giải pháp: mở rộng định nghĩa AC trong MegaVul theo **OWASP Top-10 A01 (Broken Access
Control, gồm cả CSRF) + A07 (auth failures)** — thêm CWE-287/290/352/346/384/613/648 vào
tập chặt. Kết quả: **test dương 48 → 66 (+37%), train 265 → 361.** Dữ liệu MegaVul thật,
CPG đã có sẵn. Chạy 4 cấu hình × 10 seed (42–51), có thêm 10 seed mở rộng (52–61) cho cặp
GNN đang chạy.

| Cấu hình (10 seed) | PR-AUC | F1@val_t | MCC@val_t |
|---|---|---|---|
| fusion, KHÔNG cờ | 0.295 ± 0.070 | 0.330 ± 0.066 | 0.328 |
| fusion, CÓ cờ | 0.319 ± 0.037 | 0.361 ± 0.029 | 0.357 |
| GNN, KHÔNG cờ | 0.310 ± 0.038 | 0.383 ± 0.049 | 0.387 |
| GNN, CÓ cờ | 0.320 ± 0.041 | 0.391 ± 0.026 | 0.391 |

Paired (on − off):
- **10 seed đầu:** kênh GNN PR-AUC +0.010, thắng 8/10, Wilcoxon p=0.032 (< 0.05),
  sign-test p=0.055 — *gợi ý* ranh giới có ý nghĩa.
- **Mở rộng lên 20 seed (52–61) → tín hiệu YẾU ĐI, không còn ý nghĩa:** PR-AUC +0.006,
  thắng **13/20**, **sign-test p=0.132, Wilcoxon p=0.082** (> 0.05). F1/MCC/ROC/recall đều
  không ý nghĩa. Đúng mẫu hình đã cảnh báo: p=0.032 ở 10 seed lại là hiện tượng mẫu nhỏ,
  bốc hơi khi tăng seed — lặp lại y hệt bài học ở mục 11 (4/5 → 9/15).
- **Kênh fusion (10 seed): KHÔNG có ý nghĩa** — PR-AUC +0.024 nhưng thắng 5/10, p=0.28
  (kênh ngữ nghĩa đã mang sẵn thông tin credential → cờ dư thừa; nhất quán mục 11).

**Kết luận (20 seed, có kiểm định):** ngay cả với tập AC mở rộng (+37% mẫu dương thật), đặc
trưng PCFinder **vẫn KHÔNG tạo cải thiện có ý nghĩa thống kê**. Kênh GNN có xu hướng dương
YẾU nhất quán (13/20 > phân nửa, PR-AUC +0.006 trung bình) nhưng không đạt ngưỡng; đây là
"dư âm" của ý tưởng thiết kế đúng nhưng dư thừa với thứ GNN đã tự học từ CDG/DDG. File:
`acbroad_experiment_summary.json`, `runs/acb_*_s*/`.

## SYNTHESIS — Bốn thí nghiệm trước/sau PCFinder (đọc cùng nhau)

| Thí nghiệm | Bài toán | Cờ có giúp? | Vì sao |
|---|---|---|---|
| Mục 10 | Phát hiện lỗ hổng tổng quát (MegaVul) | KHÔNG (2/5) | AC thiểu số + GNN đã học được CDG/DDG |
| Mục 11 | Access-control CHẶT, thật (48 dương) | KHÔNG — 15 seeds, 9/15, p=0.30 | Xu hướng mẫu nhỏ không tái lập |
| Mục 12 | Access-control, synthetic (Juliet) | Không đo được (trần) | Bài toán bão hòa, base đã 0.966 |
| Mục 12b | Access-control RỘNG, thật (66 dương) | KHÔNG — 10 seed gợi ý (8/10, p=0.032) nhưng 20 seed bác bỏ (13/20, Wilcoxon p=0.082) | Lại là xu hướng mẫu nhỏ bốc hơi; chỉ còn xu hướng dương yếu không đạt ngưỡng |

Thông điệp cho luận văn (kết luận cuối, 4 thí nghiệm, tối đa 20 seed, sign-test + Wilcoxon):
**học biểu diễn trên đồ thị phụ thuộc điều khiển/dữ liệu (VDMAF-GNN) bao trùm tri thức
chuyên gia mà PCFinder mã hóa thủ công — đặc trưng PCFinder KHÔNG tạo cải thiện có ý nghĩa
thống kê ở BẤT KỲ cấu hình nào đã thử** (tổng quát; fusion; AC chặt 15 seed p=0.30; AC rộng
20 seed p=0.082; Juliet trần). Kênh GNN thuần trên bài toán AC có một xu hướng dương YẾU,
nhất quán nhưng không đạt ngưỡng ý nghĩa — đây là "dư âm" của ý tưởng thiết kế đúng nhưng
dư thừa với CDG/DDG mà GNN đã tự học. Đóng góp của PCFinder cho VDMAF-Java nằm ở tầng THIẾT
KẾ (giữ tên định danh, xác nhận CDG/DDG là quan hệ cốt lõi), không phải tầng đặc trưng đầu
vào. **Bài học phương pháp lặp lại HAI lần độc lập** (AC chặt: 4/5→9/15; AC rộng: 8/10→
13/20): xu hướng seed nhỏ và p ranh giới có thể bốc hơi khi tăng mẫu — luôn đa seed + kiểm
định + xét đa so sánh trước khi tuyên bố. Đây chính là một đóng góp phương pháp luận của
luận văn, không chỉ là kết quả âm tính.

## 13. Ghi chú kỹ thuật

- Joern script params trên Windows: `--param """k=v"""`.
- Dump phải chạy trên CPG mới sinh (không dùng joern-export).
- Batch lớn: chia thư mục con như pipeline Devign (`run_batches.ps1`).
- Juliet: label theo tên method (`bad` = 1, `good*` = 0) — trích thẳng từ dump `#M`.
- dataset_v2: dump kèm node kind (cột 4 dòng N); vocab/seq/split dùng chung dataset/ v1.
- Bài toán AC: `train_v1.py --ac_only` (dương=AC-CWE vuln, âm=safe, bỏ non-AC vuln).
- Juliet AC: `build_juliet_ac.py` (per-method, nhãn bad/good, seq từ token-order); nguồn
  CWE566+601 tại `Java/juliet_ac/`, dataset `dataset_juliet_ac/`.
