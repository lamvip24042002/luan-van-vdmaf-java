# -*- coding: utf-8 -*-
# VDMAF-artifact baseline on MegaVul Java: faithful port of the released
# Devign makemodel.py — word2vec (lowercased, nltk) + token-keyed "node2vec"
# lookup + UNTRAINED MultiHeadAttention -> reduce_sum static fusion over the
# vocab intersection + BiLSTM stack. Only deviations (same as our C baselines):
# int32 index + frozen Embedding feeding (RAM-safe, mathematically identical),
# fixed seeds, fixed MegaVul splits (identical to the proposed-model runs),
# class_weight balanced (the artifact's choice on its imbalanced dataset).
# Extra metrics (PR-AUC, ROC-AUC, val-tuned threshold) added for comparison
# with the proposed model — they do not affect training.
import json
import os
import random
import sys

import numpy
import numpy as np
import tensorflow as tf
from gensim.models import Word2Vec
from keras.layers import Bidirectional, Dropout, Embedding, LSTM, Dense
from keras.models import Sequential
from tensorflow.keras.losses import BinaryCrossentropy
from tensorflow.keras.preprocessing import sequence
from sklearn.metrics import (accuracy_score, average_precision_score,
                             f1_score, matthews_corrcoef, precision_score,
                             recall_score, roc_auc_score)
from sklearn.utils import class_weight

import myutils

os.environ["CUDA_VISIBLE_DEVICES"] = "0"
SEED = int(sys.argv[1]) if len(sys.argv) > 1 else 42
print("=== seed:", SEED, "===")
random.seed(SEED)
np.random.seed(SEED)
tf.random.set_seed(SEED)


# dwce (as released; == plain BCE since pos_w + neg_w = 1)
def dynamic_weighted_binary_crossentropy(y_true, y_pred):
    batch_size = tf.cast(tf.size(y_true), tf.float32)
    positive_weight = tf.reduce_sum(y_true) / batch_size
    negative_weight = 1.0 - positive_weight
    bce = BinaryCrossentropy(from_logits=False)
    return positive_weight * bce(y_true, y_pred) + negative_weight * bce(y_true, y_pred)


w2v_model = Word2Vec.load("MegaVulJava_word2vec_5-100-300.model")
word_vectors = w2v_model.wv
node2vec_model = Word2Vec.load("node2vec_model-300.model")
node_vectors = node2vec_model.wv

common_tokens = set(word_vectors.key_to_index.keys()).intersection(
    set(node_vectors.key_to_index.keys()))
print("common tokens:", len(common_tokens))

word_vectors_common = []
node_vectors_common = []
for token in common_tokens:
    word_vectors_common.append(word_vectors[token])
    node_vectors_common.append(node_vectors[token])
word_vectors_common_array = np.array(word_vectors_common)
node_vectors_common_array = np.array(node_vectors_common)


def scaled_dot_product_attention(q, k, v, mask):
    matmul_qk = tf.matmul(q, k, transpose_b=True)
    dk = tf.cast(tf.shape(k)[-1], tf.float32)
    scaled_attention_logits = matmul_qk / tf.math.sqrt(dk)
    if mask is not None:
        scaled_attention_logits += (mask * -1e9)
    attention_weights = tf.nn.softmax(scaled_attention_logits, axis=-1)
    return tf.matmul(attention_weights, v), attention_weights


class MultiHeadAttention(tf.keras.layers.Layer):
    def __init__(self, num_heads, d_model):
        super().__init__()
        self.num_heads = num_heads
        self.d_model = d_model
        assert d_model % num_heads == 0
        self.depth = d_model // num_heads
        self.wq = tf.keras.layers.Dense(d_model)
        self.wk = tf.keras.layers.Dense(d_model)
        self.wv = tf.keras.layers.Dense(d_model)
        self.dense = tf.keras.layers.Dense(d_model)

    def split_heads(self, x, batch_size):
        x = tf.reshape(x, (batch_size, -1, self.num_heads, self.depth))
        return tf.transpose(x, perm=[0, 2, 1, 3])

    def call(self, q, k, v, mask):
        batch_size = tf.shape(q)[0]
        q, k, v = self.wq(q), self.wk(k), self.wv(v)
        q = self.split_heads(q, batch_size)
        k = self.split_heads(k, batch_size)
        v = self.split_heads(v, batch_size)
        scaled_attention, w = scaled_dot_product_attention(q, k, v, mask)
        scaled_attention = tf.transpose(scaled_attention, perm=[0, 2, 1, 3])
        concat = tf.reshape(scaled_attention, (batch_size, -1, self.d_model))
        return self.dense(concat), w


# untrained static fusion, exactly as the artifact's Devign/Bagheri variant
multihead_attn = MultiHeadAttention(num_heads=10, d_model=300)
X, _ = multihead_attn(word_vectors_common_array, node_vectors_common_array,
                      node_vectors_common_array, mask=None)
merged_vector_np = np.array(tf.reduce_sum(X, axis=1))
print("merged table:", merged_vector_np.shape)

common_tokens_index = {t: i for i, t in enumerate(common_tokens)}
emb_matrix = np.zeros((len(common_tokens) + 1, 300), dtype=np.float32)
emb_matrix[1:] = merged_vector_np.astype(np.float32)

with open("texts.json", encoding="utf-8") as f:
    texts = json.load(f)
print("functions:", len(texts))


def to_index_seq(code):
    idxs = []
    for t in myutils.getTokens(code):
        if t == " ":
            continue
        i = common_tokens_index.get(t)
        if i is not None:
            idxs.append(i + 1)
    return idxs


X_parts = {"train": [], "validation": [], "test": []}
y_parts = {"train": [], "validation": [], "test": []}
for fid, (split, label, code) in texts.items():
    X_parts[split].append(to_index_seq(code))
    y_parts[split].append(label)

X_train = sequence.pad_sequences(X_parts["train"], maxlen=200)
X_val = sequence.pad_sequences(X_parts["validation"], maxlen=200)
X_test = sequence.pad_sequences(X_parts["test"], maxlen=200)
y_train = numpy.asarray(y_parts["train"]).astype(numpy.float32)
y_val = numpy.asarray(y_parts["validation"]).astype(numpy.float32)
y_test = numpy.asarray(y_parts["test"]).astype(numpy.float32)
print("train/val/test:", len(X_train), len(X_val), len(X_test),
      "| pos:", int(y_train.sum()), int(y_val.sum()), int(y_test.sum()))
nonempty = sum(1 for s in X_parts["train"] if len(s) > 0)
print("train seqs with >=1 known token: %d/%d" % (nonempty, len(X_train)))

dropout = 0.4
neurons = 100
epochs = 50
batchsize = 1024

model = Sequential()
model.add(Embedding(input_dim=emb_matrix.shape[0], output_dim=300,
                    input_length=200, weights=[emb_matrix], trainable=False))
model.add(Bidirectional(LSTM(neurons, return_sequences=True)))
model.add(Dropout(dropout))
model.add(LSTM(neurons, activation='tanh', return_sequences=True))
model.add(Dropout(dropout))
model.add(LSTM(neurons, activation='tanh', return_sequences=True))
model.add(Dropout(dropout))
model.add(LSTM(neurons, activation='tanh'))
model.add(Dropout(dropout))
model.add(Dense(1, activation='sigmoid'))

class_weights = class_weight.compute_class_weight(
    'balanced', classes=numpy.unique(y_train), y=y_train)
class_weights_dict = {i: w for i, w in enumerate(class_weights)}
print("class weights:", class_weights_dict)

model.compile(loss=dynamic_weighted_binary_crossentropy, optimizer="adam",
              metrics=['accuracy', myutils.precision, myutils.recall, myutils.f1])
model.fit(X_train, y_train, epochs=epochs, batch_size=batchsize,
          class_weight=class_weights_dict)
if not os.path.isfile("model_megavul_java.h5"):
    model.save("model_megavul_java.h5")


def eval_split(X, y):
    prob = model.predict(X, batch_size=1024, verbose=0).ravel()
    pred = (prob > 0.5).astype(int)
    best_f1, best_t = 0.0, 0.5
    for t in np.linspace(0.05, 0.95, 19):
        f = f1_score(y, (prob > t).astype(int), zero_division=0)
        if f > best_f1:
            best_f1, best_t = f, float(t)
    return prob, {
        "accuracy": float(accuracy_score(y, pred)),
        "pr_auc": float(average_precision_score(y, prob)),
        "roc_auc": float(roc_auc_score(y, prob)),
        "f1@0.5": float(f1_score(y, pred, zero_division=0)),
        "p@0.5": float(precision_score(y, pred, zero_division=0)),
        "r@0.5": float(recall_score(y, pred, zero_division=0)),
        "mcc@0.5": float(matthews_corrcoef(y, pred)),
        "best_f1": best_f1, "best_t": best_t,
    }


_, val_m = eval_split(X_val, y_val)
prob_test, test_m = eval_split(X_test, y_test)
pred_t = (prob_test > val_m["best_t"]).astype(int)
test_m["f1@val_t"] = float(f1_score(y_test, pred_t, zero_division=0))
test_m["p@val_t"] = float(precision_score(y_test, pred_t, zero_division=0))
test_m["r@val_t"] = float(recall_score(y_test, pred_t, zero_division=0))
test_m["mcc@val_t"] = float(matthews_corrcoef(y_test, pred_t))
test_m["val_t"] = val_m["best_t"]

result = {"seed": SEED, "common_tokens": len(common_tokens),
          "val": val_m, "test": test_m}
with open("baseline_metrics_megavul_java_seed%d.json" % SEED, "w",
          encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
print("BASELINE RESULT SAVED (seed %d)" % SEED)
