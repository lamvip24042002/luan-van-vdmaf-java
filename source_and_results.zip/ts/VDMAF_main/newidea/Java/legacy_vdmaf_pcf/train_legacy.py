# -*- coding: utf-8 -*-
"""Train an end-to-end, paper-style VDMAF model on the Java tensors.

Pipeline
--------
shared Word2Vec lookup -> relation-aware GGNN -> cross-attention
(Q=semantic token sequence, K/V=graph nodes) -> BiLSTM -> vulnerability logit.

The control and treatment runs deliberately instantiate exactly the same
parameters.  ``--pcf`` only decides whether the four ``x_flags`` columns from
``dataset_v2`` are supplied to the always-present flag projection; without the
switch, a zero tensor of the same shape is supplied instead.

Explicit relative paths are resolved from the caller's working directory.  A small
``--limit`` value caps *every* split and is intended only for smoke tests.
"""

from __future__ import annotations

import argparse
import contextlib
import gc
import hashlib
import json
import os
import random
import sys
import time
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    f1_score,
    matthews_corrcoef,
    precision_score,
    recall_score,
    roc_auc_score,
)
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence, pad_sequence
from torch_geometric.data import Batch, Data
from torch_geometric.utils import to_dense_batch


HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_DATASET = os.path.join(HERE, "..", "gnn", "dataset_v2")
DEFAULT_SEQUENCE_DIR = os.path.join(HERE, "..", "gnn", "dataset")
DEFAULT_VOCAB = os.path.join(DEFAULT_SEQUENCE_DIR, "vocab_joint.json")
DEFAULT_EMBEDDING = os.path.join(HERE, "artifacts", "embedding_matrix.npy")
NUM_RELATIONS = 4  # AST, CFG, CDG, REACHING_DEF
FLAG_DIM = 4

GraphItem = Dict[str, Any]
Example = Tuple[GraphItem, torch.Tensor]


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Paper-style VDMAF-Java control/treatment trainer"
    )
    parser.add_argument("--ds", default=DEFAULT_DATASET,
                        help="dataset_v2 directory containing SPLIT.pt")
    parser.add_argument("--seq-dir", default=DEFAULT_SEQUENCE_DIR,
                        help="directory containing seq_SPLIT.pt")
    parser.add_argument("--vocab", default=DEFAULT_VOCAB,
                        help="vocab_joint.json used to build the matrix")
    parser.add_argument("--embedding-matrix", default=DEFAULT_EMBEDDING,
                        help="Word2Vec embedding_matrix.npy aligned to vocab")
    parser.add_argument("--out", default=os.path.join(HERE, "runs", "legacy"),
                        help="output directory (may already contain run_spec.json)")
    parser.add_argument("--pcf", action="store_true",
                        help="use the four PCFinder-inspired node flags")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--batch", type=int, default=8,
                        help="training batch size; lower this first on CUDA OOM")
    parser.add_argument("--eval-batch", type=int, default=0,
                        help="evaluation batch size (0 means --batch)")
    parser.add_argument("--lr", type=float, default=1e-2)
    parser.add_argument("--weight-decay", type=float, default=0.0)
    parser.add_argument("--dropout", type=float, default=0.2)
    parser.add_argument("--patience", type=int, default=10,
                        help="early-stop patience measured in validation PR-AUC")
    parser.add_argument("--grad-clip", type=float, default=1.0)
    parser.add_argument("--heads", type=int, default=10,
                        help="cross-attention heads (embedding dim must divide it)")
    parser.add_argument("--ggnn-steps", type=int, default=2)
    parser.add_argument("--lstm-hidden", type=int, default=100)
    parser.add_argument("--lstm-layers", type=int, default=1)
    parser.add_argument("--attention-chunk", type=int, default=64,
                        help="query tokens per attention call (0 disables chunking)")
    parser.add_argument("--bucket-multiplier", type=int, default=20,
                        help="locally bucket training graphs to reduce dense padding")
    parser.add_argument("--fine-tune-embeddings", action="store_true",
                        help="allow Word2Vec rows to update (frozen by default)")
    parser.add_argument("--amp", action="store_true",
                        help="use CUDA automatic mixed precision")
    parser.add_argument("--deterministic", action="store_true",
                        help="request deterministic PyTorch kernels where available")
    parser.add_argument("--device", default="auto",
                        help="auto, cpu, cuda, or a concrete device such as cuda:0")
    parser.add_argument("--limit", type=int, default=0,
                        help="smoke only: cap train, validation, and test examples")
    parser.add_argument("--overwrite", action="store_true",
                        help="allow replacing an existing completed run")
    args = parser.parse_args(argv)

    # Defaults above are already absolute.  Explicit relative CLI paths follow
    # the normal convention and resolve from the caller's working directory.
    for name in ("ds", "seq_dir", "vocab", "embedding_matrix", "out"):
        value = getattr(args, name)
        setattr(args, name, os.path.abspath(value))

    if args.epochs < 1 or args.batch < 1 or args.patience < 1:
        parser.error("--epochs, --batch, and --patience must be positive")
    if args.eval_batch < 0 or args.limit < 0:
        parser.error("--eval-batch and --limit cannot be negative")
    if args.heads < 1 or args.ggnn_steps < 1 or args.lstm_layers < 1:
        parser.error("--heads, --ggnn-steps, and --lstm-layers must be positive")
    if args.lstm_hidden < 1 or not (0.0 <= args.dropout < 1.0):
        parser.error("invalid --lstm-hidden or --dropout")
    if args.attention_chunk < 0 or args.bucket_multiplier < 0:
        parser.error("chunk and bucket settings cannot be negative")
    return args


def seed_everything(seed: int, deterministic: bool) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    if deterministic:
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True
        # index_add can lack a deterministic CUDA implementation.  warn_only
        # preserves a runnable experiment while making that limitation visible.
        torch.use_deterministic_algorithms(True, warn_only=True)


def choose_device(requested: str) -> torch.device:
    if requested == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    device = torch.device(requested)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but torch.cuda.is_available() is false")
    return device


def torch_load(path: str) -> Any:
    """Load trusted, repository-local tensors without version-specific warnings."""
    try:
        return torch.load(path, map_location="cpu", weights_only=False)
    except TypeError:  # PyTorch before weights_only was introduced
        return torch.load(path, map_location="cpu")


def sha256_file(path: str, block_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        while True:
            block = stream.read(block_size)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


def load_json_if_present(path: str) -> Optional[Dict[str, Any]]:
    if not os.path.isfile(path):
        return None
    with open(path, encoding="utf-8") as stream:
        value = json.load(stream)
    return value if isinstance(value, dict) else {"value": value}


def load_word2vec_matrix(path: str, vocab_path: str) -> Tuple[torch.Tensor, int, Dict[str, Any]]:
    if not os.path.isfile(path):
        raise FileNotFoundError(
            "Word2Vec matrix not found: %s\n"
            "Build legacy_vdmaf_pcf/artifacts/embedding_matrix.npy first." % path
        )
    if not os.path.isfile(vocab_path):
        raise FileNotFoundError("Joint vocabulary not found: %s" % vocab_path)
    with open(vocab_path, encoding="utf-8") as stream:
        vocab = json.load(stream)
    if not isinstance(vocab, dict):
        raise ValueError("vocab JSON must be a token -> integer mapping")
    if sorted(vocab.values()) != list(range(len(vocab))):
        raise ValueError("vocab indices must be unique and contiguous from zero")

    matrix_np = np.load(path, mmap_mode="r", allow_pickle=False)
    if matrix_np.ndim != 2:
        raise ValueError("embedding matrix must be rank 2, got %r" % (matrix_np.shape,))
    if matrix_np.shape[0] != len(vocab):
        raise ValueError(
            "embedding rows (%d) do not match vocab size (%d)"
            % (matrix_np.shape[0], len(vocab))
        )
    if matrix_np.shape[1] < 1:
        raise ValueError("embedding dimension must be positive")
    # Copy closes the mmap and guarantees writable, contiguous float32 storage.
    matrix = torch.from_numpy(np.asarray(matrix_np, dtype=np.float32).copy())
    if not torch.isfinite(matrix).all():
        raise ValueError("embedding matrix contains NaN or infinity")
    if not bool(torch.count_nonzero(matrix[0]) == 0):
        raise ValueError("embedding row 0 must be the zero padding vector")

    metadata_path = os.path.join(os.path.dirname(path), "embedding_metadata.json")
    metadata = load_json_if_present(metadata_path)
    vocab_sha256 = sha256_file(vocab_path)
    declared_vocab_sha256 = None
    if metadata:
        declared_vocab_sha256 = metadata.get("inputs", {}).get("vocab_joint_sha256")
    if (declared_vocab_sha256 is not None
            and str(declared_vocab_sha256).lower() != vocab_sha256.lower()):
        raise ValueError(
            "embedding metadata was built for a different vocab_joint.json "
            "(%s != %s)" % (declared_vocab_sha256, vocab_sha256)
        )
    info: Dict[str, Any] = {
        "path": path,
        "sha256": sha256_file(path),
        "vocab_path": vocab_path,
        "vocab_sha256": vocab_sha256,
        "shape": list(matrix.shape),
        "dtype_loaded": str(matrix.dtype).replace("torch.", ""),
        "metadata_path": metadata_path if os.path.isfile(metadata_path) else None,
        "metadata": metadata,
    }
    return matrix, len(vocab), info


def cap_for_smoke(items: List[Example], limit: int) -> List[Example]:
    """Deterministically cap a split, retaining both labels when possible."""
    if not limit or len(items) <= limit:
        return items
    selected = list(items[:limit])
    if limit < 2:
        return selected
    labels = {int(item[0]["y"]) for item in selected}
    for wanted in (0, 1):
        if wanted in labels:
            continue
        replacement = next((x for x in items[limit:] if int(x[0]["y"]) == wanted), None)
        if replacement is None:
            continue
        replace_at = next(
            (i for i in range(len(selected) - 1, -1, -1)
             if sum(int(x[0]["y"]) == int(selected[i][0]["y"]) for x in selected) > 1),
            len(selected) - 1,
        )
        selected[replace_at] = replacement
        labels.add(wanted)
    return selected


def validate_graph_item(item: GraphItem, split: str) -> None:
    required = {"fid", "x", "x_flags", "edge_index", "edge_type", "y"}
    missing = required.difference(item)
    if missing:
        raise ValueError("%s item lacks fields: %s" % (split, sorted(missing)))
    x, flags = item["x"], item["x_flags"]
    edge_index, edge_type = item["edge_index"], item["edge_type"]
    if x.ndim != 1 or len(x) == 0:
        raise ValueError("%s/%s has an invalid node-token tensor" % (split, item["fid"]))
    if flags.shape != (len(x), FLAG_DIM):
        raise ValueError("%s/%s x_flags must be [nodes,4]" % (split, item["fid"]))
    if edge_index.ndim != 2 or edge_index.shape[0] != 2:
        raise ValueError("%s/%s edge_index must have shape [2,E]" % (split, item["fid"]))
    if edge_type.ndim != 1 or edge_type.shape[0] != edge_index.shape[1]:
        raise ValueError("%s/%s has inconsistent edge tensors" % (split, item["fid"]))
    if edge_type.numel() and (int(edge_type.min()) < 0 or int(edge_type.max()) >= NUM_RELATIONS):
        raise ValueError("%s/%s has an unknown edge relation" % (split, item["fid"]))


def load_split(ds: str, seq_dir: str, split: str, limit: int = 0) -> Tuple[List[Example], Dict[str, int]]:
    graph_path = os.path.join(ds, split + ".pt")
    seq_path = os.path.join(seq_dir, "seq_%s.pt" % split)
    if not os.path.isfile(graph_path):
        raise FileNotFoundError("graph split not found: %s" % graph_path)
    if not os.path.isfile(seq_path):
        raise FileNotFoundError("sequence split not found: %s" % seq_path)
    graphs = torch_load(graph_path)
    seqs = torch_load(seq_path)
    if not isinstance(graphs, list) or not isinstance(seqs, dict):
        raise TypeError("unexpected serialized dataset type for split %s" % split)

    items: List[Example] = []
    missing_sequences = 0
    for item in graphs:
        validate_graph_item(item, split)
        seq = seqs.get(item["fid"])
        if seq is None:
            missing_sequences += 1
            continue
        if seq.ndim != 1 or len(seq) == 0:
            raise ValueError("%s/%s has an invalid token sequence" % (split, item["fid"]))
        items.append((item, seq.long()))
    original = len(items)
    items = cap_for_smoke(items, limit)
    stats = {
        "graphs_serialized": len(graphs),
        "matched": original,
        "missing_sequences": missing_sequences,
        "used": len(items),
        "positive": sum(int(item["y"]) for item, _ in items),
    }
    del graphs, seqs
    gc.collect()
    if not items:
        raise ValueError("split %s is empty after graph/sequence matching" % split)
    return items, stats


def collate(examples: Sequence[Example]) -> Tuple[Batch, torch.Tensor, torch.Tensor, List[str]]:
    graphs: List[Data] = []
    seqs: List[torch.Tensor] = []
    labels: List[float] = []
    fids: List[str] = []
    for item, seq in examples:
        graphs.append(Data(
            x=item["x"].long(),
            x_flags=item["x_flags"].float(),
            edge_index=item["edge_index"].long(),
            edge_type=item["edge_type"].long(),
        ))
        seqs.append(seq.long())
        labels.append(float(item["y"]))
        fids.append(str(item["fid"]))
    graph_batch = Batch.from_data_list(graphs)
    sequence_batch = pad_sequence(seqs, batch_first=True, padding_value=0)
    label_batch = torch.tensor(labels, dtype=torch.float32)
    return graph_batch, sequence_batch, label_batch, fids


def training_batches(
    items: Sequence[Example], batch_size: int, rng: random.Random, bucket_multiplier: int
) -> Iterable[Sequence[Example]]:
    indices = list(range(len(items)))
    rng.shuffle(indices)
    if bucket_multiplier > 0:
        bucket_size = max(batch_size, batch_size * bucket_multiplier)
        ordered: List[int] = []
        for start in range(0, len(indices), bucket_size):
            bucket = indices[start:start + bucket_size]
            # Local sorting substantially reduces B*Nmax dense graph padding,
            # while shuffled buckets retain stochasticity across epochs.
            bucket.sort(key=lambda i: len(items[i][0]["x"]))
            ordered.extend(bucket)
        indices = ordered
    for start in range(0, len(indices), batch_size):
        yield [items[i] for i in indices[start:start + batch_size]]


class RelationAwareGGNN(nn.Module):
    """GGNN with one directed message matrix per CPG/PDG relation."""

    def __init__(self, dim: int, num_relations: int, steps: int, dropout: float):
        super().__init__()
        self.dim = dim
        self.num_relations = num_relations
        self.steps = steps
        # F.linear interprets each [D,D] slice as [out_features,in_features].
        self.relation_weight = nn.Parameter(torch.empty(num_relations, dim, dim))
        self.update = nn.GRUCell(dim, dim)
        self.dropout = nn.Dropout(dropout)
        self.reset_parameters()

    def reset_parameters(self) -> None:
        for relation in range(self.num_relations):
            nn.init.xavier_uniform_(self.relation_weight[relation])
        self.update.reset_parameters()

    def forward(self, nodes: torch.Tensor, edge_index: torch.Tensor,
                edge_type: torch.Tensor) -> torch.Tensor:
        # High-degree sum aggregation can overflow fp16 after several updates
        # at the paper's lr=0.01. Keep GGNN messages and recurrence in fp32;
        # outer AMP still accelerates cross-attention and BiLSTM.
        with torch.autocast(device_type=nodes.device.type, enabled=False):
            hidden = nodes.float()
            source, target = edge_index[0], edge_index[1]
            for _ in range(self.steps):
                aggregated = hidden.new_zeros(hidden.shape)
                # Process relations separately: selecting W[edge_type] per edge
                # would materialize an unsafe [E,D,D] tensor.
                for relation in range(self.num_relations):
                    mask = edge_type == relation
                    rel_source = source[mask]
                    rel_target = target[mask]
                    message = F.linear(hidden.index_select(0, rel_source),
                                       self.relation_weight[relation].float())
                    aggregated.index_add_(0, rel_target, message)
                hidden = self.update(aggregated, hidden)
                hidden = self.dropout(hidden)
        return hidden


class LegacyVDMAF(nn.Module):
    def __init__(
        self,
        embedding_matrix: torch.Tensor,
        use_pcf: bool,
        heads: int,
        ggnn_steps: int,
        lstm_hidden: int,
        lstm_layers: int,
        dropout: float,
        attention_chunk: int,
        fine_tune_embeddings: bool,
    ) -> None:
        super().__init__()
        vocab_size, dim = embedding_matrix.shape
        if dim % heads:
            raise ValueError("embedding dim %d must be divisible by %d heads" % (dim, heads))
        self.use_pcf = use_pcf
        self.dim = dim
        self.attention_chunk = attention_chunk
        self.embedding = nn.Embedding.from_pretrained(
            embedding_matrix, freeze=not fine_tune_embeddings, padding_idx=0
        )
        # This layer exists in both arms. Control feeds zeros; treatment feeds
        # x_flags. Thus parameter count and all non-treatment initialization match.
        self.flag_projection = nn.Linear(FLAG_DIM, dim, bias=False)
        self.node_norm = nn.LayerNorm(dim)
        self.ggnn = RelationAwareGGNN(dim, NUM_RELATIONS, ggnn_steps, dropout)
        self.cross_attention = nn.MultiheadAttention(
            dim, heads, dropout=dropout, batch_first=True
        )
        self.fusion_norm = nn.LayerNorm(dim)
        self.input_dropout = nn.Dropout(dropout)
        self.fusion_dropout = nn.Dropout(dropout)
        self.classifier_lstm = nn.LSTM(
            input_size=dim,
            hidden_size=lstm_hidden,
            num_layers=lstm_layers,
            dropout=dropout if lstm_layers > 1 else 0.0,
            bidirectional=True,
            batch_first=True,
        )
        # Paper-style temporal attention pools the complete BiLSTM output,
        # instead of discarding every time step except the two final states.
        self.temporal_attention = nn.Linear(2 * lstm_hidden, 1, bias=True)
        self.output_dropout = nn.Dropout(dropout)
        self.output = nn.Linear(2 * lstm_hidden, 1)
        self.vocab_size = vocab_size

    def _cross_attend(
        self, query: torch.Tensor, graph: torch.Tensor, graph_mask: torch.Tensor
    ) -> torch.Tensor:
        key_padding_mask = ~graph_mask
        chunk = self.attention_chunk
        if not chunk or query.shape[1] <= chunk:
            attended, _ = self.cross_attention(
                query, graph, graph, key_padding_mask=key_padding_mask,
                need_weights=False,
            )
            return attended
        outputs = []
        for start in range(0, query.shape[1], chunk):
            attended, _ = self.cross_attention(
                query[:, start:start + chunk], graph, graph,
                key_padding_mask=key_padding_mask, need_weights=False,
            )
            outputs.append(attended)
        return torch.cat(outputs, dim=1)

    def forward(self, graph_batch: Batch, sequences: torch.Tensor) -> torch.Tensor:
        sequence_mask = sequences.ne(0)
        lengths = sequence_mask.sum(dim=1).clamp(min=1)
        semantic = self.input_dropout(self.embedding(sequences))

        node_word2vec = self.embedding(graph_batch.x)
        flags = graph_batch.x_flags
        if not self.use_pcf:
            flags = torch.zeros_like(flags)
        node_initial = self.node_norm(node_word2vec + self.flag_projection(flags))
        node_initial = self.input_dropout(node_initial)
        node_hidden = self.ggnn(
            node_initial, graph_batch.edge_index, graph_batch.edge_type
        )

        graph_dense, graph_mask = to_dense_batch(node_hidden, graph_batch.batch)
        graph_context = self._cross_attend(semantic, graph_dense, graph_mask)
        # Attention output is graph-valued; a residual keeps the semantic token
        # identity so the downstream BiLSTM sees a genuinely fused sequence.
        fused = self.fusion_norm(semantic + self.fusion_dropout(graph_context))

        packed = pack_padded_sequence(
            fused, lengths.detach().cpu(), batch_first=True, enforce_sorted=False
        )
        packed_output, _ = self.classifier_lstm(packed)
        recurrent, _ = pad_packed_sequence(
            packed_output, batch_first=True, total_length=fused.shape[1]
        )
        # Eq. (16) of VDMAF: exp(tanh(W_h h_i + b_h)), normalized over time.
        temporal_score = torch.tanh(self.temporal_attention(recurrent).squeeze(-1))
        temporal_score = temporal_score.masked_fill(~sequence_mask, float("-inf"))
        temporal_weight = torch.softmax(temporal_score, dim=1)
        representation = torch.sum(recurrent * temporal_weight.unsqueeze(-1), dim=1)
        return self.output(self.output_dropout(representation)).squeeze(-1)


def metric_or_none(function: Any, y: np.ndarray, prob_or_pred: np.ndarray) -> Optional[float]:
    try:
        return float(function(y, prob_or_pred))
    except (ValueError, ZeroDivisionError):
        return None


def calculate_metrics(y: np.ndarray, prob: np.ndarray,
                      select_threshold: bool = True) -> Dict[str, Any]:
    pred = (prob > 0.5).astype(np.int64)
    has_both = np.unique(y).size == 2
    metrics: Dict[str, Any] = {
        "accuracy": float(accuracy_score(y, pred)),
        "pr_auc": float(average_precision_score(y, prob)) if has_both else None,
        "roc_auc": float(roc_auc_score(y, prob)) if has_both else None,
        "f1@0.5": float(f1_score(y, pred, zero_division=0)),
        "p@0.5": float(precision_score(y, pred, zero_division=0)),
        "r@0.5": float(recall_score(y, pred, zero_division=0)),
        "mcc@0.5": metric_or_none(matthews_corrcoef, y, pred),
    }
    if select_threshold:
        best_f1, best_t = -1.0, 0.5
        for threshold in np.linspace(0.05, 0.95, 19):
            score = f1_score(y, (prob > threshold).astype(np.int64), zero_division=0)
            if score > best_f1:
                best_f1, best_t = float(score), float(threshold)
        metrics["best_f1"] = best_f1
        metrics["best_t"] = best_t
    return metrics


def autocast_context(device: torch.device, enabled: bool) -> contextlib.AbstractContextManager:
    if enabled and device.type == "cuda":
        return torch.autocast(device_type="cuda", dtype=torch.float16)
    return contextlib.nullcontext()


@dataclass
class Evaluation:
    metrics: Dict[str, Any]
    probability: np.ndarray
    label: np.ndarray
    fids: np.ndarray


def evaluate(
    model: nn.Module,
    items: Sequence[Example],
    batch_size: int,
    device: torch.device,
    amp: bool,
    select_threshold: bool = True,
) -> Evaluation:
    model.eval()
    probabilities: List[torch.Tensor] = []
    labels: List[torch.Tensor] = []
    fids: List[str] = []
    with torch.inference_mode():
        for start in range(0, len(items), batch_size):
            graph, sequence, label, batch_fids = collate(items[start:start + batch_size])
            graph = graph.to(device)
            sequence = sequence.to(device)
            with autocast_context(device, amp):
                logit = model(graph, sequence)
            if not bool(torch.isfinite(logit).all()):
                raise FloatingPointError("non-finite evaluation logits")
            probabilities.append(torch.sigmoid(logit.float()).cpu())
            labels.append(label)
            fids.extend(batch_fids)
    probability_np = torch.cat(probabilities).numpy()
    label_np = torch.cat(labels).numpy().astype(np.int64)
    return Evaluation(
        calculate_metrics(label_np, probability_np, select_threshold),
        probability_np,
        label_np,
        np.asarray(fids),
    )


def cpu_state_dict(model: nn.Module) -> Dict[str, torch.Tensor]:
    return {key: value.detach().cpu().clone() for key, value in model.state_dict().items()}


def state_dict_sha256(model: nn.Module) -> str:
    """Content hash used to audit paired control/treatment initialization."""
    digest = hashlib.sha256()
    state = model.state_dict()
    for key in sorted(state):
        tensor = state[key].detach().cpu().contiguous()
        digest.update(key.encode("utf-8"))
        digest.update(b"\0")
        digest.update(str(tensor.dtype).encode("ascii"))
        digest.update(np.asarray(tensor.shape, dtype=np.int64).tobytes())
        digest.update(tensor.numpy().tobytes(order="C"))
    return digest.hexdigest()


def atomic_json(path: str, value: Dict[str, Any]) -> None:
    temporary = path + ".tmp"
    with open(temporary, "w", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write("\n")
    os.replace(temporary, path)


def atomic_torch_save(path: str, value: Any) -> None:
    temporary = path + ".tmp"
    torch.save(value, temporary)
    os.replace(temporary, path)


def atomic_npz(path: str, **arrays: Any) -> None:
    temporary = path + ".tmp"
    with open(temporary, "wb") as stream:
        np.savez_compressed(stream, **arrays)
    os.replace(temporary, path)


def add_validation_threshold(metrics: Dict[str, Any], y: np.ndarray,
                             prob: np.ndarray, threshold: float) -> None:
    pred = (prob > threshold).astype(np.int64)
    metrics.update({
        "f1@val_t": float(f1_score(y, pred, zero_division=0)),
        "p@val_t": float(precision_score(y, pred, zero_division=0)),
        "r@val_t": float(recall_score(y, pred, zero_division=0)),
        "mcc@val_t": metric_or_none(matthews_corrcoef, y, pred),
        "val_t": float(threshold),
    })


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parse_args(argv)
    os.makedirs(args.out, exist_ok=True)
    metrics_path = os.path.join(args.out, "metrics.json")
    if os.path.isfile(metrics_path) and not args.overwrite:
        raise FileExistsError(
            "completed run exists at %s (use --overwrite to replace it)" % metrics_path
        )

    seed_everything(args.seed, args.deterministic)
    device = choose_device(args.device)
    if args.amp and device.type != "cuda":
        print("warning: --amp has no effect on %s" % device, file=sys.stderr)
    amp_enabled = bool(args.amp and device.type == "cuda")
    eval_batch = args.eval_batch or args.batch

    embedding_matrix, vocab_size, word2vec_info = load_word2vec_matrix(
        args.embedding_matrix, args.vocab
    )
    embedding_dim = int(embedding_matrix.shape[1])
    if embedding_dim % args.heads:
        raise ValueError(
            "Word2Vec dimension %d is not divisible by --heads=%d"
            % (embedding_dim, args.heads)
        )

    print("device=%s torch=%s vocab=%d dim=%d pcf=%s seed=%d" % (
        device, torch.__version__, vocab_size, embedding_dim, args.pcf, args.seed
    ), flush=True)
    if args.limit:
        print("SMOKE MODE: --limit=%d caps every split; do not report these metrics" % args.limit)

    train_items, train_stats = load_split(args.ds, args.seq_dir, "train", args.limit)
    validation_items, validation_stats = load_split(
        args.ds, args.seq_dir, "validation", args.limit
    )
    positives = sum(int(item["y"]) for item, _ in train_items)
    negatives = len(train_items) - positives
    if positives == 0:
        raise ValueError("training split has no positive examples")
    pos_weight = negatives / positives
    print(
        "train=%d (pos=%d, pos_weight=%.3f) validation=%d"
        % (len(train_items), positives, pos_weight, len(validation_items)),
        flush=True,
    )

    model = LegacyVDMAF(
        embedding_matrix=embedding_matrix,
        use_pcf=args.pcf,
        heads=args.heads,
        ggnn_steps=args.ggnn_steps,
        lstm_hidden=args.lstm_hidden,
        lstm_layers=args.lstm_layers,
        dropout=args.dropout,
        attention_chunk=args.attention_chunk,
        fine_tune_embeddings=args.fine_tune_embeddings,
    )
    initial_state_sha256 = state_dict_sha256(model)
    model = model.to(device)
    del embedding_matrix
    trainable_parameters = sum(p.numel() for p in model.parameters() if p.requires_grad)
    total_parameters = sum(p.numel() for p in model.parameters())
    print("parameters=%d trainable=%d" % (total_parameters, trainable_parameters), flush=True)

    # The paper specifies Adam; weight decay remains an explicit opt-in CLI
    # setting rather than silently changing the optimizer to AdamW.
    optimizer = torch.optim.Adam(
        (p for p in model.parameters() if p.requires_grad),
        lr=args.lr,
        weight_decay=args.weight_decay,
    )
    criterion = nn.BCEWithLogitsLoss(
        pos_weight=torch.tensor(pos_weight, dtype=torch.float32, device=device)
    )
    try:
        scaler = torch.amp.GradScaler("cuda", enabled=amp_enabled)
    except (AttributeError, TypeError):
        scaler = torch.cuda.amp.GradScaler(enabled=amp_enabled)

    rng = random.Random(args.seed)
    best_pr_auc = float("-inf")
    best_epoch = 0
    best_threshold = 0.5
    best_state: Optional[Dict[str, torch.Tensor]] = None
    stale_epochs = 0
    history: List[Dict[str, Any]] = []
    nonfinite_stop: Optional[Dict[str, Any]] = None
    started = time.time()

    for epoch in range(1, args.epochs + 1):
        model.train()
        epoch_started = time.time()
        loss_sum = 0.0
        seen = 0
        try:
            for examples in training_batches(
                train_items, args.batch, rng, args.bucket_multiplier
            ):
                graph, sequence, label, _ = collate(examples)
                graph = graph.to(device)
                sequence = sequence.to(device)
                label = label.to(device)
                optimizer.zero_grad(set_to_none=True)
                with autocast_context(device, amp_enabled):
                    logit = model(graph, sequence)
                    loss = criterion(logit, label)
                if not bool(torch.isfinite(loss)):
                    nonfinite_stop = {
                        "epoch": epoch,
                        "stage": "training_loss",
                        "message": "non-finite loss; restored last valid checkpoint",
                    }
                    print("NON-FINITE training loss at epoch %d; stopping" % epoch,
                          file=sys.stderr, flush=True)
                    break
                scaler.scale(loss).backward()
                scaler.unscale_(optimizer)
                if args.grad_clip > 0:
                    nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip)
                scaler.step(optimizer)
                scaler.update()
                count = int(label.numel())
                loss_sum += float(loss.detach()) * count
                seen += count
        except torch.cuda.OutOfMemoryError as error:
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            raise RuntimeError(
                "CUDA out of memory. Lower --batch/--eval-batch or "
                "--attention-chunk (current: %d/%d/%d)."
                % (args.batch, eval_batch, args.attention_chunk)
            ) from error

        if nonfinite_stop is not None:
            break

        try:
            validation = evaluate(model, validation_items, eval_batch, device, amp_enabled)
        except FloatingPointError as error:
            nonfinite_stop = {
                "epoch": epoch,
                "stage": "validation",
                "message": str(error) + "; restored last valid checkpoint",
            }
            print("NON-FINITE validation at epoch %d; stopping" % epoch,
                  file=sys.stderr, flush=True)
            break
        validation_pr = validation.metrics["pr_auc"]
        score = float(validation_pr) if validation_pr is not None else float("-inf")
        epoch_record = {
            "epoch": epoch,
            "loss": loss_sum / max(seen, 1),
            "val_pr_auc": validation_pr,
            "val_f1@0.5": validation.metrics["f1@0.5"],
            "val_best_f1": validation.metrics["best_f1"],
            "val_best_t": validation.metrics["best_t"],
            "seconds": time.time() - epoch_started,
        }
        history.append(epoch_record)
        print(
            "EPOCH %02d loss=%.4f val_pr_auc=%s val_f1@0.5=%.4f "
            "best_f1=%.4f(t=%.2f) %.0fs"
            % (
                epoch,
                epoch_record["loss"],
                "null" if validation_pr is None else "%.4f" % validation_pr,
                validation.metrics["f1@0.5"],
                validation.metrics["best_f1"],
                validation.metrics["best_t"],
                epoch_record["seconds"],
            ),
            flush=True,
        )

        if best_state is None or score > best_pr_auc:
            best_pr_auc = score
            best_epoch = epoch
            best_threshold = float(validation.metrics["best_t"])
            best_state = cpu_state_dict(model)
            stale_epochs = 0
        else:
            stale_epochs += 1
            if stale_epochs >= args.patience:
                print("early stop at epoch %d" % epoch, flush=True)
                break

    if best_state is None:  # defensive; the first epoch normally sets it
        raise RuntimeError("training completed without a checkpoint")
    model.load_state_dict(best_state)

    model_config = {
        "vocab_size": vocab_size,
        "embedding_dim": embedding_dim,
        "pcf": bool(args.pcf),
        "num_relations": NUM_RELATIONS,
        "flag_dim": FLAG_DIM,
        "heads": args.heads,
        "ggnn_steps": args.ggnn_steps,
        "lstm_hidden": args.lstm_hidden,
        "lstm_layers": args.lstm_layers,
        "dropout": args.dropout,
        "attention_chunk": args.attention_chunk,
        "fine_tune_embeddings": bool(args.fine_tune_embeddings),
    }
    atomic_torch_save(os.path.join(args.out, "model.pt"), {
        "state_dict": best_state,
        "model_config": model_config,
        "embedding_sha256": word2vec_info["sha256"],
        "initial_state_sha256": initial_state_sha256,
        "best_epoch": best_epoch,
        "best_val_pr_auc": None if best_pr_auc == float("-inf") else best_pr_auc,
        "best_val_threshold": best_threshold,
    })
    del best_state

    # Re-evaluate the selected checkpoint, then release training tensors before
    # loading test.pt.  This keeps peak host RAM well below loading all splits.
    validation = evaluate(model, validation_items, eval_batch, device, amp_enabled)
    atomic_npz(
        os.path.join(args.out, "validation_probs.npz"),
        fids=validation.fids,
        prob=validation.probability,
        y=validation.label,
        best_t=np.asarray(best_threshold),
    )
    del train_items
    gc.collect()

    test_items, test_stats = load_split(args.ds, args.seq_dir, "test", args.limit)
    # Never optimize a threshold on test labels.  Only the validation-selected
    # threshold and the fixed 0.5 operating point are reported for test.
    test = evaluate(
        model, test_items, eval_batch, device, amp_enabled,
        select_threshold=False,
    )
    add_validation_threshold(test.metrics, test.label, test.probability, best_threshold)
    atomic_npz(
        os.path.join(args.out, "test_probs.npz"),
        fids=test.fids,
        prob=test.probability,
        y=test.label,
        val_t=np.asarray(best_threshold),
    )

    config = vars(args).copy()
    result: Dict[str, Any] = {
        "config": config,
        "data": {
            "train": train_stats,
            "validation": validation_stats,
            "test": test_stats,
            "pos_weight": pos_weight,
            "limit_is_smoke_only": bool(args.limit),
        },
        "word2vec": {
            **word2vec_info,
            "frozen": not args.fine_tune_embeddings,
        },
        "model": {
            **model_config,
            "parameters": total_parameters,
            "trainable_parameters": trainable_parameters,
            "initial_state_sha256": initial_state_sha256,
        },
        "training": {
            "best_epoch": best_epoch,
            "best_val_pr_auc": None if best_pr_auc == float("-inf") else best_pr_auc,
            "epochs_ran": len(history),
            "early_stopped": len(history) < args.epochs,
            "nonfinite_stop": nonfinite_stop,
            "history": history,
            "seconds": time.time() - started,
            "device": str(device),
            "torch_version": torch.__version__,
            "optimizer": "Adam",
        },
        "val": validation.metrics,
        "test": test.metrics,
    }
    atomic_json(metrics_path, result)
    print("TEST:", json.dumps(test.metrics, indent=2), flush=True)
    print("RESULT SAVED -> %s" % args.out, flush=True)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("interrupted", file=sys.stderr)
        raise SystemExit(130)
