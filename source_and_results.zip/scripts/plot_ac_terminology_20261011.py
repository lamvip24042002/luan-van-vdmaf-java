"""Regenerate the 15-seed AC figure from its original, unrounded metrics.

Only the chart terminology and presentation change. No model is reevaluated.
The original summary is checked against every per-seed metrics file before
the existing thesis PNG is backed up and replaced.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import shutil

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import FuncFormatter
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
GNN = ROOT / "ts/VDMAF_main/newidea/Java/gnn"
DESTINATION = ROOT / "luanvan/Figures/fig3_boxplot_pcfinder_ac_15seed.png"
BACKUP = (
    ROOT
    / "output/seminar_20261011/backup_terminology/luanvan/Figures"
    / DESTINATION.name
)
SEEDS = tuple(range(42, 57))


def read_original_data() -> tuple[dict[str, np.ndarray], dict]:
    summary_path = GNN / "ac_experiment_summary.json"
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    values: dict[str, np.ndarray] = {}
    sources = []
    for variant in ("off", "on"):
        per_seed = []
        for seed in SEEDS:
            path = GNN / f"runs/ac_gnn_{variant}_s{seed}/metrics.json"
            raw = path.read_bytes()
            metric = json.loads(raw)
            config = metric["config"]
            assert config["seed"] == seed, path
            assert config["pcf"] is (variant == "on"), path
            assert config["channels"] == "gnn" and config["ac_only"], path
            ap = float(metric["test"]["pr_auc"])
            assert math.isfinite(ap) and 0 <= ap <= 1, path
            per_seed.append(ap)
            sources.append(
                {
                    "path": path.relative_to(ROOT).as_posix(),
                    "sha256": hashlib.sha256(raw).hexdigest(),
                    "seed": seed,
                    "pcf": variant,
                    "test_ap": ap,
                }
            )
        expected = summary[f"ac_gnn_{variant}"]["pr_auc"]
        assert per_seed == expected, f"Original summary differs: {variant}"
        values[variant] = np.asarray(per_seed, dtype=float)

    diff = values["on"] - values["off"]
    positive = int(np.sum(diff > 0))
    nonzero = int(np.sum(diff != 0))
    sign_p = sum(math.comb(nonzero, k) for k in range(positive, nonzero + 1)) / 2**nonzero
    # The numbers below are consistency checks against the existing thesis.
    assert positive == 9 and nonzero == 15
    assert round(sign_p, 2) == 0.30
    assert round(float(diff.mean()), 4) == 0.0009
    report = {
        "source_summary": summary_path.relative_to(ROOT).as_posix(),
        "seeds": list(SEEDS),
        "ap_off": values["off"].tolist(),
        "ap_on": values["on"].tolist(),
        "mean_off": float(values["off"].mean()),
        "mean_on": float(values["on"].mean()),
        "mean_paired_difference": float(diff.mean()),
        "positive_pairs": positive,
        "one_sided_sign_test_p": sign_p,
        "matches_original_summary_exactly": True,
        "source_files": sources,
    }
    return values, report


def render(values: dict[str, np.ndarray], report: dict) -> None:
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 11,
            "axes.labelsize": 12,
            "axes.titlesize": 14,
            "xtick.labelsize": 12,
            "ytick.labelsize": 11,
            "figure.facecolor": "white",
            "savefig.facecolor": "white",
        }
    )
    fig, ax = plt.subplots(figsize=(7.5, 6.0))
    ax.boxplot(
        [values["off"], values["on"]],
        tick_labels=["Kênh cấu trúc\nPCF tắt", "Kênh cấu trúc\nPCF bật"],
        widths=0.45,
        showmeans=True,
        meanline=True,
        boxprops={"color": "#444444", "linewidth": 1.4},
        medianprops={"color": "#444444", "linewidth": 1.4},
        meanprops={"color": "#bd382c", "linewidth": 1.6, "linestyle": "--"},
        whiskerprops={"color": "#444444"},
        capprops={"color": "#444444"},
    )
    rng = np.random.default_rng(0)
    for position, variant in enumerate(("off", "on"), start=1):
        ap = values[variant]
        x = position + rng.uniform(-0.09, 0.09, size=len(SEEDS))
        ax.scatter(
            x[:5], ap[:5], color="#247daf", marker="o", s=60,
            zorder=3, edgecolor="white", linewidth=0.7,
        )
        ax.scatter(
            x[5:], ap[5:], color="#899b9d", marker="D", s=40,
            zorder=3, edgecolor="white", linewidth=0.6,
        )

    ax.set_ylabel("AP trên tập kiểm thử kiểm soát truy cập")
    ax.yaxis.set_major_formatter(FuncFormatter(lambda value, _: f"{value:.2f}".replace(".", ",")))
    ax.grid(axis="y", linestyle=":", color="#b7b7b7", alpha=0.7)
    ax.set_axisbelow(True)
    fig.suptitle("AP qua 15 hạt giống ngẫu nhiên", y=0.975, fontsize=15)
    ax.set_title("Đặc trưng PCFinder trên kênh cấu trúc · 48 mẫu dương", pad=12, fontsize=11)
    handles = [
        Line2D([], [], linestyle="none", marker="o", color="#247daf", markersize=7,
               label="5 hạt giống ban đầu (42–46)"),
        Line2D([], [], linestyle="none", marker="D", color="#899b9d", markersize=6,
               label="10 hạt giống bổ sung (47–56)"),
        Line2D([], [], linestyle="--", color="#bd382c", linewidth=1.6,
               label="Trung bình của 15 lần chạy"),
    ]
    ax.legend(handles=handles, loc="upper right", fontsize=9, framealpha=0.95)
    p_value = f"{report['one_sided_sign_test_p']:.2f}".replace(".", ",")
    fig.text(
        0.5, 0.026,
        f"Kiểm định dấu một phía: p = {p_value}; chưa đạt mức ý nghĩa 0,05.",
        ha="center", fontsize=10,
    )
    fig.tight_layout(rect=(0.015, 0.055, 0.99, 0.95))
    # Keep the first pre-edit PNG, including on a repeat run of this script.
    if DESTINATION.exists() and not BACKUP.exists():
        BACKUP.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(DESTINATION, BACKUP)
    fig.savefig(
        DESTINATION,
        dpi=220,
        metadata={
            "Description": json.dumps(report, ensure_ascii=False),
            "Software": f"Matplotlib {matplotlib.__version__}; plot_ac_terminology_20261011.py",
        },
    )
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify-only", action="store_true", help="Check source data without rendering.")
    args = parser.parse_args()
    values, report = read_original_data()
    if not args.verify_only:
        render(values, report)
    compact = {key: value for key, value in report.items() if key != "source_files"}
    compact["output"] = str(DESTINATION) if not args.verify_only else None
    compact["backup"] = str(BACKUP) if BACKUP.exists() else None
    print(json.dumps(compact, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
