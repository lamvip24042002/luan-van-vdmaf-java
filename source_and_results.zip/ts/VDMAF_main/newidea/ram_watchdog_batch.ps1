# Long-running watchdog for the 6-mode Bagheri batch: does NOT exit when python
# is briefly absent (gaps between pipeline steps). Kills python on RAM limits,
# exits when the driver log says ALL MODES DONE or after 10 h (safety).
$log = "C:\Users\ADMIN\Desktop\ts\VDMAF_main\newidea\ram_watchdog.log"
$driverlog = "C:\Users\ADMIN\Desktop\ts\VDMAF_main\newidea\run_bagheri_modes.log"
$deadline = (Get-Date).AddHours(10)
Add-Content $log "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') batch watchdog started"
while ((Get-Date) -lt $deadline) {
    $os = Get-CimInstance Win32_OperatingSystem
    $freeGB = [math]::Round($os.FreePhysicalMemory/1MB, 1)
    $pys = Get-Process python* -ErrorAction SilentlyContinue
    $pyGB = 0
    if ($pys) { $pyGB = [math]::Round((($pys | Measure-Object WorkingSet64 -Sum).Sum)/1GB, 1) }
    Add-Content $log "$(Get-Date -Format HH:mm:ss) free=${freeGB}GB python=${pyGB}GB"
    if ($freeGB -lt 3 -or $pyGB -gt 22) {
        Add-Content $log "$(Get-Date -Format HH:mm:ss) LIMIT HIT (free=${freeGB}GB, python=${pyGB}GB) -> killing python"
        if ($pys) { $pys | Stop-Process -Force }
    }
    if (Select-String -Path $driverlog -Pattern "ALL MODES DONE" -Quiet -ErrorAction SilentlyContinue) {
        Add-Content $log "$(Get-Date -Format HH:mm:ss) batch finished -> watchdog exits"
        break
    }
    Start-Sleep -Seconds 30
}
