# -*- coding: utf-8 -*-
# VDMAF-Java v1: proposed model = semantic channel (token seq -> BiLSTM)
# + structure channel (per-function PDG -> relation-aware R-GCN)
# + TRAINED cross-attention fusion (query = token states, key/value = node
# states) — end-to-end, fixing the untrained-fusion defect of the VDMAF
# artifact. Shared embedding table over the joint vocabulary.
#
# Ablations: --channels both|gnn|seq ; --edges all|cdg_ddg
# Usage (env vdmaf-gnn):
#   python train_v1.py --out runs/v1_both --channels both --edges all
import argparse
import json
import os
import random
import time

import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import (average_precision_score, f1_score,
                             matthews_corrcoef, precision_score,
                             recall_score, roc_auc_score)
from torch.nn.utils.rnn import pad_sequence
from torch_geometric.data import Batch, Data
from torch_geometric.nn import RGCNConv, global_mean_pool
from torch_geometric.utils import to_dense_batch

HERE = os.path.dirname(os.path.abspath(__file__))

p = argparse.ArgumentParser()
p.add_argument("--channels", default="both", choices=["both", "gnn", "seq"])
p.add_argument("--edges", default="all", choices=["all", "cdg_ddg"])
p.add_argument("--ds", default="dataset", help="graph dataset dir (dataset|dataset_v2)")
p.add_argument("--pcf", action="store_true",
               help="use PCFinder-inspired x_flags node features (needs dataset_v2)")
p.add_argument("--ac_only", action="store_true",
               help="access-control task: pos=AC-CWE vuln, neg=safe, drop non-AC vulns")
p.add_argument("--ac_broad", action="store_true",
               help="broaden AC to OWASP-A01/A07 set (adds auth/CSRF/session CWEs)")
p.add_argument("--dim", type=int, default=128)
p.add_argument("--epochs", type=int, default=15)
p.add_argument("--batch", type=int, default=64)
p.add_argument("--lr", type=float, default=1e-3)
p.add_argument("--dropout", type=float, default=0.3)
p.add_argument("--patience", type=int, default=4)
p.add_argument("--limit", type=int, default=0, help="debug: cap train size")
p.add_argument("--seed", type=int, default=42)
p.add_argument("--out", default="runs/v1")
args = p.parse_args()

random.seed(args.seed)
np.random.seed(args.seed)
torch.manual_seed(args.seed)
torch.cuda.manual_seed_all(args.seed)

outdir = os.path.join(HERE, args.out)
os.makedirs(outdir, exist_ok=True)
dev = "cuda" if torch.cuda.is_available() else "cpu"

DS = os.path.join(HERE, args.ds)          # graph tensors (v1 or v2)
SHARED = os.path.join(HERE, "dataset")    # seq + vocab are shared across versions

with open(os.path.join(SHARED, "vocab_joint.json"), encoding="utf-8") as f:
    V = len(json.load(f))
print("vocab:", V, "| device:", dev, "| config:", vars(args))

FLAG_DIM = 4 if args.pcf else 0

# access-control task: fid -> is member of an AC CWE (only used with --ac_only)
# STRICT = authorization core; BROAD adds OWASP-A01 CSRF + A07 auth/session CWEs.
AC_CWES = {"CWE-264", "CWE-668", "CWE-862", "CWE-863", "CWE-285", "CWE-639",
           "CWE-284", "CWE-276", "CWE-269", "CWE-306", "CWE-732", "CWE-601",
           "CWE-522", "CWE-425"}
if args.ac_broad:
    AC_CWES = AC_CWES | {"CWE-287", "CWE-290", "CWE-352", "CWE-346",
                         "CWE-384", "CWE-613", "CWE-648"}
fid_is_ac = {}
if args.ac_only:
    with open(os.path.join(HERE, "..", "graph", "labels_all.tsv"), encoding="utf-8") as f:
        next(f)
        for line in f:
            p = line.rstrip("\n").split("\t")
            cwes = set(p[4].split(";")) if len(p) > 4 and p[4] else set()
            fid_is_ac[p[0]] = bool(cwes & AC_CWES)


def load_split(split, limit=0):
    graphs = torch.load(os.path.join(DS, split + ".pt"))
    seq_path = os.path.join(DS, "seq_%s.pt" % split)   # prefer dataset-local seq
    if not os.path.isfile(seq_path):
        seq_path = os.path.join(SHARED, "seq_%s.pt" % split)
    seqs = torch.load(seq_path)
    items = []
    for it in graphs:
        s = seqs.get(it["fid"])
        if s is None:
            continue
        if args.ac_only:
            if it["y"] == 1 and not fid_is_ac.get(it["fid"], False):
                continue  # drop non-AC vulnerabilities
            it = dict(it)
            it["y"] = 1 if (it["y"] == 1 and fid_is_ac.get(it["fid"], False)) else 0
        items.append((it, s))
        if limit and len(items) >= limit:
            break
    return items


def collate(batch):
    datas, seqs, ys = [], [], []
    for it, s in batch:
        ei, et = it["edge_index"], it["edge_type"]
        if args.edges == "cdg_ddg":
            m = et >= 2
            ei, et = ei[:, m], et[m] - 2
        d = Data(x=it["x"], edge_index=ei, edge_type=et)
        if args.pcf:
            d.x_flags = it["x_flags"]
        datas.append(d)
        seqs.append(s)
        ys.append(it["y"])
    g = Batch.from_data_list(datas)
    seq = pad_sequence(seqs, batch_first=True, padding_value=0)
    y = torch.tensor(ys, dtype=torch.float)
    return g, seq, y


class FusionModel(nn.Module):
    def __init__(self, V, D, channels, num_rel, dropout, flag_dim=0):
        super().__init__()
        self.channels = channels
        self.flag_dim = flag_dim
        self.emb = nn.Embedding(V, D, padding_idx=0)
        self.drop = nn.Dropout(dropout)
        if channels in ("both", "seq"):
            self.lstm = nn.LSTM(D, D, batch_first=True, bidirectional=True)
            self.proj_s = nn.Linear(2 * D, D)
        if channels in ("both", "gnn"):
            self.conv1 = RGCNConv(D + flag_dim, D, num_relations=num_rel)
            self.conv2 = RGCNConv(D, D, num_relations=num_rel)
        if channels == "both":
            self.cross = nn.MultiheadAttention(D, num_heads=4, batch_first=True,
                                               dropout=dropout)
            head_in = 3 * D
        else:
            head_in = D
        self.head = nn.Sequential(
            nn.Linear(head_in, D), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(D, 1))

    def forward(self, g, seq):
        feats = []
        if self.channels in ("both", "seq"):
            smask = seq.ne(0)                                     # (B,T)
            hs, _ = self.lstm(self.drop(self.emb(seq)))
            hs = self.proj_s(hs)                                  # (B,T,D)
            denom = smask.sum(1, keepdim=True).clamp(min=1)
            seq_mean = (hs * smask.unsqueeze(-1)).sum(1) / denom  # (B,D)
        if self.channels in ("both", "gnn"):
            hn = self.drop(self.emb(g.x))
            if self.flag_dim:
                hn = torch.cat([hn, g.x_flags], dim=-1)
            hn = self.conv1(hn, g.edge_index, g.edge_type).relu()
            hn = self.conv2(hn, g.edge_index, g.edge_type).relu()
            graph_mean = global_mean_pool(hn, g.batch)            # (B,D)
        if self.channels == "both":
            dense, nmask = to_dense_batch(hn, g.batch)            # (B,Nmax,D)
            fused, _ = self.cross(hs, dense, dense,
                                  key_padding_mask=~nmask)
            fused_mean = (fused * smask.unsqueeze(-1)).sum(1) / denom
            feats = [fused_mean, seq_mean, graph_mean]
        elif self.channels == "gnn":
            feats = [graph_mean]
        else:
            feats = [seq_mean]
        return self.head(torch.cat(feats, dim=-1)).squeeze(-1)


def evaluate(model, items, batch_size):
    model.eval()
    probs, ys = [], []
    with torch.no_grad():
        for i in range(0, len(items), batch_size):
            g, seq, y = collate(items[i:i + batch_size])
            out = model(g.to(dev), seq.to(dev))
            probs.append(torch.sigmoid(out).cpu())
            ys.append(y)
    prob = torch.cat(probs).numpy()
    y = torch.cat(ys).numpy()
    pred = (prob > 0.5).astype(int)
    # best-F1 threshold sweep
    best_f1, best_t = 0.0, 0.5
    for t in np.linspace(0.05, 0.95, 19):
        f = f1_score(y, (prob > t).astype(int), zero_division=0)
        if f > best_f1:
            best_f1, best_t = f, float(t)
    return {
        "pr_auc": float(average_precision_score(y, prob)),
        "roc_auc": float(roc_auc_score(y, prob)),
        "f1@0.5": float(f1_score(y, pred, zero_division=0)),
        "p@0.5": float(precision_score(y, pred, zero_division=0)),
        "r@0.5": float(recall_score(y, pred, zero_division=0)),
        "mcc@0.5": float(matthews_corrcoef(y, pred)),
        "best_f1": best_f1, "best_t": best_t,
    }, prob, y


train_items = load_split("train", args.limit)
val_items = load_split("validation", args.limit // 5 if args.limit else 0)
test_items = load_split("test")
n_pos = sum(it["y"] for it, _ in train_items)
pos_weight = (len(train_items) - n_pos) / max(n_pos, 1)
print("train=%d (pos=%d, pos_weight=%.1f) val=%d test=%d"
      % (len(train_items), n_pos, pos_weight, len(val_items), len(test_items)))

model = FusionModel(V, args.dim, args.channels,
                    2 if args.edges == "cdg_ddg" else 4, args.dropout,
                    flag_dim=FLAG_DIM).to(dev)
print("params:", sum(t.numel() for t in model.parameters()))
opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-4)
crit = nn.BCEWithLogitsLoss(pos_weight=torch.tensor(pos_weight, device=dev))

best_val, best_state, bad = -1.0, None, 0
for epoch in range(1, args.epochs + 1):
    model.train()
    random.shuffle(train_items)
    t0, tot = time.time(), 0.0
    for i in range(0, len(train_items), args.batch):
        g, seq, y = collate(train_items[i:i + args.batch])
        opt.zero_grad()
        loss = crit(model(g.to(dev), seq.to(dev)), y.to(dev))
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        tot += float(loss) * len(y)
    vm, _, _ = evaluate(model, val_items, args.batch)
    print("EPOCH %02d loss=%.4f val_pr_auc=%.4f val_f1@0.5=%.4f best_f1=%.4f(t=%.2f) %.0fs"
          % (epoch, tot / len(train_items), vm["pr_auc"], vm["f1@0.5"],
             vm["best_f1"], vm["best_t"], time.time() - t0), flush=True)
    if vm["pr_auc"] > best_val:
        best_val, bad = vm["pr_auc"], 0
        best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        best_thresh = vm["best_t"]
    else:
        bad += 1
        if bad >= args.patience:
            print("early stop at epoch", epoch)
            break

model.load_state_dict(best_state)
val_m, _, _ = evaluate(model, val_items, args.batch)
test_m, prob, y = evaluate(model, test_items, args.batch)
pred_t = (prob > best_thresh).astype(int)
test_m["f1@val_t"] = float(f1_score(y, pred_t, zero_division=0))
test_m["p@val_t"] = float(precision_score(y, pred_t, zero_division=0))
test_m["r@val_t"] = float(recall_score(y, pred_t, zero_division=0))
test_m["mcc@val_t"] = float(matthews_corrcoef(y, pred_t))
test_m["val_t"] = best_thresh

result = {"config": vars(args), "val": val_m, "test": test_m}
with open(os.path.join(outdir, "metrics.json"), "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
torch.save(best_state, os.path.join(outdir, "model.pt"))
# per-sample test probabilities for downstream subset analyses (e.g. per-CWE)
np.savez(os.path.join(outdir, "test_probs.npz"),
         fids=np.array([it["fid"] for it, _ in test_items]),
         prob=prob, y=y, val_t=best_thresh)
print("TEST:", json.dumps(test_m, indent=2))
print("RESULT SAVED ->", outdir)
