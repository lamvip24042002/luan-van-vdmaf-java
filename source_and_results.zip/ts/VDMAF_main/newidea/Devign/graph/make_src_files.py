# -*- coding: utf-8 -*-
# Write each Devign function to its own .c file so Joern c2cpg can parse them.
# Usage: python make_src_files.py [n_sample]
#   n_sample > 0  -> write only the first n functions into sample_src/
#   no argument   -> write everything into src_batches/batch_XX/ (3000 files each)
import json
import os
import sys

n_sample = int(sys.argv[1]) if len(sys.argv) > 1 else 0

with open('../dataset/function', 'r', encoding='utf-8') as f:
    data = json.load(f)

if n_sample:
    data = data[:n_sample]
    outroot = 'sample_src'
    batch = n_sample
else:
    outroot = 'src_batches'
    batch = 3000

for i, r in enumerate(data):
    d = os.path.join(outroot, "batch_%02d" % (i // batch))
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "func_%d.c" % i), 'w', encoding='utf-8') as fp:
        fp.write(r["func"])

print("wrote", len(data), "files under", outroot)
