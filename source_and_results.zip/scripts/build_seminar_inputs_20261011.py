"""Build controlled all-splits/train-only seminar inputs without touching old data.

The historical policy is preserved: graph counts precede the 2,000-node cap;
sequence counts precede last-200 truncation; graph IDs are assigned before the
sequence vocabulary extends the shared table. No original builder is imported.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import time

import numpy as np
import pandas as pd
import torch


SPLITS = ("train", "validation", "test")
EDGE_TYPES = {"AST": 0, "CFG": 1, "CDG": 2, "REACHING_DEF": 3}
SKIP_METHODS = {"<init>", "<clinit>"}
MIN_COUNT = 5
MAX_NODES = 2000
MAXLEN = 200
TOKEN_RE = re.compile(
    r'[A-Za-z_$][A-Za-z0-9_$]*'
    r'|\d+\.?\d*[fFdDlL]?'
    r'|"(?:\\.|[^"\\])*"'
    r"|'(?:\\.|[^'\\])*'"
    r'|==|!=|<=|>=|&&|\|\||\+\+|--|<<=|>>=|<<|>>>|>>'
    r'|\+=|-=|\*=|/=|%=|&=|\|=|\^=|->|::'
    r'|[{}()\[\];,.<>+\-*/%=!&|^~?:@]'
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path: Path, value) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def read_labels(path: Path) -> dict:
    labels = {}
    with path.open(encoding="utf-8") as handle:
        next(handle)
        for line in handle:
            fields = line.rstrip("\n").split("\t")
            fid, split, y = fields[0], fields[1], int(fields[2])
            if fid in labels or split not in SPLITS or y not in (0, 1):
                raise ValueError(f"Invalid or duplicate label row: {fid}")
            labels[fid] = (split, y)
    return labels


def iter_methods(paths):
    """Preserve sorted-dump order and each original method/node/edge order."""
    for path in paths:
        name, fid, nodes, edges = None, None, {}, []
        with path.open(encoding="utf-8") as handle:
            for line in handle:
                fields = line.rstrip("\n").split("\t")
                if line.startswith("#M"):
                    if name is not None:
                        yield fid, name, nodes, edges
                    base = fields[2].replace("\\", "/").rsplit("/", 1)[-1]
                    name = fields[1]
                    fid = base[:-5] if base.endswith(".java") else None
                    nodes, edges = {}, []
                elif line.startswith("N"):
                    nodes[fields[1]] = fields[2]
                elif line.startswith("E"):
                    edges.append((fields[1], fields[2], fields[3]))
        if name is not None:
            yield fid, name, nodes, edges


def count_graph_tokens(paths, labels):
    counters = {scope: Counter() for scope in ("all", "train")}
    for fid, name, nodes, _ in iter_methods(paths):
        if fid not in labels or name in SKIP_METHODS:
            continue
        counters["all"].update(nodes.values())
        if labels[fid][0] == "train":
            counters["train"].update(nodes.values())
    return counters


def make_vocab(counter, min_count=MIN_COUNT):
    vocab = {"<pad>": 0, "<unk>": 1}
    for token, count in counter.most_common():
        if count >= min_count:
            # Reserved symbols cannot be produced as single tokens by this policy.
            if token in vocab:
                raise ValueError(f"Unexpected reserved token in source: {token!r}")
            vocab[token] = len(vocab)
    return vocab


def extend_vocab(graph_vocab, sequence_counter, min_count=MIN_COUNT):
    vocab = dict(graph_vocab)
    for token, count in sequence_counter.most_common():
        if count >= min_count and token not in vocab:
            vocab[token] = len(vocab)
    return vocab


def encode_graphs(paths, labels, vocab, max_nodes=MAX_NODES):
    graphs = {}
    for fid, name, nodes, edges in iter_methods(paths):
        if fid not in labels or name in SKIP_METHODS:
            continue
        graph = graphs.setdefault(fid, {"tokens": [], "edges": [], "id2idx": {}})
        id2idx = graph["id2idx"]
        for nid, token in nodes.items():
            if nid not in id2idx and len(graph["tokens"]) < max_nodes:
                id2idx[nid] = len(graph["tokens"])
                graph["tokens"].append(vocab.get(token, 1))
        for src, dst, relation in edges:
            si, di = id2idx.get(src), id2idx.get(dst)
            if si is not None and di is not None:
                graph["edges"].append((si, di, EDGE_TYPES[relation]))
    data = {split: [] for split in SPLITS}
    skipped = {split: [] for split in SPLITS}
    for fid, (split, label) in labels.items():
        graph = graphs.pop(fid, None)
        if graph is None or not graph["tokens"] or not graph["edges"]:
            skipped[split].append(fid)
            continue
        edge_tensor = torch.tensor(graph["edges"], dtype=torch.long)
        data[split].append({
            "fid": fid,
            "x": torch.tensor(graph["tokens"], dtype=torch.long),
            "edge_index": edge_tensor[:, :2].t().contiguous(),
            "edge_type": edge_tensor[:, 2].contiguous(),
            "y": label,
        })
    return data, skipped


def remap_graphs(all_graphs, all_vocab, train_vocab):
    """Train graph vocabulary is a subset; all-splits UNKs remain train UNKs."""
    if not set(train_vocab).issubset(all_vocab):
        raise AssertionError("Train vocabulary is not a subset of all vocabulary")
    mapping = torch.ones(len(all_vocab), dtype=torch.long)
    for token, index in all_vocab.items():
        mapping[index] = train_vocab.get(token, 1)
    return {
        split: [dict(item, x=mapping[item["x"]]) for item in items]
        for split, items in all_graphs.items()
    }


def read_source_frames(java_root, labels):
    frames, files = [], []
    for split in SPLITS:
        path = java_root / "megavul" / f"{split}-00000-of-00001.parquet"
        frame = pd.read_parquet(path, columns=["input", "is_vulnerable"])
        frame["split"] = split
        frames.append(frame)
        files.append(path)
    frame = pd.concat(frames, ignore_index=True)
    frame["fid"] = [f"F{index:06d}" for index in range(len(frame))]
    for row in frame.itertuples(index=False):
        if not isinstance(row.input, str):
            raise TypeError(f"Non-string source: {row.fid}")
        if labels.get(row.fid) != (row.split, int(row.is_vulnerable)):
            raise AssertionError(f"Parquet/label mismatch: {row.fid}")
    if set(frame["fid"]) != set(labels):
        raise AssertionError("Parquet and labels have different function IDs")
    return frame, files


def count_sequence_tokens(frame):
    counters = {scope: Counter() for scope in ("all", "train")}
    for row in frame.itertuples(index=False):
        tokens = TOKEN_RE.findall(row.input)
        counters["all"].update(tokens)
        if row.split == "train":
            counters["train"].update(tokens)
    return counters


def make_sequence_items(frame, joint_vocabs, maxlen=MAXLEN):
    seqs = {scope: {split: {} for split in SPLITS} for scope in joint_vocabs}
    lengths, truncated = [], Counter()
    for row in frame.itertuples(index=False):
        tokens = TOKEN_RE.findall(row.input)
        lengths.append(len(tokens))
        truncated[row.split] += int(len(tokens) > maxlen)
        for scope, vocab in joint_vocabs.items():
            ids = [vocab.get(token, 1) for token in tokens][-maxlen:] or [1]
            seqs[scope][row.split][row.fid] = torch.tensor(ids, dtype=torch.long)
    return seqs, {
        "pre_truncation_length_quantiles": {
            str(q): float(np.quantile(lengths, q)) for q in (0, 0.5, 0.9, 0.99, 1)
        },
        "truncated_functions_by_split": dict(truncated),
    }


def unknown_stats(tensors):
    tensors = list(tensors)
    total = sum(tensor.numel() for tensor in tensors)
    unknowns = [int(tensor.eq(1).sum()) for tensor in tensors]
    unknown = sum(unknowns)
    affected = sum(count > 0 for count in unknowns)
    return {
        "samples": len(tensors), "token_occurrences": total,
        "unk_occurrences": unknown, "unk_token_rate": unknown / total if total else 0,
        "samples_with_unk": affected,
        "sample_with_unk_rate": affected / len(tensors) if tensors else 0,
    }


def assert_scope_invariants(graphs, seqs, vocabs, graph_vocabs):
    for scope in ("all", "train"):
        vocab = vocabs[scope]
        assert vocab["<pad>"] == 0 and vocab["<unk>"] == 1
        assert sorted(vocab.values()) == list(range(len(vocab)))
        assert all(vocab[token] == index for token, index in graph_vocabs[scope].items())
        for split in SPLITS:
            for item in graphs[scope][split]:
                assert item["fid"] in seqs[scope][split]
                assert 0 <= int(item["x"].min()) <= int(item["x"].max()) < len(graph_vocabs[scope])
                assert item["edge_index"].shape[0] == 2
                assert item["edge_index"].shape[1] == item["edge_type"].numel()
                assert 0 <= int(item["edge_index"].min()) <= int(item["edge_index"].max()) < item["x"].numel()
            for ids in seqs[scope][split].values():
                assert 0 <= int(ids.min()) <= int(ids.max()) < len(vocab)
    for split in SPLITS:
        left, right = graphs["all"][split], graphs["train"][split]
        assert len(left) == len(right)
        for a, b in zip(left, right):
            assert a["fid"] == b["fid"] and a["y"] == b["y"]
            assert a["x"].shape == b["x"].shape
            assert torch.equal(a["edge_index"], b["edge_index"])
            assert torch.equal(a["edge_type"], b["edge_type"])
        assert list(seqs["all"][split]) == list(seqs["train"][split])
        assert all(seqs["all"][split][fid].shape == seqs["train"][split][fid].shape
                   for fid in seqs["all"][split])
    return {"same_fids_labels_node_counts_edge_order_and_types": True,
            "same_sequence_fids_and_lengths": True,
            "valid_contiguous_pad_unk_vocabs_and_tensor_ids": True,
            "graph_vocab_ids_preserved_in_joint_vocab": True}


def duplicate_audit(frame):
    codes = {split: {} for split in SPLITS}
    for row in frame.itertuples(index=False):
        codes[row.split].setdefault(row.input, []).append((row.fid, int(row.is_vulnerable)))
    pairs = {}
    for first, second in (("train", "validation"), ("train", "test"), ("validation", "test")):
        shared = set(codes[first]) & set(codes[second])
        pairs[f"{first}__{second}"] = {
            "unique_shared_codes": len(shared),
            f"{first}_rows": sum(len(codes[first][code]) for code in shared),
            f"{second}_rows": sum(len(codes[second][code]) for code in shared),
            f"{second}_positive_rows": sum(y for code in shared for _, y in codes[second][code]),
        }
    known = set(codes["train"]) | set(codes["validation"])
    retained, excluded = [], []
    for row in frame[frame["split"] == "test"].itertuples(index=False):
        (excluded if row.input in known else retained).append((row.fid, int(row.is_vulnerable)))
    audit = {
        "policy": "Exact input string equality; no whitespace normalization; primary splits unchanged",
        "pairs": pairs,
        "test_excluding_exact_train_or_validation": {
            "retained_samples": len(retained), "retained_positive": sum(y for _, y in retained),
            "excluded_samples": len(excluded), "excluded_positive": sum(y for _, y in excluded),
            "excluded_fids": [fid for fid, _ in excluded],
        },
        "caveat": "Post-training sensitivity subset, not a new deduplicated split or project/time-disjoint evaluation",
    }
    return audit, [fid for fid, _ in retained]


def build(root: Path, output: Path):
    started = time.perf_counter()
    java_root = root / "ts" / "VDMAF_main" / "newidea" / "Java"
    label_path = java_root / "graph" / "labels_all.tsv"
    dumps = sorted((java_root / "graph" / "dumps_v2").glob("graph_batch_*.txt"))
    if not dumps:
        raise FileNotFoundError("No graph dumps found")
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f"Refusing to overwrite nonempty output: {output}")
    labels = read_labels(label_path)
    frame, parquets = read_source_frames(java_root, labels)
    print("Counting graph tokens from fixed dumps...", flush=True)
    graph_counters = count_graph_tokens(dumps, labels)
    graph_vocabs = {scope: make_vocab(counter) for scope, counter in graph_counters.items()}
    print("Counting full source sequences...", flush=True)
    seq_counters = count_sequence_tokens(frame)
    joint_vocabs = {scope: extend_vocab(graph_vocabs[scope], seq_counters[scope]) for scope in ("all", "train")}
    historical_vocab_checks = {}
    historical_vocab_paths = []
    for filename, vocabulary in (("vocab.json", graph_vocabs["all"]),
                                 ("vocab_joint.json", joint_vocabs["all"])):
        historical_path = java_root / "gnn" / "dataset" / filename
        if historical_path.is_file():
            historical = json.loads(historical_path.read_text(encoding="utf-8"))
            if historical != vocabulary:
                raise AssertionError(f"All-splits control differs from historical {filename}")
            historical_vocab_checks[filename] = {"identical_mapping": True, "size": len(vocabulary)}
            historical_vocab_paths.append(historical_path)
    print("Encoding shared graph topology...", flush=True)
    graph_all, skipped = encode_graphs(dumps, labels, graph_vocabs["all"])
    graphs = {"all": graph_all, "train": remap_graphs(graph_all, graph_vocabs["all"], graph_vocabs["train"])}
    seqs, seq_length_stats = make_sequence_items(frame, joint_vocabs)
    invariants = assert_scope_invariants(graphs, seqs, joint_vocabs, graph_vocabs)
    duplicates, clean_fids = duplicate_audit(frame)
    usable_test_fids = {item["fid"] for item in graph_all["test"]}
    clean_usable_fids = [fid for fid in clean_fids if fid in usable_test_fids]
    source_files = [label_path, *parquets, *dumps, *historical_vocab_paths, Path(__file__).resolve()]
    sources = [{"path": str(path.resolve()), "sha256": sha256(path), "bytes": path.stat().st_size}
               for path in source_files]
    output.mkdir(parents=True, exist_ok=True)
    write_json(output / "duplicate_audit.json", duplicates)
    write_json(output / "test_exact_disjoint_fids.json", clean_usable_fids)
    write_json(output / "invariants.json", invariants)
    manifests = {}
    for scope in ("all", "train"):
        directory = output / scope
        directory.mkdir()
        write_json(directory / "vocab.json", graph_vocabs[scope])
        write_json(directory / "vocab_joint.json", joint_vocabs[scope])
        split_stats = {}
        for split in SPLITS:
            items, sequences = graphs[scope][split], seqs[scope][split]
            torch.save(items, directory / f"{split}.pt")
            torch.save(sequences, directory / f"seq_{split}.pt")
            split_stats[split] = {
                "source_functions": int((frame["split"] == split).sum()),
                "model_samples": len(items), "model_positive": sum(item["y"] for item in items),
                "skipped_empty_graph_fids": skipped[split],
                "graph_used_input": unknown_stats(item["x"] for item in items),
                "sequence_used_input": unknown_stats(sequences[item["fid"]] for item in items),
                "sequence_all_source_functions": unknown_stats(sequences.values()),
                "graphs_at_node_cap": sum(item["x"].numel() == MAX_NODES for item in items),
                "edges_by_type": {name: sum(int(item["edge_type"].eq(index).sum()) for item in items)
                                  for name, index in EDGE_TYPES.items()},
            }
        stats = {"vocab_scope": scope, "graph_vocab_size": len(graph_vocabs[scope]),
                 "joint_vocab_size": len(joint_vocabs[scope]), "splits": split_stats,
                 "sequence_lengths": seq_length_stats}
        write_json(directory / "stats.json", stats)
        artifacts = {path.name: {"sha256": sha256(path), "bytes": path.stat().st_size}
                     for path in sorted(directory.iterdir())}
        manifest = {
            "schema_version": 1, "created_utc": datetime.now(timezone.utc).isoformat(),
            "vocab_scope": scope, "root": str(root), "directory": str(directory),
            "policy": {"min_count": MIN_COUNT, "max_nodes": MAX_NODES, "max_sequence_length": MAXLEN,
                       "sequence_truncation": "keep_last", "graph_counts_before_cap": True,
                       "sequence_counts_before_truncation": True, "graph_encoded_before_joint_extension": True,
                       "pcf_flags": False, "normalization": "unchanged historical case-sensitive tokenization",
                       "graph_order": "sorted dump paths; original method/node/edge order; label-file sample order",
                       "reserved_tokens": {"<pad>": 0, "<unk>": 1}},
            "vocab_size": len(joint_vocabs[scope]), "graph_vocab_size": len(graph_vocabs[scope]),
            "splits": {split: {"samples": len(graphs[scope][split]),
                               "positive": sum(item["y"] for item in graphs[scope][split])} for split in SPLITS},
            "invariants": invariants, "historical_all_vocab_checks": historical_vocab_checks,
            "sources": sources, "artifacts": artifacts,
            "duplicate_audit": "../duplicate_audit.json", "test_exact_disjoint_fids": "../test_exact_disjoint_fids.json",
            "runtime": {"torch": torch.__version__, "pandas": pd.__version__, "numpy": np.__version__},
        }
        write_json(directory / "manifest.json", manifest)
        manifests[scope] = {"path": str(directory / "manifest.json"),
                            "sha256": sha256(directory / "manifest.json")}
        print(f"{scope}: graph vocab {len(graph_vocabs[scope])}, joint {len(joint_vocabs[scope])}", flush=True)
    write_json(output / "build_manifest.json", {"scopes": manifests, "invariants": invariants,
               "elapsed_seconds": time.perf_counter() - started, "exact_disjoint_test_samples": len(clean_usable_fids)})
    print(f"Saved controlled inputs to {output} in {time.perf_counter() - started:.1f}s", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output", type=Path, help="Default: ROOT/output/seminar_20261011/inputs")
    args = parser.parse_args()
    root = args.root.resolve()
    output = args.output.resolve() if args.output else root / "output" / "seminar_20261011" / "inputs"
    build(root, output)


if __name__ == "__main__":
    main()
