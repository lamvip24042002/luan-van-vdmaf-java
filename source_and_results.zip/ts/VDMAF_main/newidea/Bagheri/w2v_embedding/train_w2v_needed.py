# -*- coding: utf-8 -*-
# Train only the word2vec model that train_model/makemodel.py loads:
#   ../model/<mode>/word2vec_withString5-100-300.model
# Same preprocessing as train_w2vmodel.py. Reads the corpus file written by
# get_corpus.py (corpus/corpus_withString<mode>).
# Usage: python train_w2v_needed.py [mode]   (default: sql)
import os
import os.path
import pickle
import sys
import nltk
from gensim.models import Word2Vec

newmode = sys.argv[1] if len(sys.argv) > 1 else "sql"

print("Loading corpus for", newmode)
with open('corpus/corpus_withString' + newmode, 'r', encoding="utf-8") as f:
    pythondata = f.read().lower().replace('\n', ' ')
print("corpus chars:", len(pythondata))

cache = 'processed_data/pythoncorpus_processed_withString_' + newmode
if os.path.isfile(cache):
    with open(cache, 'rb') as fp:
        all_words = pickle.load(fp)
    print("loaded processed corpus.")
else:
    print("tokenizing...")
    all_sentences = nltk.sent_tokenize(pythondata)
    all_words = [nltk.word_tokenize(sent) for sent in all_sentences]
    with open(cache, 'wb') as fp:
        pickle.dump(all_words, fp)
print("sentences:", len(all_words))

outdir = "../model/" + newmode
os.makedirs(outdir, exist_ok=True)
fname = outdir + "/word2vec_withString5-100-300.model"
if os.path.isfile(fname):
    print("model already exists.")
else:
    print("training w2v (min_count=5, epochs=100, size=300)...")
    model = Word2Vec(all_words, vector_size=300, min_count=5, epochs=100,
                     workers=6)
    print("vocab:", len(model.wv.key_to_index))
    model.save(fname)
    print("saved ->", fname)
