# Báo cáo các thay đổi trong mã nguồn so với bản gốc

Tài liệu này liệt kê mọi thay đổi đã thực hiện trên **mã nguồn artifact gốc của VDMAF** và
mọi phần **mã nguồn mới tự viết** (do artifact không kèm), kèm nguyên nhân. Mục tiêu là để
thầy hướng dẫn thấy rõ: (a) baseline tái lập vẫn **trung thực** với phương pháp gốc, (b)
những chỗ nào là **sửa lỗi bắt buộc** để chạy được, (c) những chỗ nào là **bổ sung mới**
thuộc đóng góp của luận văn.

**Phân loại mức độ ảnh hưởng (cột "Loại"):**
- **[A] Sửa để chạy được** — mã gốc bị crash/không chạy; sửa tối thiểu, KHÔNG đổi phương pháp.
- **[B] Sửa lỗi làm baseline trung thực hơn** — mã gốc có lỗi ngầm bóp méo kết quả; sửa cho
  đúng mô tả bài báo. Cần nêu rõ trong luận văn vì làm baseline MẠNH hơn bản buggy.
- **[C] Tối ưu tương đương toán học** — đổi cách hiện thực nhưng kết quả giống hệt (ví dụ
  RAM). KHÔNG ảnh hưởng số liệu.
- **[D] Bổ sung mới** — mã luận văn tự viết, không có trong artifact.

---

## PHẦN 1 — THAY ĐỔI TRÊN MÃ NGUỒN ARTIFACT GỐC CỦA VDMAF

### 1.1. Sửa import không tương thích phiên bản — [A]
- **File:** `*/makemodel.py`, `*/myutils.py` (mọi thư mục dataset: Devign, Reveal, Bagheri).
- **Gốc:** `from keras.preprocessing import sequence`.
- **Sửa thành:** `from tensorflow.keras.preprocessing import sequence`.
- **Nguyên nhân:** artifact viết cho TensorFlow 2.6; luận văn chạy trên TF 2.10 (bản TF cuối
  cùng hỗ trợ GPU gốc trên Windows). Ở Keras 2.10, `keras.preprocessing.sequence` không còn
  hàm `pad_sequences`, gây `ImportError`. Đây thuần túy là vấn đề tương thích phiên bản,
  không đụng đến logic mô hình.

### 1.2. Sửa kích thước đầu vào mô hình — [A]
- **File:** `*/makemodel.py`.
- **Gốc:** `input_shape=(200, 600)` (Bagheri: `(100, 600)`).
- **Sửa thành:** `(200, 300)` (Bagheri: `(100, 300)`).
- **Nguyên nhân:** vector fusion sau multi-head attention có số chiều `d_model=300`, nhưng
  mã gốc hard-code 600. Nếu giữ 600, mô hình không khớp chiều dữ liệu và crash. 300 là con
  số ĐÚNG theo chính cấu hình `d_model` của bài báo — đây là sửa lỗi hard-code, không đổi
  phương pháp.

### 1.3. Sửa lỗi crash `EagerTensor.tolist()` + tra cứu O(n) — [A]
- **File:** `Devign/code/makemodel.py`, `Bagheri/train_model/makemodel.py`.
- **Gốc:** gọi `.tolist()` trên EagerTensor của TF (không có phương thức này ở TF 2.10) →
  crash; đồng thời dùng `list(common_tokens).index(token)` tra cứu tuyến tính trong vòng lặp.
- **Sửa thành:** chuyển tensor sang numpy trước (`np.array(...)`), và thay tra cứu bằng
  từ điển `common_tokens_index = {t: i for i, t in enumerate(common_tokens)}`.
- **Nguyên nhân:** (i) sửa crash bắt buộc; (ii) tra cứu bằng dict cho kết quả GIỐNG HỆT tra
  cứu `list.index` nhưng nhanh hơn nhiều (O(1) thay vì O(n)) — không đổi số liệu, chỉ đổi
  tốc độ.

### 1.4. Loại bỏ debug leftover cắt cụt dữ liệu — [B] (QUAN TRỌNG, cần nêu trong luận văn)
- **File:** `Reveal/code/get_corpus.py` (và vòng lặp nạp dữ liệu trong `makemodel.py`).
- **Gốc:** corpus xây dựng cho word2vec có bộ lọc sót lại từ quá trình gỡ lỗi: chỉ lấy đoạn
  code `len(code) <= 200` ký tự và giới hạn 40.000 mẫu (`== 4000` cap + biến đếm không
  reset).
- **Sửa thành:** bỏ các bộ lọc này, dùng toàn bộ dữ liệu.
- **Nguyên nhân:** với bộ lọc gốc, từ vựng word2vec thực tế chỉ còn **1.063 token** — làm
  suy yếu nghiêm trọng kênh ngữ nghĩa. Sau khi sửa, từ vựng đầy đủ **43.254 token**. Đây là
  lỗi ngầm khiến baseline gốc yếu hơn thực chất; sửa để baseline phản ánh ĐÚNG năng lực
  phương pháp như bài báo mô tả. **Phải ghi rõ trong luận văn** vì nó làm baseline mạnh lên.
- **Truy vết:** artifact cũ được lưu lại dưới tên `*_v1*` trong `Reveal/code/` để đối chiếu;
  số liệu buggy (F1 34,2) so với số liệu sau sửa (F1 31,8) đều lưu trong
  `baseline_metrics_reveal_v1.json` và `baseline_metrics_reveal.json`.

### 1.5. Bật lại `class_weight` bị comment — [B]
- **File:** `Reveal/code/makemodel.py`, `Bagheri/train_model/makemodel.py`.
- **Gốc:** dòng `class_weight=class_weights_dict` trong `model.fit(...)` bị chú thích (tắt).
- **Sửa thành:** bật lại tham số này.
- **Nguyên nhân:** dữ liệu mất cân bằng nặng; nếu không có trọng số lớp, mô hình sụp về dự
  đoán toàn nhãn âm (recall = 0), không phản ánh đúng phương pháp. Bản thân mã gốc đã TÍNH
  sẵn `class_weights_dict` (chứng tỏ ý định dùng), chỉ vô tình comment dòng áp dụng.

### 1.6. Nạp lại split đã lưu để so sánh nhất quán — [B]
- **File:** `Devign/code/makemodel.py`, `Bagheri/train_model/makemodel.py`.
- **Gốc:** mỗi lần chạy đều `random.shuffle` rồi chia train/val/test mới, dù có lưu file
  `key_data/*.npy`.
- **Sửa thành:** nếu file split đã tồn tại thì nạp lại (`np.load`), chỉ tạo mới khi chưa có.
- **Nguyên nhân:** để mọi thí nghiệm (baseline, các biến thể) chạy trên CÙNG một cách chia
  tập, đảm bảo so sánh công bằng — nguyên tắc bắt buộc rút ra từ bài phê bình Reveal [tài
  liệu tham khảo trong luận văn].

### 1.7. Ghi cố định hạt giống ngẫu nhiên — [B]
- **File:** `Devign/code/makemodel.py`, `Bagheri/train_model/makemodel.py`.
- **Gốc:** không đặt seed → fusion multi-head attention (khởi tạo ngẫu nhiên) khác nhau mỗi
  lần chạy.
- **Sửa thành:** `random.seed(42)`, `np.random.seed(42)`, `tf.random.set_seed(42)`.
- **Nguyên nhân:** vì fusion của artifact dùng trọng số ngẫu nhiên cố định (chính là khiếm
  khuyết mà luận văn phân tích), cần cố định seed để kết quả tái lập được. Ở phần so sánh
  trước/sau (Chương 5.4), seed còn được tham số hóa để chạy đa seed.

### 1.8. Viết lại cách nạp dữ liệu để an toàn RAM — [C] (tương đương toán học)
- **File:** `Devign/code/makemodel.py`, `Bagheri/train_model/makemodel.py`, và bản artifact
  chạy lại trên Java (`Java/baseline_vdmaf/makemodel_megavul.py`).
- **Gốc:** tiền tính vector kết hợp 300 chiều cho từng token rồi lưu dưới dạng danh sách
  Python lồng nhau (`vectorlist.append(combined_vector.tolist())`), tạo tensor dày đặc
  `(n_mẫu, 200, 300)`.
- **Sửa thành:** mỗi mẫu là **chuỗi chỉ số token int32**; việc tra vector chuyển vào một lớp
  `Embedding` đông cứng (`trainable=False`) khởi tạo bằng đúng bảng vector fusion.
- **Nguyên nhân:** với Devign (27.318 hàm), cách gốc cần **30–40GB RAM**, vượt quá 32GB của
  máy và **từng gây treo toàn hệ thống**. Cách mới cho kết quả **hoàn toàn tương đương về
  mặt toán học** (cùng vector đầu vào cho LSTM) nhưng chỉ tốn < 100MB RAM. **Không ảnh hưởng
  số liệu**, chỉ ảnh hưởng tài nguyên. Đây là một đóng góp kỹ thuật tái sử dụng được, trình
  bày ở Chương 4.5 của luận văn.

### 1.9. Ghi chú về "DWCE loss" — KHÔNG sửa, chỉ phân tích
- **File:** `*/makemodel.py` (hàm `dynamic_weighted_binary_crossentropy`).
- **Hiện trạng:** giữ nguyên mã gốc. Qua phân tích, hàm này tính
  `pos_w*BCE + neg_w*BCE` với `pos_w + neg_w = 1`, tức **tương đương hoàn toàn với BCE
  thường** — không có trọng số hóa nào diễn ra.
- **Nguyên nhân giữ nguyên:** đây là một trong 4 khiếm khuyết được PHÂN TÍCH (không sửa) để
  làm động cơ nghiên cứu ở Chương 2.3. Mô hình đề xuất mới dùng `BCEWithLogits` có
  `pos_weight` thực sự.

---

## PHẦN 2 — MÃ NGUỒN MỚI TỰ VIẾT (artifact KHÔNG kèm) — [D]

Đây là các phần đóng góp của luận văn, không phải "sửa" mà là "viết mới" do artifact gốc
thiếu.

### 2.1. Pipeline sinh đồ thị chương trình (thay code upstream bị thiếu)
- **Devign (C):** `Devign/graph/make_src_files.py`, `run_batches.ps1` (gọi Joern `c2cpg` +
  `dump_graph.sc`), `build_node2vec.py`.
- **Bagheri (Python):** `Bagheri/graph/build_node2vec_tokens.py` — đồ thị kề token (do
  nguồn VUDENC bị làm phẳng, không parse được thành Python hợp lệ nên không sinh được CPG
  thật; đây là phát hiện đáng ghi trong luận văn).
- **Nguyên nhân:** repo VDMAF công bố **không kèm** code sinh đồ thị (bước Joern→CPG→
  node2vec), cũng không kèm các model node2vec cho Devign/Bagheri. Phải tự viết để tái lập.

### 2.2. Pipeline Java hoàn chỉnh cho mô hình đề xuất
- `Java/graph/export_all.py`, `run_batches_java.ps1`, `dump_graph_java.sc` — sinh CPG/PDG
  cho toàn bộ MegaVul Java (bản v2 có thêm cột `nodeKind`).
- `Java/gnn/build_dataset.py`, `build_seq.py` — dựng tập PyTorch Geometric + kênh chuỗi.
- `Java/gnn/train_v1.py` — mô hình đề xuất (BiLSTM + R-GCN + cross-attention học được).
- `Java/gnn/build_juliet_ac.py` — tập đối chứng Juliet.
- Các script phân tích: `aggregate_multiseed.py`; script vẽ hình `make_fig1/2/3_*.py`.
- **Nguyên nhân:** toàn bộ là hiện thực hóa phương pháp đề xuất (Chương 3–4), không có
  tương đương trong artifact.

### 2.3. Baseline VDMAF-artifact chạy riêng trên MegaVul Java (`Java/baseline_vdmaf/`)
- **File:** `makemodel_megavul.py`, `export_texts.py`, `train_w2v.py`.
- **Bản chất:** đây KHÔNG phải sửa file gốc nào, mà là **port trung thành** phương pháp
  artifact (giữ nguyên 100%: word2vec viết thường + NLTK, node2vec token-keyed huấn luyện
  từ chính CPG Java đã sinh ở 2.2, MultiHeadAttention **không huấn luyện** + `reduce_sum`,
  BiLSTM 4 lớp, DWCE loss) sang chạy trên dữ liệu MegaVul Java thay vì dữ liệu C gốc.
- **Vì sao phải xây riêng, không tái dùng thẳng `Devign/code/makemodel.py`:** khác nguồn dữ
  liệu (parquet MegaVul thay vì JSON CodeXGLUE) và khác nguồn node2vec (CPG Java thay vì
  CPG C). Mục đích duy nhất: tạo ra vế **"trước"** để so sánh công bằng với mô hình đề xuất
  trên **cùng một dataset, cùng split, cùng seed** (Chương 5.4) — nếu thiếu bước này, so
  sánh trước/sau sẽ khập khiễng vì khác cả mô hình lẫn khác cả dữ liệu.
- Các khác biệt kỹ thuật khác so với artifact gốc (int32+Embedding đông cứng, seed cố định,
  thêm chỉ số PR-AUC/ROC-AUC/ngưỡng-val) là kỹ thuật RAM-safe/đánh giá đã dùng ở Phần 1,
  **không đổi phương pháp**, chỉ thêm chỉ số để so sánh.

### 2.4. Đặc trưng node lấy cảm hứng từ PCFinder (`Java/gnn/build_dataset_v2.py`, `build_juliet_ac.py`)
- **Bản chất:** 4 cờ nhị phân gắn thêm vào mỗi node của đồ thị (`is_credential_like`,
  `is_privileged_op`, `is_interruption`, `flows_from_param`), dùng khi bật cờ `--pcf` của
  `train_v1.py`. Đây là code **hoàn toàn mới**, không sao chép hay sửa bất kỳ file nào của
  PCFinder — PCFinder chỉ được ĐỌC để lấy ý tưởng thiết kế.
- **⚠️ Điểm cần nêu rõ khi báo cáo (giới hạn về tính trung thực của việc tái dựng):** không
  thể lấy đúng bộ luật/từ khóa gốc của PCFinder, vì file
  `PCFinder-main/python/Rules/english_rules.py` trong mã nguồn PCFinder công bố có 4 danh
  sách `verbs`, `nouns`, `owners`, `operations` đều **để trống** (`verbs = []`, v.v.) — bản
  thân tác giả PCFinder cũng không công khai bộ từ khóa cụ thể họ dùng. Do đó, danh sách
  gốc từ credential (`role/pass/permiss` + mở rộng theo ví dụ nêu trong văn bản bài báo như
  `roleId`, `isAdmin`, `secretToken`) và danh sách API đặc quyền (theo tinh thần "42 API
  JDK" mà bài báo mô tả khái quát, không liệt kê đủ 42 API) là **luận văn tự suy diễn** từ
  mô tả bằng lời trong bài báo, có thể không trùng khớp hoàn toàn với bộ luật thật.
- **Hệ quả:** kết luận null ở Chương 5.5 ("đặc trưng PCFinder không cải thiện có ý nghĩa
  thống kê") là kết luận về **bản tái dựng của luận văn**, không phải phép đo trực tiếp trên
  PCFinder gốc. Đã bổ sung cảnh báo này vào luận văn (đầu Mục 5.5 và Mục 6.2 — Hạn chế) để
  tránh gây hiểu nhầm khi trình bày.

### 2.5. Hạ tầng vận hành an toàn
- Các `ram_watchdog*.ps1` / `watchdog_*.ps1` — giám sát RAM, tự dừng tiến trình nếu RAM
  trống < 3GB.
- **Nguyên nhân:** phòng ngừa tái diễn sự cố treo máy (xem 1.8); cho phép chạy các job dài
  qua đêm an toàn.

---

## PHẦN 3 — TÓM TẮT ĐỂ BÁO CÁO

**Về tính trung thực của baseline:** không có thay đổi nào làm baseline YẾU đi một cách
giả tạo. Các sửa loại [A] chỉ để code chạy được trên phiên bản thư viện mới; loại [C] tương
đương toán học. Ba sửa loại [B] (bỏ debug leftover 1.4, bật class_weight 1.5, cố định split
1.6/seed 1.7) đều làm baseline **trung thực và MẠNH hơn** bản artifact có lỗi — nghĩa là mô
hình đề xuất của luận văn đang được so với một baseline **được sửa cho tốt lên**, chứ không
phải một baseline bị dìm. Điều này làm kết quả "+49% PR-AUC" của luận văn càng đáng tin.

**Về khối lượng đóng góp mới [D]:** phần lớn công sức nằm ở mã nguồn tự viết — toàn bộ
pipeline sinh đồ thị (cho cả 3 tập gốc và Java), mô hình đề xuất, baseline artifact chạy
riêng trên Java (2.3), và bộ thí nghiệm/phân tích — do artifact gốc thiếu các thành phần
này.

**Về giới hạn cần chủ động nêu:** riêng phần đặc trưng PCFinder (2.4) là bản **tái dựng**
từ mô tả bài báo (không phải bộ luật gốc, vì `english_rules.py` công bố để trống) — kết
luận null ở Chương 5.5 cần được trình bày đúng phạm vi này, không khái quát thành "PCFinder
không có giá trị" một cách tuyệt đối.

**Truy vết & minh bạch:** các artifact bản cũ được giữ lại để đối chiếu
(`Reveal/code/*_v1*`, `Bagheri/model/sql/node2vec_model-300_cpg_broken.model`); mọi số liệu
trước/sau khi sửa đều lưu trong các file `baseline_metrics_*.json`. Chi tiết đầy đủ từng
phát hiện nằm trong `BASELINE_REPORT.md` và `JAVA_PILOT_REPORT.md`.
