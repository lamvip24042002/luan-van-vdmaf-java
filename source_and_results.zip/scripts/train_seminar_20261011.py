"""Train the seminar ablations from one explicit, immutable dataset directory.

The attention arm preserves the architecture and optimization in train_v1.py.
There is no fallback to the historical vocabulary, no warm start, and no test
threshold search. Selection uses validation AP and a validation F1 threshold.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import platform
import random
import sys
import time
import traceback
from datetime import datetime, timezone

import numpy as np
import sklearn
from sklearn.metrics import (average_precision_score, f1_score,
                             matthews_corrcoef, precision_score,
                             recall_score, roc_auc_score)
import torch
from torch import nn
from torch.nn.utils.rnn import pad_sequence
import torch_geometric
from torch_geometric.data import Batch, Data
from torch_geometric.nn import RGCNConv, global_mean_pool
from torch_geometric.utils import to_dense_batch


SPLITS = ("train", "validation", "test")
EDGE_MODES = {
    "all": (0, 1, 2, 3), "cdg_ddg": (2, 3),
    "no_ast": (1, 2, 3), "no_cfg": (0, 2, 3),
    "no_cdg": (0, 1, 3), "no_ddg": (0, 1, 2),
    "untyped": (0, 1, 2, 3),
}


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def atomic_json(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("w", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def atomic_checkpoint(path, state):
    path = Path(path)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("wb") as handle:
        torch.save(state, handle)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def remap_edges(edge_index, edge_type, mode):
    """Keep nodes even if all their incident edges are removed."""
    if mode == "all":
        return edge_index, edge_type
    if mode == "untyped":
        return edge_index, torch.zeros_like(edge_type)
    mapping = torch.full((4,), -1, dtype=torch.long, device=edge_type.device)
    for new, old in enumerate(EDGE_MODES[mode]):
        mapping[old] = new
    mapped = mapping[edge_type]
    keep = mapped >= 0
    return edge_index[:, keep], mapped[keep]


def relation_count(mode):
    return 1 if mode == "untyped" else len(EDGE_MODES[mode])


def collate(items, edges="all", pcf=False):
    graphs, sequences, labels = [], [], []
    for item, sequence in items:
        edge_index, edge_type = remap_edges(
            item["edge_index"], item["edge_type"], edges)
        graph = Data(x=item["x"], edge_index=edge_index, edge_type=edge_type)
        if pcf:
            graph.x_flags = item["x_flags"]
        graphs.append(graph)
        sequences.append(sequence)
        labels.append(item["y"])
    return (Batch.from_data_list(graphs),
            pad_sequence(sequences, batch_first=True, padding_value=0),
            torch.tensor(labels, dtype=torch.float))


class FusionModel(nn.Module):
    def __init__(self, vocab_size, dim, channels, num_rel, dropout,
                 fusion="attention", flag_dim=0):
        super().__init__()
        self.channels = channels
        self.fusion = fusion
        self.flag_dim = flag_dim
        self.emb = nn.Embedding(vocab_size, dim, padding_idx=0)
        self.drop = nn.Dropout(dropout)
        if channels in ("both", "seq"):
            self.lstm = nn.LSTM(dim, dim, batch_first=True, bidirectional=True)
            self.proj_s = nn.Linear(2 * dim, dim)
        if channels in ("both", "gnn"):
            self.conv1 = RGCNConv(dim + flag_dim, dim, num_relations=num_rel)
            self.conv2 = RGCNConv(dim, dim, num_relations=num_rel)
        if channels == "both" and fusion == "attention":
            self.cross = nn.MultiheadAttention(
                dim, num_heads=4, batch_first=True, dropout=dropout)
            head_in = 3 * dim
        elif channels == "both":
            head_in = 2 * dim
        else:
            head_in = dim
        self.head = nn.Sequential(
            nn.Linear(head_in, dim), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(dim, 1))

    def forward(self, graph, sequence):
        if self.channels in ("both", "seq"):
            mask = sequence.ne(0)
            states, _ = self.lstm(self.drop(self.emb(sequence)))
            states = self.proj_s(states)
            denominator = mask.sum(1, keepdim=True).clamp(min=1)
            sequence_mean = (states * mask.unsqueeze(-1)).sum(1) / denominator
        if self.channels in ("both", "gnn"):
            nodes = self.drop(self.emb(graph.x))
            if self.flag_dim:
                nodes = torch.cat([nodes, graph.x_flags], dim=-1)
            nodes = self.conv1(nodes, graph.edge_index, graph.edge_type).relu()
            nodes = self.conv2(nodes, graph.edge_index, graph.edge_type).relu()
            graph_mean = global_mean_pool(nodes, graph.batch)
        if self.channels == "both" and self.fusion == "attention":
            dense, node_mask = to_dense_batch(nodes, graph.batch)
            fused, _ = self.cross(states, dense, dense,
                                  key_padding_mask=~node_mask)
            fused_mean = (fused * mask.unsqueeze(-1)).sum(1) / denominator
            features = [fused_mean, sequence_mean, graph_mean]
        elif self.channels == "both":
            features = [sequence_mean, graph_mean]
        elif self.channels == "gnn":
            features = [graph_mean]
        else:
            features = [sequence_mean]
        return self.head(torch.cat(features, dim=-1)).squeeze(-1)


def require_ids(tensor, upper, context):
    if tensor.dtype != torch.long or tensor.ndim != 1 or tensor.numel() == 0:
        raise ValueError(f"{context}: expected a nonempty 1D int64 tensor")
    if int(tensor.min()) < 0 or int(tensor.max()) >= upper:
        raise ValueError(f"{context}: token ID outside vocabulary [0, {upper})")


def validate_vocabulary(vocabulary):
    if (not isinstance(vocabulary, dict) or len(vocabulary) < 2
            or any(type(index) is not int for index in vocabulary.values())
            or set(vocabulary.values()) != set(range(len(vocabulary)))):
        raise ValueError("Vocabulary must map tokens to contiguous unique IDs starting at 0")
    if vocabulary.get("<pad>") != 0 or vocabulary.get("<unk>") != 1:
        raise ValueError("Vocabulary must reserve <pad>=0 and <unk>=1")


def verify_manifest_artifacts(directory, manifest, input_hashes):
    """Bind provided provenance to the bytes actually consumed by this run."""
    if "artifacts" not in manifest:
        return
    artifacts = manifest["artifacts"]
    if not isinstance(artifacts, dict):
        raise ValueError("Manifest artifacts must be a filename-to-metadata mapping")
    missing = set(input_hashes) - set(artifacts)
    if missing:
        raise ValueError(f"Manifest omits required input hashes: {sorted(missing)}")
    for name, metadata in artifacts.items():
        if not isinstance(name, str) or Path(name).name != name or name in (".", ".."):
            raise ValueError(f"Manifest artifact must be a dataset-local filename: {name!r}")
        if not isinstance(metadata, dict) or not isinstance(metadata.get("sha256"), str):
            raise ValueError(f"Manifest artifact {name!r} lacks a SHA256 digest")
        path = directory / name
        if not path.is_file():
            raise FileNotFoundError(f"Manifest artifact missing: {path}")
        actual = input_hashes.get(name) or sha256_file(path)
        if actual != metadata["sha256"]:
            raise ValueError(f"Manifest SHA256 mismatch for {name}")
        if "bytes" in metadata and metadata["bytes"] != path.stat().st_size:
            raise ValueError(f"Manifest byte count mismatch for {name}")


def load_split(directory, split, vocab_size, pcf=False):
    graphs = torch.load(directory / f"{split}.pt", map_location="cpu", weights_only=True)
    sequences = torch.load(directory / f"seq_{split}.pt", map_location="cpu",
                           weights_only=True)
    if not isinstance(graphs, list) or not isinstance(sequences, dict):
        raise ValueError(f"{split}: expected graph list and fid-to-sequence dictionary")
    items, seen = [], set()
    for item in graphs:
        fid = item["fid"]
        if not isinstance(fid, str) or not fid or fid in seen:
            raise ValueError(f"{split}: invalid or duplicated graph fid {fid!r}")
        if fid not in sequences:
            raise ValueError(f"{split}: sequence missing for {fid}; refusing to drop it")
        if item["y"] not in (0, 1):
            raise ValueError(f"{split}/{fid}: label must be 0 or 1")
        sequence = sequences[fid]
        require_ids(item["x"], vocab_size, f"{split}/{fid}/x")
        require_ids(sequence, vocab_size, f"{split}/{fid}/sequence")
        if not sequence.ne(0).any():
            raise ValueError(f"{split}/{fid}: sequence contains only padding")
        ei, et = item["edge_index"], item["edge_type"]
        if (ei.dtype != torch.long or et.dtype != torch.long or ei.ndim != 2
                or ei.shape[0] != 2 or et.ndim != 1 or ei.shape[1] != et.numel()):
            raise ValueError(f"{split}/{fid}: malformed edge tensors")
        if et.numel() and (int(et.min()) < 0 or int(et.max()) > 3
                           or int(ei.min()) < 0 or int(ei.max()) >= item["x"].numel()):
            raise ValueError(f"{split}/{fid}: invalid relation or node index")
        if pcf:
            flags = item.get("x_flags")
            if (flags is None or flags.shape != (item["x"].numel(), 4)
                    or not flags.is_floating_point() or not torch.isfinite(flags).all()):
                raise ValueError(f"{split}/{fid}: expected finite floating x_flags[N,4]")
        seen.add(fid)
        items.append((item, sequence))
    if not items:
        raise ValueError(f"{split}: empty split")
    labels = [int(item["y"]) for item, _ in items]
    if set(labels) != {0, 1}:
        raise ValueError(f"{split}: both classes are required for this experiment")
    # Extra sequences are reported, not silently treated as model observations.
    inventory = {
        "count": len(items), "positive": sum(labels),
        "unused_sequence_count": len(set(sequences) - seen),
        "ordered_fid_label_sha256": hashlib.sha256(json.dumps(
            [(item["fid"], int(item["y"])) for item, _ in items],
            ensure_ascii=False, separators=(",", ":")).encode("utf-8")).hexdigest(),
    }
    return items, seen, inventory


@torch.no_grad()
def predict(model, items, batch_size, device, edges, pcf=False):
    model.eval()
    probabilities, labels = [], []
    for index in range(0, len(items), batch_size):
        graph, sequence, y = collate(items[index:index + batch_size], edges, pcf)
        logits = model(graph.to(device), sequence.to(device))
        probabilities.append(torch.sigmoid(logits).cpu())
        labels.append(y)
    probability = torch.cat(probabilities).numpy()
    if not np.isfinite(probability).all():
        raise FloatingPointError("Non-finite model probabilities")
    return torch.cat(labels).numpy().astype(np.int64), probability


def classification_metrics(labels, probability, threshold, suffix):
    predicted = (probability > threshold).astype(np.int64)
    return {
        f"f1@{suffix}": float(f1_score(labels, predicted, zero_division=0)),
        f"p@{suffix}": float(precision_score(labels, predicted, zero_division=0)),
        f"r@{suffix}": float(recall_score(labels, predicted, zero_division=0)),
        f"mcc@{suffix}": float(matthews_corrcoef(labels, predicted)),
    }


def metrics_at_thresholds(labels, probability, validation_threshold=None):
    ap = float(average_precision_score(labels, probability))
    result = {"ap": ap, "pr_auc": ap,
              "roc_auc": float(roc_auc_score(labels, probability)),
              "n": len(labels), "positive": int(labels.sum())}
    result.update(classification_metrics(labels, probability, 0.5, "0.5"))
    if validation_threshold is not None:
        result.update(classification_metrics(labels, probability,
                                             validation_threshold, "val_t"))
        result["val_t"] = validation_threshold
    return result


def select_validation_threshold(labels, probability):
    """Match the original 19-point validation sweep and strict > comparator."""
    best_f1, best_threshold = 0.0, 0.5
    for threshold in np.linspace(0.05, 0.95, 19):
        value = f1_score(labels, probability > threshold, zero_division=0)
        if value > best_f1:
            best_f1, best_threshold = float(value), float(threshold)
    return best_threshold, best_f1


def write_predictions(path, items, labels, probability, threshold):
    # Array comparison matches classification_metrics. NumPy 1.x can promote
    # a float32 scalar differently from a float32 array at threshold boundaries.
    predicted_half = probability > 0.5
    predicted_validation = probability > threshold
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["fid", "y", "prob", "pred_0.5", "pred_val_t", "val_t"])
        for (item, _), label, score, half, selected in zip(
                items, labels, probability, predicted_half, predicted_validation):
            writer.writerow([item["fid"], int(label), float(score),
                             int(half), int(selected), threshold])
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def parser():
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("--data", required=True, type=Path)
    result.add_argument("--out", required=True, type=Path)
    result.add_argument("--channels", choices=("both", "gnn", "seq"), default="both")
    result.add_argument("--fusion", choices=("attention", "concat"), default="attention")
    result.add_argument("--edges", choices=tuple(EDGE_MODES), default="all")
    result.add_argument("--pcf", action="store_true", help="Use all four existing x_flags")
    result.add_argument("--dim", type=int, default=128)
    result.add_argument("--epochs", type=int, default=25)
    result.add_argument("--batch", type=int, default=64)
    result.add_argument("--lr", type=float, default=1e-3)
    result.add_argument("--dropout", type=float, default=0.3)
    result.add_argument("--patience", type=int, default=5)
    result.add_argument("--seed", type=int, default=42)
    result.add_argument("--device", choices=("auto", "cuda", "cpu"), default="auto")
    return result


def train(args, spec, log):
    started = time.perf_counter()
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    cuda = torch.cuda.is_available()
    device = ("cuda" if cuda else "cpu") if args.device == "auto" else args.device
    if device == "cuda" and not cuda:
        raise RuntimeError("CUDA was requested but is unavailable")
    if device == "cuda":
        torch.cuda.reset_peak_memory_stats()

    required = ["vocab_joint.json"] + [name for split in SPLITS
                for name in (f"{split}.pt", f"seq_{split}.pt")]
    for name in required:
        if not (args.data / name).is_file():
            raise FileNotFoundError(f"Required dataset-local input missing: {args.data / name}")
    vocabulary = json.loads((args.data / "vocab_joint.json").read_text(encoding="utf-8"))
    validate_vocabulary(vocabulary)
    inputs = {name: sha256_file(args.data / name) for name in required}
    manifests = {}
    for path in sorted(args.data.glob("*manifest*.json")):
        manifests[path.name] = {"sha256": sha256_file(path),
                                "content": json.loads(path.read_text(encoding="utf-8"))}
        verify_manifest_artifacts(args.data, manifests[path.name]["content"], inputs)
    items, split_ids, inventories = {}, {}, {}
    for split in SPLITS:
        items[split], split_ids[split], inventories[split] = load_split(
            args.data, split, len(vocabulary), args.pcf)
    for left, right in (("train", "validation"), ("train", "test"), ("validation", "test")):
        if split_ids[left] & split_ids[right]:
            raise ValueError(f"Graph fid overlap between {left} and {right}")

    pos_weight = ((inventories["train"]["count"] - inventories["train"]["positive"])
                  / inventories["train"]["positive"])
    model = FusionModel(len(vocabulary), args.dim, args.channels,
                        relation_count(args.edges), args.dropout, args.fusion,
                        flag_dim=4 if args.pcf else 0).to(device)
    parameter_count = sum(parameter.numel() for parameter in model.parameters())
    environment = {
        "python": platform.python_version(), "platform": platform.platform(),
        "torch": str(torch.__version__), "torch_geometric": torch_geometric.__version__,
        "numpy": np.__version__, "sklearn": sklearn.__version__,
        "cuda_runtime": torch.version.cuda, "device": device,
        "gpu_name": torch.cuda.get_device_name(0) if device == "cuda" else None,
        "gpu_total_memory_bytes": (torch.cuda.get_device_properties(0).total_memory
                                    if device == "cuda" else None),
        "cudnn_deterministic": torch.backends.cudnn.deterministic,
        "cudnn_benchmark": torch.backends.cudnn.benchmark,
        "deterministic_algorithms": torch.are_deterministic_algorithms_enabled(),
        "pythonhashseed": os.environ.get("PYTHONHASHSEED"),
        "torch_num_threads": torch.get_num_threads(),
    }
    spec.update({
        "input_sha256": inputs, "vocab_sha256": inputs["vocab_joint.json"],
        "data_manifests": manifests, "splits": inventories,
        "environment": environment, "parameter_count": parameter_count,
        "trainable_parameter_count": sum(p.numel() for p in model.parameters() if p.requires_grad),
        "vocab_size": len(vocabulary), "pos_weight": pos_weight,
        "relations": {str(old): (0 if args.edges == "untyped" else new)
                      for new, old in enumerate(EDGE_MODES[args.edges])},
        "optimizer": {"name": "AdamW", "lr": args.lr, "weight_decay": 1e-4},
        "gradient_clip_norm": 1.0, "warm_start": None,
        "validation_predictions_source": "selected_epoch_cached",
        "selection": {"checkpoint": "maximum validation AP",
                      "threshold": "maximum validation F1, 0.05:0.05:0.95",
                      "prediction_comparator": ">", "test_threshold_search": False},
    })
    atomic_json(args.out / "run_spec.json", spec)
    log(f"INPUTS {json.dumps(inventories)}")
    log(f"MODEL device={device} gpu={environment['gpu_name']} params={parameter_count} "
        f"vocab={len(vocabulary)} pos_weight={pos_weight:.6f}")
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-4)
    criterion = nn.BCEWithLogitsLoss(pos_weight=torch.tensor(pos_weight, device=device))
    best_ap, best_state, best_epoch, bad = -1.0, None, 0, 0
    best_threshold = 0.5
    best_validation = None
    train_started = time.perf_counter()
    epoch_history = []
    with (args.out / "epochs.jsonl").open("w", encoding="utf-8", newline="\n") as history:
        for epoch in range(1, args.epochs + 1):
            model.train()
            random.shuffle(items["train"])
            epoch_started, total_loss = time.perf_counter(), 0.0
            for index in range(0, len(items["train"]), args.batch):
                graph, sequence, labels = collate(
                    items["train"][index:index + args.batch], args.edges, args.pcf)
                optimizer.zero_grad()
                loss = criterion(model(graph.to(device), sequence.to(device)), labels.to(device))
                if not torch.isfinite(loss):
                    raise FloatingPointError(f"Non-finite training loss at epoch {epoch}")
                loss.backward()
                nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                optimizer.step()
                total_loss += float(loss.detach()) * len(labels)
            val_y, val_p = predict(model, items["validation"], args.batch,
                                   device, args.edges, args.pcf)
            validation_metrics = metrics_at_thresholds(val_y, val_p)
            threshold, validation_best_f1 = select_validation_threshold(val_y, val_p)
            improved = validation_metrics["ap"] > best_ap
            if improved:
                best_ap, best_epoch, bad = validation_metrics["ap"], epoch, 0
                best_threshold = threshold
                # These exact predictions selected the threshold. Re-evaluating
                # validation on GPU can introduce small nondeterministic changes.
                best_validation = (val_y.copy(), val_p.copy())
                best_state = {name: value.detach().cpu().clone()
                              for name, value in model.state_dict().items()}
                atomic_checkpoint(args.out / "model.pt", best_state)
                atomic_json(args.out / "best_checkpoint.json", {
                    "epoch": epoch, "validation_ap": best_ap, "val_t": best_threshold,
                    "vocab_sha256": inputs["vocab_joint.json"],
                })
            else:
                bad += 1
            row = {"epoch": epoch, "loss": total_loss / len(items["train"]),
                   "validation": validation_metrics, "validation_best_f1": validation_best_f1,
                   "validation_best_t": threshold, "improved": improved,
                   "seconds": time.perf_counter() - epoch_started}
            epoch_history.append(row)
            history.write(json.dumps(row, allow_nan=False) + "\n")
            history.flush()
            os.fsync(history.fileno())
            log(f"EPOCH {epoch:02d} loss={row['loss']:.6f} val_ap={validation_metrics['ap']:.6f} "
                f"val_f1={validation_best_f1:.6f}(t={threshold:.2f}) "
                f"seconds={row['seconds']:.3f} best_epoch={best_epoch}")
            if bad >= args.patience:
                log(f"EARLY_STOP epoch={epoch}")
                break
    train_seconds = time.perf_counter() - train_started
    if best_state is None or best_validation is None:
        raise RuntimeError("No valid best checkpoint")
    model.load_state_dict(best_state)
    evaluation_started = time.perf_counter()
    result = {"config": spec["config"], "vocab_sha256": inputs["vocab_joint.json"],
              "best_epoch": best_epoch, "epochs_completed": len(epoch_history),
              "parameter_count": parameter_count, "splits": inventories,
              "validation_predictions_source": "selected_epoch_cached"}
    for split, result_key in (("validation", "val"), ("test", "test")):
        if split == "validation":
            labels, probabilities = best_validation
        else:
            labels, probabilities = predict(model, items[split], args.batch,
                                             device, args.edges, args.pcf)
        result[result_key] = metrics_at_thresholds(labels, probabilities, best_threshold)
        write_predictions(args.out / f"{split}_predictions.csv", items[split], labels,
                          probabilities, best_threshold)
    result["timing"] = {
        "training_with_validation_seconds": train_seconds,
        "final_evaluation_seconds": time.perf_counter() - evaluation_started,
        "total_seconds": time.perf_counter() - started,
    }
    result["gpu"] = {
        "name": environment["gpu_name"],
        "peak_allocated_bytes": torch.cuda.max_memory_allocated() if device == "cuda" else None,
        "peak_reserved_bytes": torch.cuda.max_memory_reserved() if device == "cuda" else None,
    }
    # metrics.json is the completed-run marker; write it after all predictions.
    atomic_json(args.out / "metrics.json", result)
    spec.update({"status": "completed", "finished_utc": utc_now(),
                 "timing": result["timing"], "gpu": result["gpu"],
                 "best_epoch": best_epoch, "epochs_completed": len(epoch_history)})
    atomic_json(args.out / "run_spec.json", spec)
    log("TEST " + json.dumps(result["test"], allow_nan=False))
    log(f"RESULT_SAVED {args.out}")
    return result


def main(argv=None):
    cli = parser()
    args = cli.parse_args(argv)
    if min(args.dim, args.epochs, args.batch, args.patience) < 1 or args.lr <= 0:
        cli.error("dim, epochs, batch, patience and lr must be positive")
    if not 0 <= args.dropout < 1:
        cli.error("dropout must lie in [0,1)")
    if not 0 <= args.seed < 2 ** 32:
        cli.error("seed must lie in [0,2**32)")
    if args.channels == "both" and args.fusion == "attention" and args.dim % 4:
        cli.error("attention dimension must be divisible by four heads")
    if args.channels != "both" and args.fusion != "attention":
        cli.error("--fusion concat is meaningful only with --channels both")
    if args.channels == "seq" and (args.edges != "all" or args.pcf):
        cli.error("seq-only has no graph: keep --edges all and omit --pcf")
    args.data, args.out = args.data.resolve(), args.out.resolve()
    if not args.data.is_dir():
        cli.error(f"dataset directory does not exist: {args.data}")
    if args.out.exists() and any(args.out.iterdir()):
        cli.error(f"output must be new or empty; refusing to overwrite: {args.out}")
    args.out.mkdir(parents=True, exist_ok=True)
    config = {key: str(value) if isinstance(value, Path) else value
              for key, value in vars(args).items()}
    spec = {"status": "running", "started_utc": utc_now(), "config": config,
            "command": sys.argv if argv is None else [str(Path(__file__).resolve()), *argv],
            "script_sha256": sha256_file(__file__), "cwd": str(Path.cwd())}
    atomic_json(args.out / "run_spec.json", spec)
    with (args.out / "train.log").open("w", encoding="utf-8", newline="\n") as log_file:
        def log(message):
            print(message, flush=True)
            log_file.write(message + "\n")
            log_file.flush()
        try:
            log("CONFIG " + json.dumps(config))
            train(args, spec, log)
        except BaseException as error:
            spec.update({"status": "failed", "finished_utc": utc_now(),
                         "error": f"{type(error).__name__}: {error}"})
            atomic_json(args.out / "run_spec.json", spec)
            log(traceback.format_exc())
            raise


if __name__ == "__main__":
    main()
