# Juliet access-control (CWE-566+601) before/after PCFinder: controlled synthetic
# check. bad=1/good=0, balanced (~35% pos). 4 configs x 5 seeds. Resumable.
$conda = "C:\Users\ADMIN\miniconda3\condabin\conda.bat"
Set-Location "C:\Users\ADMIN\Desktop\ts\VDMAF_main\newidea\Java\gnn"
foreach ($seed in 42, 43, 44, 45, 46) {
    Write-Output "=== JAC SEED $seed START  $(Get-Date -Format HH:mm:ss) ==="
    $runs = @(
        @("jac_both_off", "both", ""),
        @("jac_both_on",  "both", "--pcf"),
        @("jac_gnn_off",  "gnn",  ""),
        @("jac_gnn_on",   "gnn",  "--pcf")
    )
    foreach ($r in $runs) {
        $name, $ch, $flag = $r
        $dir = "runs/${name}_s$seed"
        if (Test-Path "$dir/metrics.json") { continue }
        if ($flag -eq "--pcf") {
            & $conda run -n vdmaf-gnn python -u train_v1.py --ds dataset_juliet_ac --channels $ch --edges all --epochs 30 --patience 6 --seed $seed --out $dir --pcf
        } else {
            & $conda run -n vdmaf-gnn python -u train_v1.py --ds dataset_juliet_ac --channels $ch --edges all --epochs 30 --patience 6 --seed $seed --out $dir
        }
    }
    Write-Output "=== JAC SEED $seed GROUP DONE  $(Get-Date -Format HH:mm:ss) ==="
}
Write-Output "=== JAC EXPERIMENT ALL DONE  $(Get-Date -Format HH:mm:ss) ==="
