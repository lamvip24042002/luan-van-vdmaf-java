$conda = "C:\Users\ADMIN\miniconda3\condabin\conda.bat"
Write-Output "=== Devign makemodel  $(Get-Date -Format HH:mm:ss) ==="
Set-Location "C:\Users\ADMIN\Desktop\ts\VDMAF_main\newidea\Devign\code"
& $conda run -n vdmaf python -u makemodel.py
Write-Output "=== Bagheri makemodel (sql)  $(Get-Date -Format HH:mm:ss) ==="
Set-Location "C:\Users\ADMIN\Desktop\ts\VDMAF_main\newidea\Bagheri\train_model"
& $conda run -n vdmaf python -u makemodel.py
Write-Output "=== ALL TRAINING DONE  $(Get-Date -Format HH:mm:ss) ==="
