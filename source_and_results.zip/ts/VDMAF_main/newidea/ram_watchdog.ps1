# Logs RAM every 15 s; force-kills python if free RAM < 3 GB or python > 22 GB.
$log = "C:\Users\ADMIN\Desktop\ts\VDMAF_main\newidea\ram_watchdog.log"
Add-Content $log "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') watchdog started"
Start-Sleep -Seconds 30   # grace period for python to appear
while ($true) {
    $os = Get-CimInstance Win32_OperatingSystem
    $freeGB = [math]::Round($os.FreePhysicalMemory/1MB, 1)
    $pys = Get-Process python* -ErrorAction SilentlyContinue
    if (-not $pys) { Add-Content $log "$(Get-Date -Format HH:mm:ss) no python running -> watchdog exits"; break }
    $pyGB = [math]::Round((($pys | Measure-Object WorkingSet64 -Sum).Sum)/1GB, 1)
    Add-Content $log "$(Get-Date -Format HH:mm:ss) free=${freeGB}GB python=${pyGB}GB"
    if ($freeGB -lt 3 -or $pyGB -gt 22) {
        Add-Content $log "$(Get-Date -Format HH:mm:ss) LIMIT HIT (free=${freeGB}GB, python=${pyGB}GB) -> killing python"
        $pys | Stop-Process -Force
        break
    }
    Start-Sleep -Seconds 15
}
