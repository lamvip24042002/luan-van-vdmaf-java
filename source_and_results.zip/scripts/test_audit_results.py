"""Integrity and numeric edge cases for the portable recorded-results audit."""
import csv
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np

from audit_results import Evidence, predictions, sha256, threshold_from_validation


class IntegrityTests(unittest.TestCase):
    def test_changed_bytes_fail_even_with_same_size(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            file = root / "evidence.txt"
            file.write_bytes(b"one")
            (root / "MANIFEST.json").write_text(json.dumps({"files": [
                {"path": "evidence.txt", "size": 3, "sha256": sha256(file)}]}))
            file.write_bytes(b"two")
            with self.assertRaisesRegex(ValueError, "SHA-256 mismatch"):
                Evidence(root).path("evidence.txt")

    def test_manifest_rejects_path_escape(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for path in ("../outside.txt", "/outside.txt", "C:/outside.txt", "a\\outside.txt"):
                with self.subTest(path=path):
                    (root / "MANIFEST.json").write_text(json.dumps({"files": [
                        {"path": path, "size": 1, "sha256": "0" * 64}]}))
                    with self.assertRaisesRegex(ValueError, "Unsafe manifest path"):
                        Evidence(root)

    def test_float32_threshold_tie_uses_strict_greater_than(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "predictions.csv"
            with path.open("w", newline="") as handle:
                writer = csv.writer(handle)
                writer.writerow(("fid", "y", "prob", "pred_0.5", "pred_val_t", "val_t"))
                writer.writerow(("a", 0, float(np.float32(0.9)), 1, 0, 0.9))
                writer.writerow(("b", 1, 1.0, 1, 1, 0.9))
            _, _, probs, threshold, _ = predictions(path)
            self.assertEqual(probs.dtype, np.float32)
            self.assertFalse(bool(probs[0:1] > threshold))

    def test_duplicate_prediction_ids_fail(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "predictions.csv"
            path.write_text("fid,y,prob,pred_0.5,pred_val_t,val_t\na,0,0.1,0,0,0.5\na,1,0.8,1,1,0.5\n")
            with self.assertRaisesRegex(ValueError, "Duplicate sample IDs"):
                predictions(path)

    def test_validation_threshold_keeps_first_maximum(self):
        labels = np.asarray([0, 1])
        probs = np.asarray([0.0, 1.0], dtype=np.float32)
        self.assertEqual(threshold_from_validation(labels, probs), 0.05)


if __name__ == "__main__":
    unittest.main()
