[CmdletBinding()]
param(
    [ValidateSet("smoke", "full")]
    [string]$Mode = "full",

    [string]$CondaEnv = "vdmaf-gnn",

    # If supplied, bypass conda and run this Python executable directly.
    [string]$Python = "",

    [string]$Dataset = "",
    [string]$SequenceDir = "",
    [string]$Vocab = "",
    [string]$EmbeddingMatrix = "",
    [string]$OutputRoot = "",

    # Zero selects the mode default.  Full defaults to the paper's 100-epoch
    # ceiling, with validation early stopping; the physical batch remains 32
    # because graph cross-attention cannot fit the paper's batch 256 on 12 GB.
    [int]$MaxEpochs = 0,
    [int]$TrainBatch = 0,
    [int]$EarlyStopPatience = 0,

    [ValidateSet("auto", "cpu", "cuda")]
    [string]$Device = "auto",

    [switch]$NoAggregate
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$Here = $PSScriptRoot
$TrainScript = Join-Path $Here "train_legacy.py"
$AggregateScript = Join-Path $Here "aggregate_compare.py"

if ([string]::IsNullOrWhiteSpace($Dataset)) {
    $Dataset = Join-Path $Here "..\gnn\dataset_v2"
}
if ([string]::IsNullOrWhiteSpace($SequenceDir)) {
    $SequenceDir = Join-Path $Here "..\gnn\dataset"
}
if ([string]::IsNullOrWhiteSpace($Vocab)) {
    $Vocab = Join-Path $SequenceDir "vocab_joint.json"
}
if ([string]::IsNullOrWhiteSpace($EmbeddingMatrix)) {
    $EmbeddingMatrix = Join-Path $Here "artifacts\embedding_matrix.npy"
}
if ([string]::IsNullOrWhiteSpace($OutputRoot)) {
    $OutputRoot = Join-Path $Here "runs_compare\$Mode"
}

function Resolve-ExistingPath([string]$Path, [string]$Description) {
    if (-not (Test-Path -LiteralPath $Path)) {
        throw "$Description not found: $Path"
    }
    return (Resolve-Path -LiteralPath $Path).Path
}

$TrainScript = Resolve-ExistingPath $TrainScript "Training script"
$AggregateScript = Resolve-ExistingPath $AggregateScript "Aggregation script"
$Dataset = Resolve-ExistingPath $Dataset "Dataset"
$SequenceDir = Resolve-ExistingPath $SequenceDir "Sequence dataset"
$Vocab = Resolve-ExistingPath $Vocab "Joint vocabulary"
$EmbeddingMatrix = Resolve-ExistingPath $EmbeddingMatrix "Embedding matrix"
$EmbeddingSha256 = (Get-FileHash -LiteralPath $EmbeddingMatrix -Algorithm SHA256).Hash.ToLowerInvariant()
$VocabSha256 = (Get-FileHash -LiteralPath $Vocab -Algorithm SHA256).Hash.ToLowerInvariant()
$TrainScriptSha256 = (Get-FileHash -LiteralPath $TrainScript -Algorithm SHA256).Hash.ToLowerInvariant()
$AggregateScriptSha256 = (Get-FileHash -LiteralPath $AggregateScript -Algorithm SHA256).Hash.ToLowerInvariant()
$WrapperScriptSha256 = (Get-FileHash -LiteralPath $MyInvocation.MyCommand.Path -Algorithm SHA256).Hash.ToLowerInvariant()

$GraphHashes = [ordered]@{}
$SequenceHashes = [ordered]@{}
foreach ($Split in @("train", "validation", "test")) {
    $GraphFile = Resolve-ExistingPath (Join-Path $Dataset "$Split.pt") "Graph split $Split"
    $SequenceFile = Resolve-ExistingPath (Join-Path $SequenceDir "seq_$Split.pt") "Sequence split $Split"
    $GraphHashes[$Split] = (Get-FileHash -LiteralPath $GraphFile -Algorithm SHA256).Hash.ToLowerInvariant()
    $SequenceHashes[$Split] = (Get-FileHash -LiteralPath $SequenceFile -Algorithm SHA256).Hash.ToLowerInvariant()
}
$OutputRoot = [System.IO.Path]::GetFullPath($OutputRoot)
New-Item -ItemType Directory -Force -Path $OutputRoot | Out-Null

foreach ($Override in @($MaxEpochs, $TrainBatch, $EarlyStopPatience)) {
    if ($Override -lt 0) { throw "Epoch, batch, and patience overrides cannot be negative." }
}

if ($Mode -eq "smoke") {
    # A pipeline check only. It is deliberately isolated from full results.
    $Seeds = @(42)
    $DefaultEpochs = 1
    $DefaultBatch = 8
    $DefaultPatience = 1
    $Limit = 512
} else {
    $Seeds = @(42, 43, 44, 45, 46)
    $DefaultEpochs = 100
    $DefaultBatch = 32
    $DefaultPatience = 10
    $Limit = 0
}
$Epochs = if ($MaxEpochs -gt 0) { $MaxEpochs } else { $DefaultEpochs }
$Batch = if ($TrainBatch -gt 0) { $TrainBatch } else { $DefaultBatch }
$Patience = if ($EarlyStopPatience -gt 0) { $EarlyStopPatience } else { $DefaultPatience }
$EvalBatch = [math]::Min($Batch, 16)

# Explicit architecture/training constants: changing trainer defaults cannot
# silently change or resume this experiment.
$LearningRate = 0.01
$WeightDecay = 0.0
$Dropout = 0.2
$Heads = 10
$GgnnSteps = 2
$LstmHidden = 100
$LstmLayers = 1
$AttentionChunk = 64
$UseAmp = $false

if ([string]::IsNullOrWhiteSpace($Python)) {
    $Conda = Get-Command conda -ErrorAction SilentlyContinue
    if ($null -eq $Conda) {
        throw "conda was not found on PATH. Activate conda or pass -Python <python.exe>."
    }
    $Runner = $Conda.Source
    $RunnerPrefix = @("run", "--no-capture-output", "-n", $CondaEnv, "python")
} else {
    $PythonCommand = Get-Command $Python -ErrorAction SilentlyContinue
    if ($null -ne $PythonCommand) {
        $Runner = $PythonCommand.Source
    } elseif (Test-Path -LiteralPath $Python) {
        $Runner = (Resolve-Path -LiteralPath $Python).Path
    } else {
        throw "Python executable was not found: $Python"
    }
    $RunnerPrefix = @()
}

# Required by PyTorch deterministic mode for CUDA >= 10.2.  It must be set
# before Python initializes cuBLAS.
if ([string]::IsNullOrWhiteSpace($env:CUBLAS_WORKSPACE_CONFIG)) {
    $env:CUBLAS_WORKSPACE_CONFIG = ":4096:8"
}

function ConvertTo-CanonicalJson($Value) {
    return ($Value | ConvertTo-Json -Depth 10 -Compress)
}

function Test-SamePath([string]$Left, [string]$Right) {
    if ([string]::IsNullOrWhiteSpace($Left) -or [string]::IsNullOrWhiteSpace($Right)) {
        return $false
    }
    $A = [System.IO.Path]::GetFullPath($Left)
    $B = [System.IO.Path]::GetFullPath($Right)
    return $A.Equals($B, [System.StringComparison]::OrdinalIgnoreCase)
}

function Test-CompleteMetrics([string]$MetricsPath, [System.Collections.IDictionary]$Expected) {
    if (-not (Test-Path -LiteralPath $MetricsPath)) {
        return $false
    }
    try {
        $Metrics = Get-Content -LiteralPath $MetricsPath -Raw | ConvertFrom-Json
        foreach ($Section in @("config", "data", "word2vec", "training", "val", "test")) {
            if ($null -eq $Metrics.PSObject.Properties[$Section]) {
                return $false
            }
        }
        if ($null -eq $Metrics.config.PSObject.Properties["seed"] -or
            [int]$Metrics.config.seed -ne [int]$Expected["seed"]) {
            return $false
        }
        if ($null -eq $Metrics.config.PSObject.Properties["pcf"] -or
            [bool]$Metrics.config.pcf -ne [bool]$Expected["pcf"]) {
            return $false
        }
        foreach ($Name in @("epochs", "batch", "eval_batch", "limit", "patience", "heads", "ggnn_steps", "lstm_hidden", "lstm_layers", "attention_chunk")) {
            if ($null -eq $Metrics.config.PSObject.Properties[$Name] -or
                [double]$Metrics.config.PSObject.Properties[$Name].Value -ne [double]$Expected[$Name]) {
                return $false
            }
        }
        foreach ($Name in @("lr", "weight_decay", "dropout")) {
            if ($null -eq $Metrics.config.PSObject.Properties[$Name] -or
                [math]::Abs([double]$Metrics.config.PSObject.Properties[$Name].Value - [double]$Expected[$Name]) -gt 1e-12) {
                return $false
            }
        }
        if (-not (Test-SamePath ([string]$Metrics.config.ds) ([string]$Expected["dataset"]))) { return $false }
        if (-not (Test-SamePath ([string]$Metrics.config.seq_dir) ([string]$Expected["sequence_dir"]))) { return $false }
        if (-not (Test-SamePath ([string]$Metrics.config.vocab) ([string]$Expected["vocab"]))) { return $false }
        if (-not (Test-SamePath ([string]$Metrics.config.embedding_matrix) ([string]$Expected["embedding_matrix"]))) { return $false }
        if ([string]$Metrics.word2vec.sha256 -ne [string]$Expected["embedding_sha256"]) { return $false }
        if ([bool]$Metrics.config.amp -ne [bool]$Expected["amp"]) { return $false }
        if ([bool]$Metrics.config.deterministic -ne [bool]$Expected["deterministic_requested"]) { return $false }
        foreach ($Name in @("pr_auc", "roc_auc", "f1@0.5", "mcc@0.5", "f1@val_t", "mcc@val_t", "val_t")) {
            if ($null -eq $Metrics.test.PSObject.Properties[$Name]) {
                return $false
            }
            $Number = $Metrics.test.PSObject.Properties[$Name].Value
            if ($null -eq $Number -or [double]::IsNaN([double]$Number) -or [double]::IsInfinity([double]$Number)) {
                return $false
            }
        }
        return $true
    } catch {
        return $false
    }
}

function Invoke-Python([string[]]$Arguments, [string]$LogPath) {
    $AllArguments = @($RunnerPrefix) + $Arguments
    # Windows PowerShell wraps every native stderr line as a non-terminating
    # ErrorRecord.  Temporarily allow those records through Tee-Object; the
    # native exit code remains the authoritative success/failure signal.
    $PreviousErrorAction = $ErrorActionPreference
    try {
        $ErrorActionPreference = "Continue"
        & $Runner @AllArguments 2>&1 | Tee-Object -FilePath $LogPath
        $ExitCode = $LASTEXITCODE
    } finally {
        $ErrorActionPreference = $PreviousErrorAction
    }
    if ($ExitCode -ne 0) {
        throw "Command failed with exit code $ExitCode. See $LogPath"
    }
}

Write-Output "=== LEGACY VDMAF +/- PCFinder: $($Mode.ToUpperInvariant()) ==="
Write-Output "dataset:   $Dataset"
Write-Output "embedding: $EmbeddingMatrix"
Write-Output "output:    $OutputRoot"
Write-Output "seeds:     $($Seeds -join ', ')"
Write-Output "config:    epochs=$Epochs batch=$Batch eval_batch=$EvalBatch patience=$Patience limit=$Limit amp=$UseAmp device=$Device"

foreach ($Seed in $Seeds) {
    foreach ($Variant in @("off", "on")) {
        $PcfEnabled = $Variant -eq "on"
        $RunDir = Join-Path $OutputRoot "${Variant}_seed${Seed}"
        $SpecPath = Join-Path $RunDir "run_spec.json"
        $MetricsPath = Join-Path $RunDir "metrics.json"
        $LogPath = Join-Path $RunDir "train.log"

        $Spec = [ordered]@{
            schema_version = 1
            experiment = "legacy_vdmaf_pcf_paired"
            mode = $Mode
            variant = $Variant
            pcf = $PcfEnabled
            seed = $Seed
            dataset = $Dataset
            dataset_sha256 = $GraphHashes
            sequence_dir = $SequenceDir
            sequence_sha256 = $SequenceHashes
            vocab = $Vocab
            vocab_sha256 = $VocabSha256
            embedding_matrix = $EmbeddingMatrix
            embedding_sha256 = $EmbeddingSha256
            train_script_sha256 = $TrainScriptSha256
            aggregate_script_sha256 = $AggregateScriptSha256
            wrapper_script_sha256 = $WrapperScriptSha256
            epochs = $Epochs
            batch = $Batch
            eval_batch = $EvalBatch
            patience = $Patience
            limit = $Limit
            device = $Device
            optimizer = "Adam"
            lr = $LearningRate
            weight_decay = $WeightDecay
            dropout = $Dropout
            heads = $Heads
            ggnn_steps = $GgnnSteps
            lstm_hidden = $LstmHidden
            lstm_layers = $LstmLayers
            attention_chunk = $AttentionChunk
            deterministic_requested = $true
            amp = $UseAmp
            cublas_workspace_config = $env:CUBLAS_WORKSPACE_CONFIG
        }
        $SpecJson = ConvertTo-CanonicalJson $Spec

        if (Test-Path -LiteralPath $SpecPath) {
            try {
                $ExistingSpec = Get-Content -LiteralPath $SpecPath -Raw | ConvertFrom-Json
                $ExistingJson = ConvertTo-CanonicalJson $ExistingSpec
            } catch {
                throw "Invalid run manifest: $SpecPath. Move this run directory aside, then retry."
            }
            if ($ExistingJson -ne $SpecJson) {
                throw "Run manifest does not match the requested configuration: $SpecPath. Use a different -OutputRoot."
            }
        }

        if ((Test-Path -LiteralPath $MetricsPath) -and -not (Test-Path -LiteralPath $SpecPath)) {
            throw "Found metrics without a run manifest: $MetricsPath. Use a different -OutputRoot or move this untracked run aside."
        }

        if ((Test-Path -LiteralPath $SpecPath) -and
            (Test-CompleteMetrics $MetricsPath $Spec)) {
            Write-Output "[skip] $Variant seed=$Seed (validated metrics + matching manifest)"
            continue
        }

        New-Item -ItemType Directory -Force -Path $RunDir | Out-Null
        $SpecJson | Set-Content -LiteralPath $SpecPath -Encoding UTF8

        $TrainArguments = @(
            "-u", $TrainScript,
            "--out", $RunDir,
            "--ds", $Dataset,
            "--seq-dir", $SequenceDir,
            "--vocab", $Vocab,
            "--embedding-matrix", $EmbeddingMatrix,
            "--seed", [string]$Seed,
            "--epochs", [string]$Epochs,
            "--batch", [string]$Batch,
            "--eval-batch", [string]$EvalBatch,
            "--patience", [string]$Patience,
            "--limit", [string]$Limit,
            "--device", $Device,
            "--lr", [string]$LearningRate,
            "--weight-decay", [string]$WeightDecay,
            "--dropout", [string]$Dropout,
            "--heads", [string]$Heads,
            "--ggnn-steps", [string]$GgnnSteps,
            "--lstm-hidden", [string]$LstmHidden,
            "--lstm-layers", [string]$LstmLayers,
            "--attention-chunk", [string]$AttentionChunk,
            "--deterministic"
        )
        if ($PcfEnabled) {
            $TrainArguments += "--pcf"
        }
        # A matching manifest makes overwriting an incomplete/stale metrics file
        # safe.  Metrics without a manifest were rejected above.
        if (Test-Path -LiteralPath $MetricsPath) {
            $TrainArguments += "--overwrite"
        }

        Write-Output "[run ] $Variant seed=$Seed -> $RunDir"
        Invoke-Python $TrainArguments $LogPath
        if (-not (Test-CompleteMetrics $MetricsPath $Spec)) {
            throw "Training exited successfully but metrics are missing or incomplete: $MetricsPath"
        }
    }
}

if (-not $NoAggregate) {
    $AggregateArguments = @(
        "-u", $AggregateScript,
        "--mode", $Mode,
        "--root", $OutputRoot
    )
    Invoke-Python $AggregateArguments (Join-Path $OutputRoot "aggregate.log")
}

Write-Output "=== COMPARISON COMPLETE: $OutputRoot ==="
