"""Adversarial archive checks using only small standard-library fixtures."""
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile

from evaluate import Package
from prepare_data import unpack


class SafeArchiveTests(unittest.TestCase):
    def fixture(self, directory, zip_name="output/inputs/test.pt"):
        directory = Path(directory)
        root = directory / "relocated package"
        root.mkdir()
        content = b"small-tensor-fixture"
        member = {"path": "output/inputs/test.pt", "size": len(content),
                  "sha256": hashlib.sha256(content).hexdigest()}
        (root / "MANIFEST.json").write_text(json.dumps({"files": [member]}), encoding="utf-8")
        archive = directory / "data.zip"
        with zipfile.ZipFile(archive, "w") as writer:
            writer.writestr(zip_name, content)
        asset = {"name": "data.zip", "size": archive.stat().st_size,
                 "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(), "members": [member]}
        return root, archive, asset, Package(root)

    def test_relocated_extraction_and_identical_existing_files(self):
        with tempfile.TemporaryDirectory() as temporary:
            root, archive, asset, package = self.fixture(temporary)
            self.assertEqual(unpack(asset, archive, package, Path(temporary)), (1, 0))
            self.assertEqual((root / "output/inputs/test.pt").read_bytes(), b"small-tensor-fixture")
            self.assertEqual(unpack(asset, archive, package, Path(temporary)), (0, 1))

    def test_archive_tampering_fails_before_opening_zip(self):
        with tempfile.TemporaryDirectory() as temporary:
            _, archive, asset, package = self.fixture(temporary)
            archive.write_bytes(b"tampered")
            with patch("prepare_data.zipfile.ZipFile") as zip_open:
                with self.assertRaisesRegex(ValueError, "Archive SHA256/size mismatch"):
                    unpack(asset, archive, package, Path(temporary))
                zip_open.assert_not_called()

    def test_zip_slip_is_rejected_without_writing_outside_package(self):
        with tempfile.TemporaryDirectory() as temporary:
            root, archive, asset, package = self.fixture(temporary, "../escaped.txt")
            with self.assertRaisesRegex(ValueError, "Unsafe asset path"):
                unpack(asset, archive, package, Path(temporary))
            self.assertFalse((root.parent / "escaped.txt").exists())
            self.assertFalse((root / "output").exists())

    def test_different_existing_file_is_never_overwritten(self):
        with tempfile.TemporaryDirectory() as temporary:
            root, archive, asset, package = self.fixture(temporary)
            target = root / "output/inputs/test.pt"
            target.parent.mkdir(parents=True)
            target.write_bytes(b"examiner local changes")
            with self.assertRaisesRegex(ValueError, "Refusing to overwrite different"):
                unpack(asset, archive, package, Path(temporary))
            self.assertEqual(target.read_bytes(), b"examiner local changes")

    def test_expanded_member_hash_must_match_manifest(self):
        with tempfile.TemporaryDirectory() as temporary:
            root, archive, asset, package = self.fixture(temporary)
            # Archive is internally consistent but the declared member hash is wrong.
            wrong = dict(asset["members"][0], sha256="0" * 64)
            asset["members"] = [wrong]
            package.files[wrong["path"]] = wrong
            with self.assertRaisesRegex(ValueError, "Extracted member failed SHA256"):
                unpack(asset, archive, package, Path(temporary))
            self.assertFalse((root / wrong["path"]).exists())


if __name__ == "__main__":
    unittest.main()
