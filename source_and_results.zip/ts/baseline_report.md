# Báo cáo chốt baseline VDMAF trên 3 tập dữ liệu

*Ngày: 2026-07-04 · Môi trường: conda `vdmaf` (TF 2.10.1, GPU RTX 3060 12GB), Joern tại `C:\tools\joern-cli`*

## 1. Phạm vi

Tái lập phương pháp VDMAF (Li et al., IST 2025) theo **artifact công bố** (`VDMAF_main/newidea`)
trên 3 tập: Reveal (C), Devign (C), Bagheri/VUDENC (Python, mode SQL).
Mục đích: có mốc so sánh trung thực trước khi xây phiên bản chuyên biệt Java.

## 2. Nguồn dữ liệu (khớp Table 1–2 của bài báo)

| Tập | Nguồn đã dùng | Quy mô | Ghi chú |
|---|---|---|---|
| Reveal | kèm sẵn trong repo | 22.734 hàm, 2.240 vul (9,9%) | debian 18.298 + chrome 4.436 ✓ khớp Table 1 |
| Devign | HuggingFace `google/code_x_glue_cc_defect_detection` | 27.318 hàm (FFmpeg 9.769 + qemu 17.549) | chính makemodel của tác giả đặt tên `CodeXGLUE_word2vec_*` → đúng nguồn |
| Bagheri | VUDENC (Zenodo 3559841), 7 file `plain_*` | mode `sql`: 657 file nguồn, corpus 2,9MB | dữ liệu block-level, mất cân bằng nặng |

## 3. Các thành phần thiếu phải tự dựng lại

Repo **không kèm**: code sinh đồ thị (Joern→CPG), model node2vec cho Devign/Bagheri, Word2Vec models, raw datasets.
Đã dựng pipeline thay thế (`Devign/graph/`, `Bagheri/graph/`):

1. `make_src_files.py` — tách từng hàm/file ra file nguồn riêng, chia batch;
2. `c2cpg` / `pysrc2cpg` (Joern) — sinh CPG; `dump_graph.sc` — importCpg + ossdataflow rồi dump
   nút (token) + cạnh **AST / CFG / CDG / REACHING_DEF** cho từng method;
3. `build_node2vec.py` — gộp nút theo token trong từng method, random walk (2 walk × độ dài 20, đều),
   train skip-gram **đúng siêu tham số artifact của tác giả** (sg=1, window=10, min_count=5, dim=300, epochs=5 —
   xác định bằng cách mổ xẻ `node2vec_model-300.model` của Reveal: 9.293 key là token code).

Kiểm chứng trên mẫu 20 hàm Devign: 8.684 AST + 7.839 CFG + 6.999 CDG + 30.435 REACHING_DEF — đồ thị đầy đủ.

## 4. Khoảng cách bài báo ↔ code công bố (quan trọng cho luận văn)

1. **Bài báo mô tả GGNN 2 lớp trên CPG** (mục 3.x, Table 4) cho graph embedding; **code công bố dùng
   file gensim Word2Vec keyed theo token** ("node2vec"). Không có GGNN nào trong artifact.
2. **Fusion multi-head attention không được huấn luyện**: Reveal dùng `np.maximum(w2v, n2v)` (output MHA bị bỏ);
   Devign/Bagheri dùng `reduce_sum(MHA(...))` với trọng số ngẫu nhiên — với input 2D thực chất là
   biến đổi tuyến tính ngẫu nhiên của vector node2vec, w2v chỉ đóng góp qua phần giao từ vựng.
3. **Loss DWCE trong code = BCE thuần** (pos_w·bce + neg_w·bce với pos_w+neg_w=1).
4. Token chỉ được nhận vector khi nằm trong **cả hai** từ điển (w2v ∩ n2v); token khác bị loại khỏi chuỗi.

## 5. Lỗi code đã sửa để chạy được / chạy đúng

| Fix | Tệp | Lý do |
|---|---|---|
| `keras.preprocessing` → `tensorflow.keras.preprocessing` | makemodel (Devign, Bagheri) | TF 2.10 |
| `input_shape=(·,600)` → `(·,300)` | makemodel (Devign, Bagheri) | vector fusion là 300-d |
| `merged_vector_np = np.array(merged_vector)` | Devign, Bagheri | EagerTensor không có `.tolist()` — code gốc crash |
| dict lookup thay `list(common_tokens).index()` | cả 3 | O(n) mỗi token → không khả thi với vocab lớn |
| Tái dùng split đã lưu (`key_data/*.npy`) | cả 3 | so sánh các phiên bản trên cùng split |
| `get_corpus.py` Reveal: bỏ filter ≤200 ký tự + cap 40k | Reveal | debug leftover → corpus w2v chỉ 459KB, vocab 1.063 |
| Bật `class_weight` trong `model.fit` | Bagheri | dữ liệu block-level mất cân bằng nặng |
| Tắt print ma trận embedding khổng lồ | cả 3 | vocab lớn in hàng chục MB ra console |

Sau khi sửa corpus: vocab w2v Reveal 1.063 → **43.254**; Devign 64.720; Bagheri(sql) 6.466.

## 6. Kết quả (finaltest, split 70/15/15 cố định)

Số bài báo (Table 5–6) để đối chiếu:

| Tập | Acc | Pre | Rec | F1 | MCC |
|---|---|---|---|---|---|
| Devign (paper) | 71,9 | 62,0 | 69,0 | **65,3** | 0,35 |
| Reveal (paper) | 94,5 | 40,9 | 93,1 | **56,8** | 0,59 |
| Bagheri-SQL (paper, F1) | – | – | – | **96,5** | – |

Kết quả tái lập:

| Tập | Acc | Pre | Rec | F1 | MCC | AUC |
|---|---|---|---|---|---|---|
| Reveal v1 (w2v corpus lỗi) | 75,5 | 23,3 | 64,6 | 34,2 | 0,276 | 0,785 |
| Reveal v2 (corpus đầy đủ) | *(đang train)* | | | | | |
| Devign | *(đang train)* | | | | | |
| Bagheri-SQL | *(đang train)* | | | | | |

## 7. Nhận định sơ bộ

- Khoảng cách so với số bài báo là **dự kiến được** với artifact công bố: fusion không được huấn luyện,
  không có GGNN, và node2vec của Devign/Bagheri phải tự sinh (bài báo không mô tả tham số walk).
- Các khoảng cách 4.1–4.4 chính là chỗ luận văn cải tiến: GNN thật trên PDG từng hàm (đúng như bài báo
  *tuyên bố*), fusion attention huấn luyện end-to-end, và frontend chuyên biệt Java (`javasrc2cpg` đã sẵn trong Joern).
