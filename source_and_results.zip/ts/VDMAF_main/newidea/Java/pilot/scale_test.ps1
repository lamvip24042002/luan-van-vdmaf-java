# Scale test: javasrc2cpg + dump_graph.sc on a Juliet CWE89 subfolder.
# Measures parse time, dump time, method/edge counts.
param([string]$SrcDir, [string]$Tag = "cwe89")

$pilot = "C:\Users\ADMIN\Desktop\ts\VDMAF_main\newidea\Java\pilot"
$dump = "C:\Users\ADMIN\Desktop\ts\VDMAF_main\newidea\Devign\graph\dump_graph.sc"

$nFiles = (Get-ChildItem $SrcDir -Recurse -Filter "*.java" | Measure-Object).Count
Write-Output "files: $nFiles  ($SrcDir)"

$t1 = Measure-Command { & "C:\tools\joern-cli\javasrc2cpg.bat" $SrcDir --output "$pilot\$Tag.cpg" }
Write-Output ("javasrc2cpg: {0:N1}s" -f $t1.TotalSeconds)

Set-Location $pilot
$t2 = Measure-Command { & "C:\tools\joern-cli\joern.bat" --script $dump --param """cpgFile=$pilot\$Tag.cpg""" --param """outFile=$pilot\graph_$Tag.txt""" }
Write-Output ("joern dump: {0:N1}s" -f $t2.TotalSeconds)

$m = 0; $n = 0; $edges = @{}
Get-Content "$pilot\graph_$Tag.txt" | ForEach-Object {
    if ($_.StartsWith('#M')) { $m++ }
    elseif ($_.StartsWith('N')) { $n++ }
    elseif ($_.StartsWith('E')) {
        $t = ($_ -split "`t")[3]
        if ($edges.ContainsKey($t)) { $edges[$t]++ } else { $edges[$t] = 1 }
    }
}
Write-Output "methods: $m | nodes: $n"
$edges.GetEnumerator() | Sort-Object Value -Descending | ForEach-Object { Write-Output ("edge {0}: {1}" -f $_.Key, $_.Value) }
