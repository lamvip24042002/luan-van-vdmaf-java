# Phân tích PCFinder (TIFS 2025) — kỹ thuật đặc thù Java & khả năng áp dụng vào VDMAF

Nguồn: Shi et al., "Facilitating Access Control Vulnerability Detection in Modern Java Web
Applications With Accurate Permission Check Identification", IEEE TIFS vol. 20, 2025,
pp. 10683–10698. Source code: `PCFinder-main/` (986 dòng CodeQL + 2.712 dòng Python).

Tóm tắt phương pháp: PCFinder nhận diện **permission check** (câu lệnh if kiểm tra quyền
trước thao tác đặc quyền) trong ứng dụng web Java bằng 2 module: (1) suy luận **credential**
qua mô hình đặt tên tiến hóa (root words → lan truyền data-flow → mở rộng bằng Apriori);
(2) xác định permission check qua **phân tích ngữ cảnh condition–body** của if. Từ đó phát
hiện lỗ hổng thiếu/không nhất quán permission check. Kết quả: 486 permission check
(precision 91,35%), 58 lỗ hổng 0-day (30 CVE); trên ground truth: P 94,12% / R 96,97%.

---

## PHẦN 1 — Các chi tiết kỹ thuật ĐẶC THÙ JAVA (không áp dụng nguyên xi cho ngôn ngữ khác)

### 1.1. Credential nằm trong **class field** và truy cập qua **getter/setter (JavaBean)**
- Bài báo (Challenge I, tr. 10685): Java **không có** biến global/super-global như PHP
  (`$_SESSION['role']` — hook mà MACE dựa vào); credential nằm rải trong hàng nghìn class
  field không có gì phân biệt về cú pháp khai báo. Đây là *lý do tồn tại* của cả mô hình
  đặt tên tiến hóa — tức thành phần sáng tạo nhất của bài báo sinh ra từ một đặc điểm
  ngôn ngữ Java.
- Bài báo (§IV-A2a, tr. 10688): phân tích lan truyền bắt đầu từ **call site của getter**
  (`SysUser.userId` truy cập qua `SysUser.getUserId()`).
- Code: `python/pcfinder.py` dòng 215 & 236 tự sinh tên getter theo đúng quy ước JavaBean:
  `method = f"get{field[:1].upper()}{field[1:]}"`; query CodeQL
  `codeql/code/extended_user_related_class.ql` dùng lớp `SetterMethod`/`GetterMethod`
  (khái niệm riêng của thư viện CodeQL-Java).
- Vì sao không áp dụng ngôn ngữ khác: PHP/Python/JS không có quy ước getter/setter bắt
  buộc kiểu JavaBean; PHP có super-globals nên bài toán nhận diện credential dễ hơn hẳn
  (MACE chỉ cần người dùng gán nhãn vài super-global).

### 1.2. Lọc kiểu tĩnh: credential chỉ thuộc **7 kiểu dữ liệu Java**
- Bài báo (§IV-A1, tr. 10688): lọc `<int, short, long, boolean, char, String, enum>`
  (đối chiếu Java tutorial/documentation chính thức) — "type-sensitive naming model-based
  analysis".
- Code: `pcfinder.py` hàm `normalize()` thay tên biến bằng **kiểu tĩnh** của nó
  (`if var.type != "String": condition.replace(var.name, var.type)`) khi chuẩn hóa
  điều kiện để gom nhóm.
- Vì sao đặc thù Java: đòi hỏi hệ kiểu tĩnh khai báo tường minh. PHP/Python/JS là
  dynamic typing — không tồn tại "kiểu của field" ở mức khai báo để lọc; `enum` càng
  không có ở PHP cổ điển.

### 1.3. Tách **camelCase** + stemming WordNet cho tên định danh
- Bài báo (§IV-A2b, tr. 10688): "class fields are generally named following the
  conventions of camel case naming in Java applications" — `contentPermissions` →
  `<content, permiss>`.
- Vì sao đặc thù: camelCase là quy ước Java (Oracle/Google style); PHP/Python phổ biến
  snake_case, Ruby snake_case — bước tách chữ phải viết lại. (Ý tưởng "tên mang ngữ
  nghĩa" thì tổng quát, nhưng bộ tách được hiệu chỉnh cho Java.)

### 1.4. Mô hình hóa **web framework Java**: controller là entry point, interceptor/AOP
- Bài báo (§IV-C1, tr. 10690): "designates the controllers of the application as user
  entries" — entry point là controller của Spring Boot/Spring MVC/Struts (annotation
  `@Controller/@RequestMapping`), dùng làm nguồn taint cho phân tích "credential có bị
  user điều khiển không" và làm gốc trích execution path.
- Code: `pcfinder.py` có `is_in_interceptor()` (interceptor — cơ chế đặc thù Spring);
  `config.py` có `IF_AOP_SARIF_PATH` (AOP — lập trình hướng khía cạnh kiểu Spring);
  `codeql/cfg/if_true_sso.ql` (mẫu kiểm tra qua framework SSO/security kiểu Shiro/
  Spring Security).
- Vì sao đặc thù: PHP truyền thống route theo file; cơ chế interceptor/AOP/annotation
  là hạ tầng riêng của hệ sinh thái Java.

### 1.5. Ngữ nghĩa **ngắt luồng** theo idiom Java: throw / redirect / return-wrapper
- Bài báo (§IV-B2b, tr. 10689–10690): 3 loại interruption — ném exception, redirect
  (trang login/forbidden), return đóng gói (`return responseUtil.unlogin()`); thống kê
  thực nghiệm 84,38% permission check ngắt luồng khi fail.
- Code: 3 query CFG riêng `if_throw.ql`, `if_redirect.ql`, `if_return.ql`;
  `if_redirect.ql` còn xử lý cả cấu trúc `try/catch` bọc redirect (`TryStmt`,
  `getACatchClause`) — cấu trúc exception là của Java.
- Vì sao đặc thù: PHP hay dùng `die()/exit()`; mô hình exception + servlet redirect
  (`response.sendRedirect`) là idiom Java web.

### 1.6. Danh sách **42 API đặc quyền của JDK**
- Bài báo (§IV-B2b, tr. 10689): rà soát tài liệu Java chính thức, chốt 42 API — ví dụ
  `java.sql.Statement.executeQuery` (DB), `java.io.FileOutputStream.write` (file),
  `java.net.URL` (network).
- Vì sao đặc thù: đây là chữ ký API chuẩn JDK; mỗi ngôn ngữ khác phải xây danh sách
  riêng (PHP: `mysqli_query`, `fopen`…).

### 1.7. Chọn **source code** thay bytecode vì tên định danh — và loại trừ code sinh tự động
- Bài báo (§VI-D, tr. 10695): buộc phân tích source vì tên biến (nguyên liệu của naming
  model) bị mất/obfuscate khi biên dịch sang bytecode; thảo luận Soot/WALA — toolchain
  Java. (§V-E): loại code do **MyBatis Generator** sinh (chiếm >50% source ở nhiều app) —
  đặc thù hệ sinh thái Java.

### 1.8. Điều gì KHÔNG đặc thù Java (chính bài báo thừa nhận)
§VI-C (tr. 10695): "its high-level design is almost independent of any specific features
of the Java language". Tức là: ý tưởng tầng cao (tên định danh mang ngữ nghĩa an ninh;
permission check = điều kiện kiểm credential + thân chứa thao tác đặc quyền/ngắt luồng)
là tổng quát; **cái đặc thù Java là toàn bộ tầng "móc nối"** (1.1–1.7). Phân biệt này
quan trọng khi viết luận văn: đề tài của ta cũng đi đúng con đường "giữ khung tổng quát,
chuyên biệt hóa tầng móc nối cho Java".

---

## PHẦN 2 — Khả năng áp dụng vào các thành phần VDMAF (kèm dẫn chứng, không bịa số)

Quy ước: "VDMAF-Java" = pipeline luận văn đang xây (Joern javasrc2cpg → PDG →
R-GCN + BiLSTM + cross-attention fusion, dataset MegaVul Java 41.949 hàm).

### 2.1. Kênh NGỮ NGHĨA (tokenizer + embedding) — ÁP DỤNG ĐƯỢC, mức cao
**Ý tưởng chuyển giao:** tên định danh Java mang ngữ nghĩa an ninh → chiến lược chuẩn hóa
token của VDMAF-Java **không được xóa tên biến** (không abstract kiểu VAR1/VAR2 như nhiều
pipeline C), và nên **đánh dấu lớp token "giống credential"**.
**Dẫn chứng từ bài báo:** ablation Table II (tr. 10692) — tắt phân tích ngữ nghĩa tên
(biến thể OnlyInitialModel) làm recall nhận diện credential rơi từ **98,59% xuống 13,70%**;
tắt ngữ cảnh (ContextUnaware) làm precision permission check rơi từ **94,12% xuống 58,90%**.
Đây là bằng chứng định lượng (của chính tác giả) rằng ngữ nghĩa tên định danh là tín hiệu
mạnh trong an ninh Java.
**Hiện trạng VDMAF-Java của ta:** vocab 35.909 token đã giữ nguyên tên định danh (đúng
hướng). Việc bổ sung: thêm cờ token `is_credential_like` (tên chứa root word kiểu
role/pass/permiss sau tách camelCase + stemming). Phần lọc theo kiểu (7 kiểu Java) cần
mở rộng `dump_graph_java.sc` để xuất thêm kiểu khai báo của node Local/Field — Joern có
sẵn thuộc tính `typeFullName`, chi phí sửa nhỏ.

### 2.2. Kênh CẤU TRÚC (PDG: CDG/DDG) — ÁP DỤNG ĐƯỢC, trùng khớp trực tiếp với đề tài
**Ý tưởng chuyển giao:** định nghĩa permission check của PCFinder chính là một **mẫu phụ
thuộc điều khiển**: thao tác đặc quyền/câu lệnh ngắt trong if-body **phụ thuộc điều khiển
(CDG)** vào điều kiện kiểm credential. Còn "credential propagation" và "controllability
analysis" chính là **phụ thuộc dữ liệu (DDG/taint)**. Tức là hai quan hệ trung tâm của
đề tài (CDG + DDG) cũng chính là hai trục phân tích của PCFinder.
**Dẫn chứng bài báo:** §III-A key insight 2 (condition + body); Observation#2 (97,51%
permission check là if; 84,38% ngắt luồng khi fail); repo có nguyên thư mục
`codeql/pdg/source_to_if_control_pdg.ql` — dùng taint-tracking CodeQL từ nguồn tin cậy
đến điều kiện if.
**Dẫn chứng từ thí nghiệm của ta (đã đo, phiên 2026-07-05):** cấu hình fusion chỉ dùng
cạnh CDG+DDG đạt PR-AUC 0,499±0,011 so với 0,504±0,016 khi dùng đủ 4 loại cạnh trên
MegaVul Java (5 seeds) — hai nguồn độc lập (PCFinder bằng luật, ta bằng học máy) cùng
hội tụ về kết luận: **quan hệ phụ thuộc điều khiển/dữ liệu gánh phần lớn ngữ nghĩa an
ninh Java**. Đây là đoạn "related work ủng hộ thiết kế" rất tốt cho luận văn.
**Bổ sung cụ thể khả thi (v2):** thêm thuộc tính node vào đồ thị PyG hiện có:
- `is_privileged_op`: tên call trùng danh sách API đặc quyền (kiểu 42 API của PCFinder;
  token `executeQuery`, `write`, `URL`… đã có sẵn trong dump của ta — ví dụ taint-check
  pilot của ta dùng đúng `java.sql.Statement.executeQuery`);
- `is_interruption`: node `throw`/`return`/call `sendRedirect` (token ControlStructure
  "throw" và "return" đã có trong dump);
- `flows_from_param`: node có đường REACHING_DEF xuất phát từ MethodParameterIn (xấp xỉ
  nội hàm của "user-controllable" — tính được ngay từ DDG hiện có).

### 2.3. Fusion & classifier — ÁP DỤNG GIÁN TIẾP
PCFinder không có mô hình học nên không có gì "cắm" trực tiếp vào fusion. Giá trị gián
tiếp: các cờ ngữ cảnh ở 2.1–2.2 làm giàu không gian đặc trưng cho cả hai kênh trước khi
fusion; và cách PCFinder chuẩn hóa điều kiện if (thay biến bằng kiểu, thay toán tử so
sánh bằng [OP] — `pcfinder.py normalize()`) gợi ý một phép chuẩn hóa token bổ sung
đáng thử ở kênh ngữ nghĩa.

### 2.4. Dữ liệu & nhãn — ÁP DỤNG ĐƯỢC một phần, có tài nguyên tái dùng ngay
- **Phạm vi lỗ hổng:** PCFinder nhắm riêng broken access control; trong MegaVul Java của
  ta (đã đo 2026-07-04), nhóm CWE liên quan access control trong top-10 gồm CWE-264
  (94 hàm lỗi) và CWE-668 (59 hàm lỗi) — tức nhóm này là thiểu số so với XSS/XXE/SQLi.
  Kết luận trung thực: kỹ thuật PCFinder giúp **một lát cắt** của bài toán VDMAF-Java,
  không thay thế toàn bộ.
- **Tài nguyên tái dùng:** repo mở kèm `empirical data/Evaluation-Permission Check GT.json`
  (ground truth permission check từ PublicCMS + FlyCms; bài báo: 71 credential + 99
  permission check, công gán nhãn >165 giờ người) — có thể dùng làm **nhiệm vụ phụ trợ**
  (auxiliary task: node/method nào là permission check) để huấn luyện đa nhiệm kênh GNN,
  hoặc làm test bộ đặc trưng 2.2 mà không tốn công gán nhãn.

### 2.5. Những gì KHÔNG chuyển giao được (nói rõ để tránh hứa hão)
1. **Phân tích liên thủ tục toàn ứng dụng:** PCFinder chạy trên cả app (controller →
   privileged op, lan truyền credential giữa các chức năng như roleId→memberId).
   VDMAF/MegaVul là **function-level** trên snippet cô lập — không thể tái hiện lan
   truyền xuyên hàm/xuyên class; chỉ xấp xỉ được phần nội hàm.
2. **Vòng lặp tiến hóa naming model bằng Apriori trên 50 ứng dụng:** cần kho class field
   của nhiều ứng dụng nguyên vẹn; dataset function-level không có thông tin này. Chỉ
   "mượn" được sản phẩm cuối (bộ root word) chứ không mượn được quy trình.
3. **Chiến lược phát hiện lỗ hổng missing/inconsistent check** (so khớp tuple điều kiện
   giữa các execution path cùng nhóm thao tác DB): là phân tích đường đi toàn app,
   ngoài phạm vi phân loại hàm.
4. Lưu ý tái lập: file `python/Rules/english_rules.py` trong bản open-source có các danh
   sách từ (verbs/nouns/owners/operations) **để trống** — muốn dùng đúng bộ luật của
   nhóm tác giả sẽ phải tự điền lại từ mô tả trong bài báo.

### 2.6. Đề xuất hành động cho luận văn (xếp theo chi phí/lợi ích)
1. (Rẻ, làm được ngay) Thêm 3 cờ node `is_credential_like` / `is_privileged_op` /
   `is_interruption` + `flows_from_param` vào loader PyG; chạy lại v1 đa seed → một
   ablation mới "đặc trưng ngữ cảnh an ninh kiểu PCFinder".
2. (Vừa) Mở rộng dump Joern xuất `typeFullName` để tái hiện bộ lọc 7 kiểu của PCFinder.
3. (Vừa) Dùng GT permission check của PCFinder làm auxiliary task / sanity benchmark.
4. (Viết luận văn) Dùng PCFinder làm related work chủ lực cho luận điểm "chuyên biệt hóa
   Java nằm ở tầng móc nối ngôn ngữ, không phải ở khung tổng quát" — trùng khớp thiết kế
   đề tài; và trích ablation của họ như bằng chứng độc lập cho giá trị của CDG/DDG +
   ngữ nghĩa tên định danh.
