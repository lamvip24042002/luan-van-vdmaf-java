# -*- coding: utf-8 -*-
# Export ALL MegaVul-Java functions as wrapped .java files in batches of 2000
# (wrapper class name == file name, required-ish by parsers) + one labels TSV.
# Output: src_all/batch_XX/Fnnnnnn.java, labels_all.tsv
import os
import pandas as pd

BATCH = 2000
d = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "megavul"))
out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "src_all")

splits = {
    "train": "train-00000-of-00001.parquet",
    "validation": "validation-00000-of-00001.parquet",
    "test": "test-00000-of-00001.parquet",
}
frames = []
for name, fn in splits.items():
    df = pd.read_parquet(os.path.join(d, fn))
    df["split"] = name
    frames.append(df)
df = pd.concat(frames, ignore_index=True)
print("total functions:", len(df))

rows = []
for gid, row in df.iterrows():
    fid = "F%06d" % gid
    bdir = os.path.join(out, "batch_%02d" % (gid // BATCH))
    os.makedirs(bdir, exist_ok=True)
    with open(os.path.join(bdir, fid + ".java"), "w", encoding="utf-8") as f:
        f.write("public class %s {\n%s\n}\n" % (fid, row["input"]))
    cwe = row["cwe_ids"]
    cwe = ";".join(list(cwe)) if cwe is not None and len(cwe) > 0 else ""
    rows.append("%s\t%s\t%d\t%s\t%s" % (fid, row["split"],
                int(row["is_vulnerable"]), str(row["func_name"]), cwe))

lbl = os.path.join(os.path.dirname(os.path.abspath(__file__)), "labels_all.tsv")
with open(lbl, "w", encoding="utf-8") as f:
    f.write("fid\tsplit\tlabel\tfunc_name\tcwe\n")
    f.write("\n".join(rows))
print("wrote", len(rows), "files in", (len(df) + BATCH - 1) // BATCH, "batches")
print("labels ->", lbl)
