$conda = "C:\Users\ADMIN\miniconda3\condabin\conda.bat"
Set-Location "C:\Users\ADMIN\Desktop\ts\VDMAF_main\newidea\Java\gnn"
$runs = @(
    @("v1_both",        "both", "all"),
    @("v1_gnn",         "gnn",  "all"),
    @("v1_seq",         "seq",  "all"),
    @("v1_both_cdgddg", "both", "cdg_ddg")
)
foreach ($r in $runs) {
    $name, $ch, $ed = $r
    Write-Output "=== RUN $name (channels=$ch edges=$ed)  $(Get-Date -Format HH:mm:ss) ==="
    & $conda run -n vdmaf-gnn python -u train_v1.py --channels $ch --edges $ed --epochs 25 --patience 5 --out "runs/$name"
    Write-Output "=== RUN $name FINISHED  $(Get-Date -Format HH:mm:ss) ==="
}
Write-Output "=== ALL RUNS DONE  $(Get-Date -Format HH:mm:ss) ==="
