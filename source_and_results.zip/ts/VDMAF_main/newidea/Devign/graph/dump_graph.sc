// Dump per-method graph (token-labelled nodes + typed edges) from a CPG.
// Usage: joern --script dump_graph.sc --param cpgFile=<path> --param outFile=<path>
// Output format (tab-separated):
//   #M <methodName>
//   N <nodeId> <token>
//   E <srcId> <dstId> <edgeType>
import io.shiftleft.codepropertygraph.generated.nodes._

val opMap = Map(
  "<operator>.assignment" -> "=", "<operator>.addition" -> "+",
  "<operator>.subtraction" -> "-", "<operator>.multiplication" -> "*",
  "<operator>.division" -> "/", "<operator>.modulo" -> "%",
  "<operator>.lessThan" -> "<", "<operator>.greaterThan" -> ">",
  "<operator>.lessEqualsThan" -> "<=", "<operator>.greaterEqualsThan" -> ">=",
  "<operator>.equals" -> "==", "<operator>.notEquals" -> "!=",
  "<operator>.logicalAnd" -> "&&", "<operator>.logicalOr" -> "||",
  "<operator>.logicalNot" -> "!", "<operator>.and" -> "&",
  "<operator>.or" -> "|", "<operator>.xor" -> "^",
  "<operator>.shiftLeft" -> "<<", "<operator>.arithmeticShiftRight" -> ">>",
  "<operator>.not" -> "~", "<operator>.indirection" -> "*",
  "<operator>.addressOf" -> "&", "<operator>.fieldAccess" -> ".",
  "<operator>.indirectFieldAccess" -> "->", "<operator>.indexAccess" -> "[]",
  "<operator>.indirectIndexAccess" -> "[]", "<operator>.cast" -> "(cast)",
  "<operator>.preIncrement" -> "++", "<operator>.postIncrement" -> "++",
  "<operator>.preDecrement" -> "--", "<operator>.postDecrement" -> "--",
  "<operator>.assignmentPlus" -> "+=", "<operator>.assignmentMinus" -> "-=",
  "<operator>.assignmentMultiplication" -> "*=", "<operator>.assignmentDivision" -> "/=",
  "<operator>.minus" -> "-", "<operator>.plus" -> "+",
  "<operator>.conditional" -> "?", "<operator>.sizeOf" -> "sizeof"
)

def clean(s: String): String =
  s.replace("\t", " ").replace("\r", " ").replace("\n", " ").trim

def token(n: StoredNode): String = n match {
  case c: Call =>
    if (c.name.startsWith("<operator>")) opMap.getOrElse(c.name, "")
    else c.name
  case i: Identifier      => i.name
  case f: FieldIdentifier => f.canonicalName
  case l: Literal         => clean(l.code)
  case m: Method          => m.name
  case p: MethodParameterIn => p.name
  case lo: Local          => lo.name
  case _: Return          => "return"
  case cs: ControlStructure => cs.controlStructureType.toLowerCase
  case _ => ""
}

@main def exec(cpgFile: String, outFile: String) = {
  importCpg(cpgFile)
  run.ossdataflow
  val pw = new java.io.PrintWriter(
    new java.io.OutputStreamWriter(
      new java.io.FileOutputStream(outFile), "UTF-8"))
  var nMeth = 0
  cpg.method.isExternal(false).nameNot("<global>").foreach { m =>
    val nodes = m.ast.l
    val ids   = nodes.map(_.id).toSet
    pw.println("#M\t" + clean(m.name))
    nodes.foreach { n =>
      val t = token(n)
      if (t.nonEmpty && !t.contains(" "))
        pw.println("N\t" + n.id + "\t" + t)
    }
    def dump(src: StoredNode, label: String, dsts: Iterator[StoredNode]): Unit =
      dsts.foreach { d =>
        if (ids.contains(d.id))
          pw.println("E\t" + src.id + "\t" + d.id + "\t" + label)
      }
    nodes.foreach { n =>
      dump(n, "AST", n._astOut.iterator)
      dump(n, "CFG", n._cfgOut.iterator)
      dump(n, "CDG", n._cdgOut.iterator)
      dump(n, "REACHING_DEF", n._reachingDefOut.iterator)
    }
    nMeth += 1
  }
  pw.close()
  println(s"dumped $nMeth methods -> $outFile")
}
