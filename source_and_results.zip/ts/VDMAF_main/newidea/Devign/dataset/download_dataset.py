# -*- coding: utf-8 -*-
# Download the Devign dataset (CodeXGLUE defect detection = FFmpeg + qemu)
# from HuggingFace parquet and write it as the JSON array file `function`
# that get_corpus.py / dataset.py / makemodel.py expect.
import io
import json
import requests
import pandas as pd

BASE = ("https://huggingface.co/api/datasets/"
        "google/code_x_glue_cc_defect_detection/parquet/default/%s/0.parquet")

frames = []
for split in ["train", "validation", "test"]:
    print("downloading", split, "...")
    r = requests.get(BASE % split, timeout=300)
    r.raise_for_status()
    df = pd.read_parquet(io.BytesIO(r.content))
    print(split, len(df), "rows")
    frames.append(df)

df = pd.concat(frames, ignore_index=True)
print("total:", len(df))
print(df["project"].value_counts())

records = [
    {"project": row.project,
     "commit_id": row.commit_id,
     "target": int(row.target),
     "func": row.func}
    for row in df.itertuples(index=False)
]

with open("function", "w", encoding="utf-8") as f:
    json.dump(records, f)
print("written -> function")
