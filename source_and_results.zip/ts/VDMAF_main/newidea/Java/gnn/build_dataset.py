# -*- coding: utf-8 -*-
# Build the PyG-ready graph dataset from the MegaVul-Java CPG dumps.
#
# Unit = one MegaVul function (one wrapper file Fnnnnnn.java). We merge every
# method dumped for that file EXCEPT <init>/<clinit> (trivial auto-generated
# constructors), so lambdas / anonymous-class bodies inside the function stay
# in the graph as disjoint components.
#
# Per graph:  x = token-vocab ids (long), edge_index (2,E), edge_type (E)
#             with AST=0 CFG=1 CDG=2 DDG(REACHING_DEF)=3, y = label.
# Node features stay as VOCAB IDS (embedding lookup happens in the model —
# same RAM-safe pattern as the baseline fix); vocab built with min_count>=5,
# 0=PAD 1=UNK.
#
# Output (Java/gnn/dataset/): vocab.json, train.pt, validation.pt, test.pt,
# stats.json. Streaming, RAM-light. Run inside env vdmaf-gnn.
import glob
import json
import os
from collections import Counter

import torch

HERE = os.path.dirname(os.path.abspath(__file__))
# Use the same node-kind-aware dump as build_dataset_v2.py.  This makes a
# clean-room +/- PCFinder comparison differ only in x_flags, rather than in the
# underlying Joern export.
DUMPS = sorted(glob.glob(os.path.join(HERE, "..", "graph", "dumps_v2", "graph_batch_*.txt")))
LABELS = os.path.join(HERE, "..", "graph", "labels_all.tsv")
OUT = os.path.join(HERE, "dataset")
os.makedirs(OUT, exist_ok=True)

MIN_COUNT = 5
MAX_NODES = 2000          # p99-safety cap; overflow nodes (+ incident edges) dropped
EDGE_TYPES = {"AST": 0, "CFG": 1, "CDG": 2, "REACHING_DEF": 3}
SKIP_METHODS = {"<init>", "<clinit>"}

labels = {}
with open(LABELS, encoding="utf-8") as f:
    next(f)
    for line in f:
        p = line.rstrip("\n").split("\t")
        labels[p[0]] = (p[1], int(p[2]))


def fid_of(path):
    base = os.path.basename(path)
    return base[:-5] if base.endswith(".java") else None


def iter_methods():
    """Yield (fid, method_name, nodes{id:token}, edges[(src,dst,type)]) per #M block."""
    for path in DUMPS:
        with open(path, encoding="utf-8") as f:
            name, fid, nodes, edges = None, None, {}, []
            for line in f:
                if line.startswith("#M"):
                    if name is not None:
                        yield fid, name, nodes, edges
                    p = line.rstrip("\n").split("\t")
                    name, fid, nodes, edges = p[1], fid_of(p[2]), {}, []
                elif line.startswith("N"):
                    p = line.rstrip("\n").split("\t")
                    nodes[p[1]] = p[2]
                elif line.startswith("E"):
                    p = line.rstrip("\n").split("\t")
                    edges.append((p[1], p[2], p[3]))
            if name is not None:
                yield fid, name, nodes, edges


# ---- pass 1: token vocabulary over kept methods ----
print("pass 1: vocabulary...")
cnt = Counter()
for fid, name, nodes, edges in iter_methods():
    if fid is None or fid not in labels or name in SKIP_METHODS:
        continue
    cnt.update(nodes.values())
vocab = {"<pad>": 0, "<unk>": 1}
for tok, c in cnt.most_common():
    if c >= MIN_COUNT:
        vocab[tok] = len(vocab)
with open(os.path.join(OUT, "vocab.json"), "w", encoding="utf-8") as f:
    json.dump(vocab, f)
n_tok_total = sum(cnt.values())
n_tok_unk = sum(c for t, c in cnt.items() if t not in vocab)
print("vocab size:", len(vocab), "| UNK token rate: %.2f%%" % (100.0 * n_tok_unk / n_tok_total))

# ---- pass 2: merge methods per fid, tensorize ----
print("pass 2: building graphs...")
graphs = {}   # fid -> {"tokens": [...], "edges": [(si,di,t)], "id2idx": {}}
for fid, name, nodes, edges in iter_methods():
    if fid is None or fid not in labels or name in SKIP_METHODS:
        continue
    g = graphs.setdefault(fid, {"tokens": [], "edges": [], "id2idx": {}})
    id2idx = g["id2idx"]
    for nid, tok in nodes.items():
        if nid not in id2idx and len(g["tokens"]) < MAX_NODES:
            id2idx[nid] = len(g["tokens"])
            g["tokens"].append(vocab.get(tok, 1))
    for s, d, t in edges:
        si, di = id2idx.get(s), id2idx.get(d)
        if si is not None and di is not None:
            g["edges"].append((si, di, EDGE_TYPES[t]))

data = {"train": [], "validation": [], "test": []}
skipped_empty = 0
capped = 0
edge_hist = Counter()
node_counts = []
for fid, (split, y) in labels.items():
    g = graphs.get(fid)
    if g is None or len(g["tokens"]) == 0 or len(g["edges"]) == 0:
        skipped_empty += 1
        continue
    if len(g["tokens"]) >= MAX_NODES:
        capped += 1
    e = torch.tensor(g["edges"], dtype=torch.long)
    item = {
        "fid": fid,
        "x": torch.tensor(g["tokens"], dtype=torch.long),
        "edge_index": e[:, :2].t().contiguous(),
        "edge_type": e[:, 2].contiguous(),
        "y": y,
    }
    node_counts.append(len(g["tokens"]))
    for _, _, t in g["edges"]:
        edge_hist[t] += 1
    data[split].append(item)

for split, items in data.items():
    torch.save(items, os.path.join(OUT, split + ".pt"))
    nv = sum(it["y"] for it in items)
    print("%-11s graphs=%6d  vul=%5d (%.2f%%)" % (split, len(items), nv, 100.0 * nv / max(len(items), 1)))

node_counts.sort()
stats = {
    "vocab_size": len(vocab),
    "unk_token_rate": n_tok_unk / n_tok_total,
    "skipped_empty": skipped_empty,
    "capped_at_max_nodes": capped,
    "nodes_p50": node_counts[len(node_counts) // 2],
    "nodes_p90": node_counts[int(len(node_counts) * 0.9)],
    "nodes_p99": node_counts[int(len(node_counts) * 0.99)],
    "nodes_max": node_counts[-1],
    "edge_type_hist": {k: edge_hist[v] for k, v in EDGE_TYPES.items()},
    "splits": {s: len(v) for s, v in data.items()},
}
with open(os.path.join(OUT, "stats.json"), "w", encoding="utf-8") as f:
    json.dump(stats, f, indent=2)
print(json.dumps(stats, indent=2))
print("saved ->", OUT)
