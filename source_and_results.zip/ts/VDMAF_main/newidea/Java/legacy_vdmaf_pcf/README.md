# Tái dựng VDMAF-Java và phép thử ± PCFinder

Thư mục này là một **operational reconstruction** của nhánh Java theo mô tả
trong bài báo, không phải source chính thức của tác giả. Mục tiêu là tạo một
phép thử có kiểm soát: hai nhánh dùng cùng dữ liệu, Word2Vec, kiến trúc, seed,
số tham số và trạng thái khởi tạo; khác biệt duy nhất là bốn cờ node lấy cảm
hứng từ PCFinder.

## 1. Nguyên lý mô hình

Với một hàm Java, kênh ngữ nghĩa tạo chuỗi embedding

`S = Word2Vec(token_1, ..., token_T)`.

Kênh cấu trúc dùng graph Joern với bốn quan hệ `AST`, `CFG`, `CDG` và
`REACHING_DEF`. Trạng thái node ban đầu là

`h_v^0 = LayerNorm(Word2Vec(node_token_v) + W_f f_v)`.

Ở nhánh `off`, `f_v` là vector 0; ở nhánh `on`, `f_v` là bốn cờ PCFinder.
Module `W_f: 4 -> 300` luôn tồn tại trong cả hai nhánh. GGNN truyền thông tin
theo từng loại cạnh rồi cập nhật bằng GRU:

`m_v^t = sum_r sum_(u,v in E_r) W_r h_u^(t-1)`

`h_v^t = GRU(m_v^t, h_v^(t-1))`.

Fusion dùng multi-head cross-attention 10 head:

`C = MHA(Q=S, K=H_graph, V=H_graph)`

`Z = LayerNorm(S + C)`.

Chuỗi `Z` đi qua BiLSTM. Temporal attention đúng dạng của bài báo
`softmax(tanh(W_h h_i + b_h))` gộp toàn bộ time step, sau đó linear layer sinh
vulnerability logit.

Mặc định chính: Word2Vec 300 chiều, CBOW, `min_count=5`, 100 epoch; GGNN 2
bước; 10 attention heads; BiLSTM hidden 100 mỗi chiều; dropout 0,2; Adam
`lr=0,01`.

## 2. PCFinder được đưa vào ở đâu

`gnn/build_dataset_v2.py` dựng bốn cờ nhị phân cho mỗi node:

1. `is_credential_like`: token chứa gốc từ liên quan role/password/permission,
   auth, admin, token, user, owner, v.v.
2. `is_privileged_op`: node `CALL` gọi API thao tác DB/file/network đặc quyền.
3. `is_interruption`: `throw`, `return`, redirect/forward/sendError.
4. `flows_from_param`: node reachable từ `METHOD_PARAMETER_IN` qua cạnh
   `REACHING_DEF` có hướng.

Đây là **PCFinder-inspired proxy features** được tái dựng từ bài báo. Artifact
PCFinder trong repository thiếu `AuthIF` và các rule list phát hành đang rỗng,
vì vậy không được gọi đây là tích hợp nguyên bản PCFinder.

## 3. Vì sao baseline cũng đọc `dataset_v2`

Không so trực tiếp file `dataset/*.pt` lịch sử với `dataset_v2/*.pt`: hai lần
dump cũ có thứ tự/index cạnh khác nhau. Cả hai nhánh của thí nghiệm mới đọc
chính `dataset_v2`; nhánh baseline đưa `x_flags` về 0. Nhờ vậy chênh lệch
`on - off` chỉ đo thông tin PCFinder, không đo khác biệt graph export.

Mỗi run ghi SHA-256 của graph splits, sequence splits, vocab, embedding,
trainer, wrapper và aggregator. Aggregator còn kiểm tra số tham số và
`initial_state_sha256` của từng cặp.

## 4. Dựng lại dữ liệu từ đầu

Chạy từ thư mục `Java` trong environment `vdmaf-gnn`:

```powershell
conda activate vdmaf-gnn
python graph\export_all.py
powershell.exe -NoProfile -ExecutionPolicy Bypass -File graph\run_batches_java.ps1 -JoernHome C:\tools\joern-cli
python gnn\build_dataset.py
python gnn\build_seq.py
python gnn\build_dataset_v2.py
python graph\coverage_stats.py
```

Thứ tự là bắt buộc: `build_dataset.py` tạo `vocab.json`; `build_seq.py` tạo
`vocab_joint.json` và `seq_*.pt`; sau đó `build_dataset_v2.py` tái dùng vocab
để thêm flags. `run_batches_java.ps1`, baseline builder và v2 builder đều đã
được thống nhất về `graph/dumps_v2`.

Checkpoint hiện tại: 41.949 hàm raw; tensor usable là 31.448 train, 4.193
validation, 6.293 test (tổng 41.934; 15 graph rỗng/không có cạnh bị bỏ).

## 5. Dựng Word2Vec

Từ thư mục `legacy_vdmaf_pcf`:

```powershell
conda activate vdmaf-gnn
python build_word2vec.py
```

Script chỉ fit trên train split, dùng tokenizer case-sensitive giống
`gnn/build_seq.py`, một worker và stable MurmurHash. Artifact hiện tại có
25.564 token Word2Vec; phủ 71,20% hàng joint-vocab và 94,25% lượt token train.
Các file sinh ra nằm trong `artifacts/`.

## 6. Smoke và so sánh chính thức

Smoke kiểm tra plumbing, không dùng để kết luận:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_compare.ps1 -Mode smoke
```

Chạy đầy đủ 5 seed, tối đa 100 epoch và early stopping patience 10:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_compare.ps1 -Mode full
```

Có thể override trần epoch/batch/patience, nhưng phải coi đó là protocol khác:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_compare.ps1 `
  -Mode full -MaxEpochs 5 -EarlyStopPatience 5 `
  -OutputRoot .\runs_compare\pilot_5epoch
```

Mỗi run xuất `metrics.json`, `model.pt`, `validation_probs.npz`,
`test_probs.npz`, `run_spec.json` và `train.log`. `compare_summary.json` báo
mean ± sample std, paired difference `PCFinder on - off`, exact sign test và
paired Wilcoxon hai phía.

Primary metric là test PR-AUC của checkpoint có validation PR-AUC cao nhất.
Ngưỡng F1 được chọn **chỉ trên validation** rồi áp lên test (`f1@val_t`);
không sweep threshold trên test.

## 7. Kết quả pilot đã chạy

Protocol pilot dùng toàn bộ 31.448/4.193/6.293 graph, seed 42–46, 5 epoch,
batch 32, float32. Đây là **pilot checkpoint-limited**, không phải full run
100 epoch.

| Metric test | PCFinder off | PCFinder on | Paired mean `on-off` | Thắng/thua | Wilcoxon 2 phía |
|---|---:|---:|---:|---:|---:|
| PR-AUC | 0,1851 ± 0,0233 | 0,1507 ± 0,0227 | −0,0344 | 1/4 | 0,1250 |
| ROC-AUC | 0,7476 ± 0,0113 | 0,7342 ± 0,0169 | −0,0134 | 2/3 | 0,3125 |
| F1@validation-threshold | 0,2525 ± 0,0136 | 0,1869 ± 0,0722 | −0,0655 | 1/4 | 0,1875 |
| MCC@validation-threshold | 0,2057 ± 0,0116 | 0,1152 ± 0,1065 | −0,0904 | 1/4 | 0,1875 |

PR-AUC theo seed (`on-off`): 42: −0,0621; 43: −0,0163; 44: +0,0129;
45: −0,0667; 46: −0,0400. Exact sign-test hai phía là 0,375.

Diễn giải đúng mức: trong pilot này, bốn flags PCFinder **không cải thiện** bản
VDMAF cũ và giảm PR-AUC trung bình 0,0344 điểm tuyệt đối (khoảng 18,6% tương
đối so với baseline). Kết quả chưa có ý nghĩa thống kê và có thể thay đổi khi
chạy đủ 100 epoch/nhiều seed hơn. Chi tiết/audit nằm tại
`runs_compare/pilot_5epoch_fp32/compare_summary.json`.

## 8. Sai khác và giới hạn cần báo cáo

- Paper dùng một graph vector tổng; reconstruction dùng node states làm K/V và
  semantic residual. Với đúng một K/V, multi-head attention sẽ suy biến về
  weight 1, nên lựa chọn node-level làm fusion có ý nghĩa nhưng không phải
  source gốc.
- Paper ghi batch 256/float32. RTX 3060 12 GB dùng physical batch 32 và
  evaluation batch 16 nhưng vẫn giữ float32; đây là sai khác tài nguyên có
  kiểm soát. Trainer có tùy chọn `--amp`, song wrapper paired không bật nó vì
  GGNN sum aggregation với `lr=0,01` có thể mất ổn định số học trong FP16.
- Checkpoint chọn bằng validation PR-AUC thay vì validation F1 để phù hợp dữ
  liệu mất cân bằng.
- Word2Vec chỉ fit train, nhưng `vocab.json`/`vocab_joint.json` lịch sử được
  chọn từ cả ba split. Điều này không làm lệch phép thử paired ±flags, nhưng là
  vocabulary-selection leakage đối với đánh giá tuyệt đối. Protocol hoàn toàn
  inductive cần rebuild vocab từ train-only.
- Năm seed chỉ cho effect estimate: p-value nhỏ nhất của exact sign test hai
  phía là 0,0625. Muốn kiểm định mức 5% nên chạy ít nhất 10 seed.
- CUDA `index_add_` có thể không bitwise-deterministic trên mọi driver, dù
  wrapper bật deterministic mode và đặt `CUBLAS_WORKSPACE_CONFIG`.

Không diễn giải metric trong `runs_compare/smoke` như kết quả nghiên cứu.
