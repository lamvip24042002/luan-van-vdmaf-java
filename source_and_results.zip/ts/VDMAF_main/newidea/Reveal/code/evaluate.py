# -*- coding: utf-8 -*-
# Task 1: re-evaluate the trained model.h5 on the saved split.
# RAM-safe version: preallocated float32 arrays (no nested python lists),
# evaluates validation + finaltest only (~0.8 GB each), frees between splits.
# Vector construction mirrors makemodel.py: max-fusion of word2vec + node2vec
# over the common vocabulary, 'pre' pad/truncate to 200 tokens.
import json
import numpy as np
import tensorflow as tf
from gensim.models import Word2Vec
from tensorflow.keras.models import load_model
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, matthews_corrcoef, roc_curve, auc)
import myutils

MAXLEN = 200
DIM = 300

word_vectors = Word2Vec.load("Reveal_word2vec_5-100-300.model").wv
node_vectors = Word2Vec.load("node2vec_model-300.model").wv

common_tokens = set(word_vectors.key_to_index.keys()).intersection(
    set(node_vectors.key_to_index.keys()))
print("common tokens:", len(common_tokens))

# same max-fusion as makemodel.py, stored in a dict (order-safe)
token2vec = {t: np.maximum(word_vectors[t], node_vectors[t]).astype(np.float32)
             for t in common_tokens}

with open('../dataset/vulnerables.json', 'r') as v_file:
    vulnerables = json.load(v_file)
with open('../dataset/non-vulnerables.json', 'r') as nv_file:
    non_vulnerables = json.load(nv_file)

allblocks = []
for r in vulnerables:
    allblocks.append([r["code"], 1])
for r in non_vulnerables:
    allblocks.append([r["code"], 0])
print("Total blocks:", len(allblocks))

keystest = np.load('key_data/keystest_data.npy')
keysfinaltest = np.load('key_data/keysfinaltest_data.npy')
print("split sizes: val=%d finaltest=%d" % (len(keystest), len(keysfinaltest)))


def build_xy(keys):
    n = len(keys)
    X = np.zeros((n, MAXLEN, DIM), dtype=np.float32)
    Y = np.zeros(n, dtype=np.float32)
    for row, k in enumerate(keys):
        code, label = allblocks[k]
        vecs = [token2vec[t] for t in myutils.getTokens(code)
                if t != " " and t in token2vec]
        vecs = vecs[-MAXLEN:]                    # 'pre' truncation: keep last 200
        if vecs:
            X[row, MAXLEN - len(vecs):, :] = np.stack(vecs)  # 'pre' padding
        Y[row] = label
    return X, Y


model = load_model("model.h5", compile=False)

results = {}
for name, keys in [("validation", keystest), ("finaltest", keysfinaltest)]:
    X, y = build_xy(keys)
    yhat = model.predict(X, batch_size=256, verbose=0).ravel()
    del X                                        # free ~0.8 GB before next split
    yhat_classes = (yhat > 0.5).astype(int)
    fpr, tpr, _ = roc_curve(y, yhat)
    results[name] = dict(
        n=len(y), vul=int(y.sum()),
        accuracy=accuracy_score(y, yhat_classes),
        precision=precision_score(y, yhat_classes),
        recall=recall_score(y, yhat_classes),
        f1=f1_score(y, yhat_classes),
        mcc=matthews_corrcoef(y, yhat_classes),
        auc=auc(fpr, tpr))
    r = results[name]
    print("\n=== %s (n=%d, vul=%d) ===" % (name, r["n"], r["vul"]))
    for m in ["accuracy", "precision", "recall", "f1", "mcc", "auc"]:
        print("%-9s %.4f" % (m, r[m]))

with open("baseline_metrics_reveal.json", "w") as f:
    json.dump(results, f, indent=2)
print("\nsaved -> baseline_metrics_reveal.json")
