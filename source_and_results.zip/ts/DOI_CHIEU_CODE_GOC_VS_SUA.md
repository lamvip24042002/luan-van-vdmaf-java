# Đối chiếu mã nguồn: bản gốc VDMAF vs bản đã sửa (trích nguyên văn)

Tài liệu này bổ trợ cho `BAO_CAO_THAY_DOI_SOURCE_CODE.md`: trình bày **nguyên văn** từng
đoạn code trước/sau cho các thay đổi quan trọng nhất, để trình chiếu/giải trình với giảng
viên hướng dẫn.

**Nguồn đối chiếu:** mọi đoạn "TRƯỚC" được trích từ bản gốc nguyên vẹn `VDMAF_main.zip`
tải trực tiếp từ kho chính thức của tác giả (github.com/yangli12138/VDMAF, tải ngày
2026-07-06) — KHÔNG dựng lại từ trí nhớ. File diff đầy đủ máy sinh (730 dòng) lưu tại
`code_diffs_vs_upstream.txt` để kiểm chứng độc lập.

Ký hiệu mức ảnh hưởng như báo cáo chính: **[A]** sửa để chạy được · **[B]** sửa lỗi ngầm,
baseline trung thực hơn · **[C]** tương đương toán học.

---

## ĐỐI CHIẾU 1 — Bỏ bộ lọc debug cắt cụt dữ liệu [B] (quan trọng nhất)

**File:** `Reveal/code/get_corpus.py` (corpus word2vec) và `Reveal/code/makemodel.py`
(vòng nạp dữ liệu train/test).

**TRƯỚC (gốc) — get_corpus.py:**
```python
for r in data:
    if len(r["code"]) <= 200:
        progress = progress + 1
        if progress == 40000:
            break
        code = code + r["code"]
```

**TRƯỚC (gốc) — makemodel.py (vòng nạp mẫu train/test):**
```python
for r in vulnerables:
    if len(r["code"]) <= 200:
        progress = progress + 1
        if progress == 4000:
            break
        b = []
        b.append(r["code"])
        b.append('1')
        allblocks.append(b)
for r in non_vulnerables:
    if len(r["code"]) <= 200:
        progress = progress + 1
        if progress == 4000:
            break
        ...
```

**SAU (đã sửa):**
```python
# get_corpus.py
for r in data:
    progress = progress + 1
    code = code + r["code"]

# makemodel.py
for r in vulnerables:
    allblocks.append([r["code"], '1'])
for r in non_vulnerables:
    allblocks.append([r["code"], '0'])
```

**Vì sao phải sửa:** bản gốc chỉ giữ các hàm ≤200 **ký tự** (rất ngắn) và dừng ở mẫu thứ
4.000/40.000. Đặc biệt biến đếm `progress` **không được reset** giữa hai vòng lặp: nếu vòng
lặp hàm-lỗ-hổng đã đếm đến 4.000 thì vòng hàm-an-toàn bị bỏ qua gần hết — dữ liệu bị cắt
một cách méo mó, không phải lấy mẫu ngẫu nhiên. Hệ quả đo được: từ vựng word2vec chỉ còn
**1.063 token**; sau khi sửa là **43.254 token**. Không có dòng nào trong bài báo mô tả các
giới hạn này → đây là code gỡ lỗi bị bỏ quên, việc loại bỏ đưa baseline về ĐÚNG phương pháp
được công bố. (Bản gốc còn có `print(allblocks)` — in toàn bộ dataset ra màn hình — cũng
được gỡ.)

---

## ĐỐI CHIẾU 2 — Bật lại trọng số lớp bị chú thích [B]

**File:** `Reveal/code/makemodel.py`, `Bagheri/train_model/makemodel.py`.

**TRƯỚC (gốc):**
```python
# history = model.fit(X_train, y_train, epochs=epochs, batch_size=batchsize, class_weight=class_weights_dict)
history = model.fit(X_train, y_train, epochs=epochs, batch_size=batchsize)
```

**SAU (đã sửa):**
```python
history = model.fit(X_train, y_train, epochs=epochs, batch_size=batchsize, class_weight=class_weights_dict)
```

**Vì sao phải sửa:** dữ liệu Reveal chỉ có ~10% mẫu dương; không có trọng số lớp, mô hình
hội tụ về dự đoán toàn "an toàn" (recall ≈ 0). Chính mã gốc đã **tính sẵn**
`class_weights_dict` ngay phía trên (chứng tỏ ý định của tác giả), chỉ có dòng áp dụng bị
chú thích — nhiều khả năng là trạng thái dở dang khi tác giả thử nghiệm. Việc bật lại khôi
phục đúng thiết kế.

---

## ĐỐI CHIẾU 3 — Sửa chiều đầu vào sai [A]

**File:** `Reveal/code/makemodel.py` (Devign/Bagheri tương tự).

**TRƯỚC (gốc):**
```python
model.add(Bidirectional(LSTM(neurons, return_sequences=True), input_shape=(200, 600)))  # around 50 seems good
```

**SAU (đã sửa):**
```python
model.add(Bidirectional(LSTM(neurons, return_sequences=True), input_shape=(200, 300)))  # 300 = d_model of the multi-head attention fusion
```

**Vì sao phải sửa:** vector fusion có đúng `d_model = 300` chiều (tham số của chính bài
báo); con số 600 hard-code là tàn dư của một biến thể cũ (ghép nối 300+300). Giữ 600 thì
mô hình không nhận được dữ liệu (mismatch chiều) — code gốc không thể chạy tới bước huấn
luyện với đường dẫn mặc định.

---

## ĐỐI CHIẾU 4 — Sửa crash EagerTensor + tra cứu O(n) → O(1) [A]

**File:** `Devign/code/makemodel.py`, `Bagheri/train_model/makemodel.py`.

**TRƯỚC (gốc):**
```python
merged_vector_np = merged_vector          # vẫn là EagerTensor của TF

def get_token_vector(token, common_tokens, merged_vector_np):
    if token in common_tokens:
        token_index = list(common_tokens).index(token)   # quét tuyến tính mỗi token
        return merged_vector_np[token_index]
    else:
        return None
```

**SAU (đã sửa):**
```python
merged_vector_np = np.array(merged_vector)   # EagerTensor không có .tolist() → chuyển numpy

common_tokens_index = {t: i for i, t in enumerate(common_tokens)}  # cùng thứ tự vòng lặp gốc

def get_token_vector(token, common_tokens, merged_vector_np):
    idx = common_tokens_index.get(token)
    if idx is not None:
        return merged_vector_np[idx]
    return None
```

**Vì sao phải sửa:** (i) dòng dưới của code gốc gọi `.tolist()` trên vector trả về —
EagerTensor của TF 2.10 không có phương thức này → crash; (ii) `list(...).index(token)`
dựng lại list và quét tuyến tính cho MỖI token của MỖI hàm (hàng chục triệu lần quét trên
Devign). Bảng tra dict cho **kết quả giống hệt** (giữ nguyên thứ tự duyệt tập
`common_tokens` như vòng lặp gốc) nhưng nhanh hơn nhiều bậc.

---

## ĐỐI CHIẾU 5 — Nạp dữ liệu an toàn RAM: chỉ số int32 + Embedding đông cứng [C]

**File:** `Devign/code/makemodel.py`, `Bagheri/train_model/makemodel.py`.

**TRƯỚC (gốc)** — tiền tính vector 300 chiều cho từng token, lưu list Python lồng nhau:
```python
X_train = numpy.array(TrainX, dtype="object")      # TrainX = list các list vector .tolist()
...
X_train = sequence.pad_sequences(X_train, maxlen=200)
X_train = numpy.asarray(X_train).astype(numpy.float32)   # tensor (n, 200, 300) dày đặc
...
model.add(Bidirectional(LSTM(neurons, return_sequences=True), input_shape=(200, 600)))
```

**SAU (đã sửa)** — mẫu là chuỗi chỉ số; tra vector bên trong mô hình:
```python
# frozen embedding table: row 0 = padding (zero vector), row i+1 = fused vector
emb_matrix = np.zeros((len(common_tokens) + 1, 300), dtype=np.float32)
emb_matrix[1:] = np.asarray(merged_vector_np, dtype=np.float32)
...
X_train = sequence.pad_sequences(TrainX, maxlen=200)      # ma trận int32 (n, 200)
...
model.add(Embedding(input_dim=emb_matrix.shape[0], output_dim=300, input_length=200,
                    weights=[emb_matrix], trainable=False))   # đông cứng, không huấn luyện
model.add(Bidirectional(LSTM(neurons, return_sequences=True)))
```

**Vì sao phải sửa:** với Devign (27.318 hàm × ~150 token × 300 chiều, mỗi số là Python
float ~32 byte trong list lồng nhau) cách gốc cần **30–40GB RAM** — vượt 32GB của máy và
đã từng làm treo toàn hệ thống, buộc khởi động lại. Cách mới **tương đương toán học tuyệt
đối**: LSTM vẫn nhận đúng chuỗi vector fusion như trước (hàng 0 = vector không ứng với
padding, `trainable=False` bảo đảm bảng vector không đổi trong huấn luyện), nhưng RAM giảm
~1000 lần và tra cứu chạy trên GPU. Không ảnh hưởng số liệu — chỉ ảnh hưởng tài nguyên.

---

## ĐỐI CHIẾU 6 — Cố định split + seed để so sánh được [B]

**File:** cả ba `makemodel.py`.

**TRƯỚC (gốc)** — mỗi lần chạy xáo trộn và chia lại từ đầu:
```python
keys = []
for i in range(len(allblocks)):
    keys.append(i)
random.shuffle(keys)          # không seed → mỗi lần chạy một split khác
...
numpy.save('key_data/keystrain_data.npy', keystrain_data)   # lưu nhưng không bao giờ nạp lại
```

**SAU (đã sửa):**
```python
random.seed(42); np.random.seed(42); tf.random.set_seed(42)   # đầu file
...
# reuse the saved split when it exists so runs stay comparable
if os.path.isfile('key_data/keystrain_data.npy'):
    keystrain = numpy.load('key_data/keystrain_data.npy').tolist()
    ...
else:
    # (chia mới + lưu, đúng logic gốc)
```

**Vì sao phải sửa:** (i) mã gốc LƯU split ra file nhưng không bao giờ nạp lại — mỗi lần
chạy là một cách chia dữ liệu khác, không thể so sánh hai thí nghiệm với nhau; (ii) fusion
multi-head attention của artifact dùng trọng số **ngẫu nhiên không seed** — nghĩa là chính
"phương pháp" thay đổi giữa các lần chạy. Cố định seed 42 và tái sử dụng split là điều kiện
tối thiểu để mọi con số trong luận văn tái lập được (ở các thí nghiệm đa seed, seed được
tham số hóa thành 42–56).

---

## ĐỐI CHIẾU 7 — Sửa import theo phiên bản thư viện [A]

**File:** mọi `makemodel.py`, `myutils.py`.

```python
# TRƯỚC:
from keras.preprocessing import sequence
# SAU:
from tensorflow.keras.preprocessing import sequence
```

**Vì sao:** Keras 2.10 (đi kèm TF 2.10 — bản TF cuối hỗ trợ GPU gốc trên Windows) đã bỏ
`pad_sequences` khỏi đường dẫn cũ → `ImportError` ngay khi khởi động. Sửa 1 dòng, không đổi
hành vi.

---

## ĐỐI CHIẾU 8 — Tham số hóa `mode` cho Bagheri [B nhẹ/tiện ích]

**File:** `Bagheri/train_model/makemodel.py`, `Bagheri/w2v_embedding/get_corpus.py`.

```python
# TRƯỚC:
mode = "sql"
# mode = ["sql", "xsrf", "xss", ...]        # gợi ý trong comment nhưng phải sửa tay
# SAU:
mode = sys.argv[1] if len(sys.argv) > 1 else "sql"
```

**Vì sao:** bài báo báo cáo cả 7 loại lỗ hổng Python nhưng mã gốc hard-code `"sql"`, muốn
chạy loại khác phải sửa file bằng tay từng lần. Tham số hóa cho phép script tự động chạy
tuần tự 7 mode (kèm việc `makemodel` tự xuất `baseline_metrics_bagheri_<mode>.json` thay vì
phải bới log). Logic mô hình không đổi.

---

## TÓM TẮT MỘT TRANG (cho slide báo cáo)

| # | Thay đổi | Loại | Trước → Sau | Ảnh hưởng số liệu |
|---|---|---|---|---|
| 1 | Bỏ lọc `≤200 ký tự` + cap 4k/40k (Reveal) | B | vocab 1.063 → 43.254 | Baseline trung thực hơn (F1 34,2 → 31,8) |
| 2 | Bật `class_weight` bị comment | B | recall ≈ 0 → hoạt động đúng | Khôi phục thiết kế gốc |
| 3 | `input_shape` 600 → 300 | A | crash → chạy | Bắt buộc để chạy |
| 4 | EagerTensor→numpy + dict lookup | A | crash/rất chậm → chạy | Kết quả giống hệt |
| 5 | int32 + frozen Embedding | C | 30–40GB RAM → <100MB | Tương đương toán học |
| 6 | Cố định split + seed 42 | B | mỗi lần một split → tái lập được | Điều kiện so sánh |
| 7 | Import `tensorflow.keras` | A | ImportError → chạy | Không đổi hành vi |
| 8 | `mode` qua argv (Bagheri) | B nhẹ | sửa tay 7 lần → tự động | Không đổi logic |

**Điểm chốt để trình bày:** không thay đổi nào chạm vào *phương pháp* VDMAF (word2vec +
node2vec + MHA fusion + BiLSTM giữ nguyên); các sửa loại [B] đều làm baseline **mạnh và
trung thực hơn** — nghĩa là mức cải thiện +49% PR-AUC của mô hình đề xuất được đo so với
phiên bản artifact TỐT NHẤT có thể, không phải so với bản lỗi.
