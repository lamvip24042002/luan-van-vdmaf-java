# -*- coding: utf-8 -*-
# Aggregate the Juliet access-control before/after PCFinder experiment (balanced
# synthetic controlled set, 88 test positives). Reports mean±std + paired diffs.
import json
import os
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
SEEDS = [42, 43, 44, 45, 46]
CONFIGS = ["jac_both_off", "jac_both_on", "jac_gnn_off", "jac_gnn_on"]
METRICS = ["pr_auc", "roc_auc", "f1@val_t", "mcc@val_t", "r@val_t"]

res = {c: {m: [] for m in METRICS} for c in CONFIGS}
for c in CONFIGS:
    for s in SEEDS:
        mp = os.path.join(HERE, "runs", "%s_s%d" % (c, s), "metrics.json")
        if not os.path.isfile(mp):
            continue
        with open(mp, encoding="utf-8") as f:
            t = json.load(f)["test"]
        for m in METRICS:
            res[c][m].append(t.get(m, float("nan")))


def ms(v):
    a = np.array(v)
    return "%.3f ± %.3f" % (a.mean(), a.std(ddof=1) if len(a) > 1 else 0.0)


print("| Config | n | " + " | ".join(METRICS) + " |")
print("|---|---|" + "---|" * len(METRICS))
for c in CONFIGS:
    if res[c]["pr_auc"]:
        print("| %s | %d | %s |" % (c, len(res[c]["pr_auc"]),
                                    " | ".join(ms(res[c][m]) for m in METRICS)))

print("\n=== paired per-seed diffs (on - off) ===")
for a, b in [("jac_both_on", "jac_both_off"), ("jac_gnn_on", "jac_gnn_off")]:
    for m in METRICS:
        if len(res[a][m]) == len(res[b][m]) and res[a][m]:
            d = np.array(res[a][m]) - np.array(res[b][m])
            print("%s - %s | %-10s mean %+0.4f | per-seed %s | wins %d/%d"
                  % (a, b, m, d.mean(), np.round(d, 3).tolist(),
                     int((d > 0).sum()), len(d)))

with open(os.path.join(HERE, "jac_experiment_summary.json"), "w", encoding="utf-8") as f:
    json.dump({c: {m: res[c][m] for m in METRICS} for c in CONFIGS}, f, indent=2)
print("\nsaved -> jac_experiment_summary.json")
