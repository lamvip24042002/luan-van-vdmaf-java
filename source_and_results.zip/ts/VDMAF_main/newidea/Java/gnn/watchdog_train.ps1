# RAM guard for v1 training runs; exits on ALL RUNS DONE or after 4 h.
$log = "C:\Users\ADMIN\Desktop\ts\VDMAF_main\newidea\Java\gnn\watchdog_train.log"
$driverlog = "C:\Users\ADMIN\Desktop\ts\VDMAF_main\newidea\Java\gnn\run_v1_all.log"
$deadline = (Get-Date).AddHours(4)
Add-Content $log "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') train watchdog started"
while ((Get-Date) -lt $deadline) {
    $os = Get-CimInstance Win32_OperatingSystem
    $freeGB = [math]::Round($os.FreePhysicalMemory/1MB, 1)
    $pys = Get-Process python* -ErrorAction SilentlyContinue
    $pyGB = 0
    if ($pys) { $pyGB = [math]::Round((($pys | Measure-Object WorkingSet64 -Sum).Sum)/1GB, 1) }
    Add-Content $log "$(Get-Date -Format HH:mm:ss) free=${freeGB}GB python=${pyGB}GB"
    if ($freeGB -lt 3) {
        Add-Content $log "$(Get-Date -Format HH:mm:ss) LIMIT HIT (free=${freeGB}GB) -> killing python"
        if ($pys) { $pys | Stop-Process -Force }
    }
    if (Select-String -Path $driverlog -Pattern "ALL RUNS DONE" -Quiet -ErrorAction SilentlyContinue) {
        Add-Content $log "$(Get-Date -Format HH:mm:ss) training finished -> watchdog exits"
        break
    }
    Start-Sleep -Seconds 30
}
