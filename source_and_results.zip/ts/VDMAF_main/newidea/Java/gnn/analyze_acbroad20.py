# -*- coding: utf-8 -*-
# Aggregate the broadened-AC (OWASP A01/A07) before/after PCFinder experiment:
# mean±std per config + paired sign-test/Wilcoxon on both fusion and gnn pairs.
import json
import os
import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
SEEDS = list(range(42, 62))          # 10 seeds
CONFIGS = ["acb_both_off", "acb_both_on", "acb_gnn_off", "acb_gnn_on"]
METRICS = ["pr_auc", "roc_auc", "f1@val_t", "mcc@val_t", "r@val_t"]

res = {c: {m: [] for m in METRICS} for c in CONFIGS}
for c in CONFIGS:
    for s in SEEDS:
        mp = os.path.join(HERE, "runs", "%s_s%d" % (c, s), "metrics.json")
        if not os.path.isfile(mp):
            continue
        with open(mp, encoding="utf-8") as f:
            t = json.load(f)["test"]
        for m in METRICS:
            res[c][m].append(t.get(m, float("nan")))


def ms(v):
    a = np.array(v)
    return "%.3f ± %.3f" % (a.mean(), a.std(ddof=1) if len(a) > 1 else 0.0)


print("| Config | n | " + " | ".join(METRICS) + " |")
print("|---|---|" + "---|" * len(METRICS))
for c in CONFIGS:
    if res[c]["pr_auc"]:
        print("| %s | %d | %s |" % (c, len(res[c]["pr_auc"]),
                                    " | ".join(ms(res[c][m]) for m in METRICS)))

print("\n=== paired (on - off), sign-test + Wilcoxon ===")
for a, b in [("acb_both_on", "acb_both_off"), ("acb_gnn_on", "acb_gnn_off")]:
    for m in METRICS:
        if len(res[a][m]) == len(res[b][m]) and res[a][m]:
            d = np.array(res[a][m]) - np.array(res[b][m])
            wins, n = int((d > 0).sum()), len(d)
            sp = stats.binomtest(wins, n, 0.5, alternative="greater").pvalue
            try:
                wp = stats.wilcoxon(d, alternative="greater").pvalue
            except ValueError:
                wp = float("nan")
            print("%s-%s | %-10s mean %+0.4f | wins %d/%d | sign p=%.3f | wilcoxon p=%.3f"
                  % (a, b, m, d.mean(), wins, n, sp, wp))

with open(os.path.join(HERE, "acbroad_experiment_summary.json"), "w", encoding="utf-8") as f:
    json.dump({c: {m: res[c][m] for m in METRICS} for c in CONFIGS}, f, indent=2)
print("\nsaved -> acbroad_experiment_summary.json")
