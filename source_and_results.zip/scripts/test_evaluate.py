"""Portable package-integrity checks without requiring PyTorch or a dataset."""
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

import evaluate


class PackageIntegrityTests(unittest.TestCase):
    def create_package(self, root, name="models/model.pt", content=b"checkpoint-bytes"):
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content)
        entry = {"path": name, "size": len(content),
                 "sha256": hashlib.sha256(content).hexdigest()}
        (root / "MANIFEST.json").write_text(json.dumps({"files": [entry]}), encoding="utf-8")
        return entry

    def test_hashes_are_independent_of_the_original_machine_path(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "relocated thesis package"
            self.create_package(root)
            package = evaluate.Package(root)
            self.assertEqual(package.check("models/model.pt"), (root / "models/model.pt").resolve())

    def test_changed_checkpoint_is_rejected_before_loading(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            self.create_package(root)
            package = evaluate.Package(root)
            (root / "models/model.pt").write_bytes(b"changed-checkpoin")
            with self.assertRaisesRegex(ValueError, "integrity failure"):
                package.check("models/model.pt")

    def test_missing_manifest_entry_is_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            self.create_package(root)
            with self.assertRaisesRegex(ValueError, "absent from MANIFEST"):
                evaluate.Package(root).check("models/unlisted.pt")

    def test_manifest_cannot_escape_or_ambiguously_alias_paths(self):
        for name in ("../secret", "/absolute", "C:/absolute", "a\\b", "a/../b", "./model.pt"):
            with self.subTest(name=name), tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary)
                entry = {"path": name, "size": 0, "sha256": hashlib.sha256(b"").hexdigest()}
                (root / "MANIFEST.json").write_text(json.dumps({"files": [entry]}), encoding="utf-8")
                with self.assertRaisesRegex(ValueError, "Invalid package manifest path"):
                    evaluate.Package(root)

    def test_duplicate_entries_are_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            entry = self.create_package(root)
            (root / "MANIFEST.json").write_text(json.dumps({"files": [entry, entry]}), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "Duplicate manifest path"):
                evaluate.Package(root)


if __name__ == "__main__":
    unittest.main()
