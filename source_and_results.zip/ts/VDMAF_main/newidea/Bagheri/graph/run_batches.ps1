param([string]$Mode = "sql")
$graph = "C:\Users\ADMIN\Desktop\ts\VDMAF_main\newidea\Bagheri\graph"
Set-Location $graph
$batches = Get-ChildItem "src_$Mode" -Directory | Sort-Object Name
foreach ($b in $batches) {
  $name = "$($Mode)_$($b.Name)"
  if (Test-Path "graph_$name.txt") { Write-Output "skip $name (done)"; continue }
  Write-Output "=== $name  $(Get-Date -Format HH:mm:ss) ==="
  & C:\tools\joern-cli\pysrc2cpg.bat $b.FullName -o "$name.cpg" | Out-Null
  if (-not (Test-Path "$name.cpg")) { Write-Output "pysrc2cpg FAILED for $name"; continue }
  & C:\tools\joern-cli\joern.bat --script "..\..\Devign\graph\dump_graph.sc" --param """cpgFile=$name.cpg""" --param """outFile=graph_$name.txt""" | Select-Object -Last 2
  Remove-Item -Recurse -Force workspace -ErrorAction SilentlyContinue
  Remove-Item "$name.cpg" -Force -ErrorAction SilentlyContinue
}
Write-Output "ALL BATCHES DONE  $(Get-Date -Format HH:mm:ss)"
