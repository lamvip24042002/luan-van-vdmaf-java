"""Plot the complete, verified seminar experiment; never plot partial results.

Outputs are new seminar figures only. Historical thesis figures are untouched.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import statistics

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import MultipleLocator
import numpy as np


SEEDS = [42, 43, 44, 45, 46]
# A fixed 6-inch canvas scales by 0.984 when inserted at 15 cm in the thesis.
# At that width the minimum 10-point text remains 9.84 points in print.
FIGURE_WIDTH_INCHES = 6.0
PRIMARY_HEIGHT_INCHES = 7.8
PAIRED_HEIGHT_INCHES = 7.4
TARGET_PRINT_WIDTH_CM = 15.0
MINIMUM_FONT_POINTS = 10
ARM_LABELS = {
    "all_full": "Đầy đủ · từ vựng\ncả ba tập",
    "train_full": "Đầy đủ · từ vựng\ntập huấn luyện",
    "train_seq": "Chỉ chuỗi BiLSTM",
    "train_gnn": "Chỉ đồ thị R-GCN",
    "train_concat": "Ghép nối hai kênh\n(concat)",
    "train_cdg_ddg": "Chỉ cạnh CDG + DDG",
    "train_untyped": "Không phân biệt\nloại cạnh",
    "train_no_cdg": "Bỏ cạnh CDG",
    "train_no_ddg": "Bỏ cạnh DDG",
}
COLORS = ["#0072B2", "#D55E00", "#009E73", "#CC79A7", "#E69F00"]
MARKERS = ["o", "s", "^", "v", "P"]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_statistic(statistic, context):
    require(statistic["n"] == 5, f"{context}: expected five seeds")
    require(set(statistic["values_by_seed"]) == {str(seed) for seed in SEEDS},
            f"{context}: wrong seed identities")
    values = [float(statistic["values_by_seed"][str(seed)]) for seed in SEEDS]
    require(all(math.isfinite(value) for value in values), f"{context}: nonfinite value")
    require(math.isclose(statistic["mean"], statistics.mean(values), rel_tol=1e-10, abs_tol=1e-12),
            f"{context}: mean does not match seed values")
    require(math.isclose(statistic["sample_sd"], statistics.stdev(values), rel_tol=1e-10, abs_tol=1e-12),
            f"{context}: SD does not match sample SD (ddof=1)")
    return values


def load_verified_summary(path):
    summary = json.loads(path.read_text(encoding="utf-8"))
    require(summary.get("status") == "complete" and summary.get("exploratory") is False,
            "Only final status=complete, exploratory=false summaries may be plotted")
    require(summary.get("completed_runs") == summary.get("planned_runs") == 45,
            "The complete 45-run protocol is required")
    require(not summary.get("incomplete_runs"), "Summary contains incomplete runs")
    protocol = summary["protocol"]["specification"]
    require(protocol["seeds"] == SEEDS and protocol["planned_runs"] == 45,
            "Unexpected protocol seeds/run count")
    require([arm[0] for arm in protocol["arms"]] == list(ARM_LABELS), "Unexpected protocol arms")
    require(set(summary["primary"]) == set(ARM_LABELS), "Primary arm inventory differs")
    records = summary["runs"]
    require(len(records) == 45 and {(row["arm"], row["seed"]) for row in records}
            == {(arm, seed) for arm in ARM_LABELS for seed in SEEDS}, "Missing/duplicate run identities")
    reference_sample_counts = None
    for arm, label in ARM_LABELS.items():
        group = summary["primary"][arm]
        require(group["seeds"] == SEEDS, f"{arm}: wrong seeds")
        sample_counts = (group["n"], group["positive"])
        if reference_sample_counts is None:
            reference_sample_counts = sample_counts
        require(sample_counts == reference_sample_counts, "Arms use different test samples/class counts")
        values = validate_statistic(group["metrics"]["ap"], arm)
        require(all(0 <= value <= 1 for value in values), f"{arm}: AP outside [0,1]")
        expected_scope = "all" if arm == "all_full" else "train"
        require(group["scope"] == expected_scope, f"{arm}: unexpected vocabulary scope")
    comparisons = [row for row in summary["paired_comparisons"] if row["metric"] == "ap"]
    require(len(comparisons) == 8 and {row["right"] for row in comparisons}
            == set(ARM_LABELS) - {"train_full"}, "Expected all eight AP comparisons")
    pairs = {}
    for row in comparisons:
        require(row["left"] == "train_full" and row["direction"] == "left_minus_right"
                and row["paired_seeds"] == SEEDS, "Unexpected paired-comparison definition")
        values = validate_statistic(row, f"train_full - {row['right']}")
        for seed, value in zip(SEEDS, values):
            expected = (summary["primary"]["train_full"]["metrics"]["ap"]["values_by_seed"][str(seed)]
                        - summary["primary"][row["right"]]["metrics"]["ap"]["values_by_seed"][str(seed)])
            require(math.isclose(value, expected, rel_tol=1e-10, abs_tol=1e-12),
                    f"Incorrect paired difference for seed {seed}")
        pairs[row["right"]] = row
    return summary, pairs


def set_style():
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": MINIMUM_FONT_POINTS,
        "axes.titlesize": 12, "axes.labelsize": MINIMUM_FONT_POINTS,
        "xtick.labelsize": MINIMUM_FONT_POINTS, "ytick.labelsize": MINIMUM_FONT_POINTS,
        "legend.fontsize": 10, "pdf.fonttype": 42, "ps.fonttype": 42,
        "axes.spines.top": False, "axes.spines.right": False,
        "axes.spines.left": False, "axes.grid": False,
        "savefig.facecolor": "white", "figure.facecolor": "white",
    })


def draw_seed_points(axis, values, row):
    offsets = np.linspace(-0.15, 0.15, len(SEEDS))
    for index, value in enumerate(values):
        axis.scatter(value, row + offsets[index], s=24, marker=MARKERS[index],
                     color=COLORS[index], edgecolor="white", linewidth=0.45, zorder=4)


def legend_handles():
    return [Line2D([0], [0], color="#242424", marker="D", markersize=6,
                   linewidth=1.5, label="Trung bình ± SD mẫu")] + [
        Line2D([0], [0], color=COLORS[index], marker=MARKERS[index], markersize=6,
               linestyle="none", label=f"Hạt giống {seed}") for index, seed in enumerate(SEEDS)]


def finish_axes(axis, labels):
    axis.set_yticks(range(len(labels)), labels)
    axis.set_ylim(len(labels) - 0.45, -0.6)
    axis.tick_params(axis="y", length=0, pad=7)
    axis.grid(axis="x", color="#E5E7EB", linewidth=0.7, zorder=0)
    axis.set_axisbelow(True)


def save_figure(figure, output, stem):
    paths = []
    for extension in ("png", "pdf"):
        path = output / f"{stem}.{extension}"
        # Keep the physical canvas width exact; bbox_inches="tight" would change
        # the scale and therefore the font size after thesis insertion.
        figure.savefig(path, dpi=300)
        paths.append(path)
    plt.close(figure)
    return paths


def plot_primary(summary, output):
    figure, axis = plt.subplots(figsize=(FIGURE_WIDTH_INCHES, PRIMARY_HEIGHT_INCHES))
    figure.subplots_adjust(left=0.40, right=0.975, top=0.85, bottom=0.31)
    labels = list(ARM_LABELS.values())
    axis.axhspan(0.65, 1.35, color="#EAF2FA", zorder=0)
    for row, arm in enumerate(ARM_LABELS):
        statistic = summary["primary"][arm]["metrics"]["ap"]
        values = [statistic["values_by_seed"][str(seed)] for seed in SEEDS]
        draw_seed_points(axis, values, row)
        axis.errorbar(statistic["mean"], row, xerr=statistic["sample_sd"], fmt="D",
                      color="#242424", markersize=4.5, elinewidth=1.4, capsize=3, zorder=5)
    finish_axes(axis, labels)
    axis.set_xlim(0, 1)
    axis.xaxis.set_major_locator(MultipleLocator(0.1))
    axis.set_xlabel("Average precision (AP)", labelpad=9)
    figure.suptitle("AP của 9 cấu hình\ntrên cùng tập kiểm thử", x=0.5, y=0.975,
                   fontsize=12, fontweight="bold")
    group = summary["primary"]["train_full"]
    figure.text(0.5, 0.90,
                f"5 hạt giống/cấu hình · {group['n']:,} mẫu · {group['positive']:,} mẫu dương".replace(",", "."),
                ha="center", fontsize=10, color="#4B5563")
    figure.legend(handles=legend_handles(), loc="lower center", ncol=3,
                  bbox_to_anchor=(0.5, 0.15), frameon=False, columnspacing=1.2,
                  handlelength=1.4, handletextpad=0.5)
    figure.text(0.04, 0.10,
                "Từ hàng thứ hai: từ vựng chỉ xây từ tập huấn luyện.\n"
                "Thanh sai số: SD mẫu qua 5 hạt giống (ddof = 1),\n"
                "không phải khoảng tin cậy cho tổng quát hóa.",
                fontsize=10, va="top", linespacing=1.3)
    return save_figure(figure, output, "seminar_ap_9_cau_hinh")


def plot_paired(summary, pairs, output):
    figure, axis = plt.subplots(figsize=(FIGURE_WIDTH_INCHES, PAIRED_HEIGHT_INCHES))
    figure.subplots_adjust(left=0.40, right=0.975, top=0.83, bottom=0.34)
    other_arms = [arm for arm in ARM_LABELS if arm != "train_full"]
    labels = [ARM_LABELS[arm] for arm in other_arms]
    bound = 0.0
    for row, arm in enumerate(other_arms):
        statistic = pairs[arm]
        values = [100 * statistic["values_by_seed"][str(seed)] for seed in SEEDS]
        mean, sd = 100 * statistic["mean"], 100 * statistic["sample_sd"]
        draw_seed_points(axis, values, row)
        axis.errorbar(mean, row, xerr=sd, fmt="D", color="#242424", markersize=4.5,
                      elinewidth=1.4, capsize=3, zorder=5)
        bound = max(bound, abs(mean) + sd, *(abs(value) for value in values))
    finish_axes(axis, labels)
    span = max(0.5, 1.13 * bound)
    axis.set_xlim(-span, span)
    axis.axvline(0, color="#4B5563", linestyle="--", linewidth=1.2, zorder=2)
    axis.set_xlabel("Chênh lệch AP × 100\n(điểm phần trăm)", labelpad=9)
    figure.suptitle("Chênh lệch AP theo cặp hạt giống\nvới 8 đối chứng", x=0.5, y=0.975,
                   fontsize=12, fontweight="bold")
    figure.text(0.5, 0.91,
                "Mô hình đầy đủ với từ vựng TRAIN\ntrừ cấu hình ghi ở mỗi hàng",
                ha="center", va="top", fontsize=10, color="#4B5563", linespacing=1.3)
    figure.legend(handles=legend_handles(), loc="lower center", ncol=3,
                  bbox_to_anchor=(0.5, 0.165), frameon=False, columnspacing=1.2,
                  handlelength=1.4, handletextpad=0.5)
    figure.text(0.04, 0.12,
                "Dương: mô hình đầy đủ (TRAIN) có AP cao hơn.\n"
                "Mỗi điểm so hai cấu hình trên cùng hạt giống.\n"
                "Thanh sai số: SD mẫu của 5 chênh lệch;\n"
                "biến thiên tối ưu hóa trên phép chia cố định.",
                fontsize=10, va="top", linespacing=1.3)
    return save_figure(figure, output, "seminar_chenh_lech_ap_theo_seed")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    root = Path(__file__).resolve().parents[1]
    parser.add_argument("--summary", type=Path,
                        default=root / "output" / "seminar_20261011" / "analysis" / "summary.json")
    parser.add_argument("--out", type=Path, help="Default: sibling figures directory of summary.json")
    args = parser.parse_args()
    summary_path = args.summary.resolve()
    summary, pairs = load_verified_summary(summary_path)
    output = args.out.resolve() if args.out else summary_path.parent / "figures"
    output.mkdir(parents=True, exist_ok=True)
    set_style()
    files = plot_primary(summary, output) + plot_paired(summary, pairs, output)
    metadata = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "summary": str(summary_path), "summary_sha256": sha256(summary_path),
        "script_sha256": sha256(Path(__file__).resolve()), "completed_runs": 45,
        "seeds": SEEDS, "error_bars": "sample standard deviation across 5 optimization seeds; ddof=1",
        "primary_axis": "AP in [0,1]", "paired_axis": "100 * (train_full AP minus comparator AP), percentage points",
        "font": "DejaVu Sans", "minimum_font_points": MINIMUM_FONT_POINTS,
        "figure_width_inches": FIGURE_WIDTH_INCHES,
        "primary_height_inches": PRIMARY_HEIGHT_INCHES,
        "paired_height_inches": PAIRED_HEIGHT_INCHES,
        "target_print_width_cm": TARGET_PRINT_WIDTH_CM,
        "minimum_print_font_points_at_target_width": (
            MINIMUM_FONT_POINTS * TARGET_PRINT_WIDTH_CM / (2.54 * FIGURE_WIDTH_INCHES)),
        "fixed_canvas_without_tight_bbox": True,
        "outputs": {path.name: {"path": str(path), "sha256": sha256(path)} for path in files},
    }
    (output / "figure_manifest.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for path in files:
        print(path)


if __name__ == "__main__":
    main()
