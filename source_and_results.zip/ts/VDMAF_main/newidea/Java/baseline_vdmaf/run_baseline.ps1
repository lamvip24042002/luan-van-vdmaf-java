$conda = "C:\Users\ADMIN\miniconda3\condabin\conda.bat"
$b = "C:\Users\ADMIN\Desktop\ts\VDMAF_main\newidea\Java\baseline_vdmaf"
Set-Location $b
Write-Output "=== STEP export_texts (vdmaf-gnn)  $(Get-Date -Format HH:mm:ss) ==="
& $conda run -n vdmaf-gnn python -u export_texts.py
Write-Output "=== STEP train_w2v (vdmaf)  $(Get-Date -Format HH:mm:ss) ==="
& $conda run -n vdmaf python -u train_w2v.py
Write-Output "=== STEP node2vec (vdmaf)  $(Get-Date -Format HH:mm:ss) ==="
& $conda run -n vdmaf python -u "..\..\Devign\graph\build_node2vec.py" "..\graph\dumps\graph_batch_*.txt" "node2vec_model-300.model"
Write-Output "=== STEP makemodel (vdmaf)  $(Get-Date -Format HH:mm:ss) ==="
& $conda run -n vdmaf python -u makemodel_megavul.py
Write-Output "=== BASELINE ALL DONE  $(Get-Date -Format HH:mm:ss) ==="
