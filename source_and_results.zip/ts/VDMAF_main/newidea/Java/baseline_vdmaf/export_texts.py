# -*- coding: utf-8 -*-
# Export MegaVul-Java parquet -> texts.json {fid: [split, label, code]} and a
# concatenated `corpus` file (artifact style: all splits concatenated, exactly
# like Devign's get_corpus.py). Run in env vdmaf-gnn (pandas).
import json
import os
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
MEGA = os.path.abspath(os.path.join(HERE, "..", "megavul"))

splits = {
    "train": "train-00000-of-00001.parquet",
    "validation": "validation-00000-of-00001.parquet",
    "test": "test-00000-of-00001.parquet",
}
frames = []
for name, fn in splits.items():
    df = pd.read_parquet(os.path.join(MEGA, fn))
    df["split"] = name
    frames.append(df)
df = pd.concat(frames, ignore_index=True)

texts = {}
code_all = []
for gid, row in df.iterrows():
    fid = "F%06d" % gid
    texts[fid] = [row["split"], int(row["is_vulnerable"]), row["input"]]
    code_all.append(row["input"])

with open(os.path.join(HERE, "texts.json"), "w", encoding="utf-8") as f:
    json.dump(texts, f)
with open(os.path.join(HERE, "corpus"), "w", encoding="utf-8") as f:
    f.write("".join(code_all))
print("exported", len(texts), "functions; corpus chars:", sum(len(c) for c in code_all))
