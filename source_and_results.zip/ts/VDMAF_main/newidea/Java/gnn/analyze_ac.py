# -*- coding: utf-8 -*-
# Aggregate the access-control-task before/after PCFinder experiment.
# Task: pos = AC-CWE vuln, neg = safe. Random-baseline PR-AUC = test_pos/test_n.
import json
import os
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
SEEDS = list(range(42, 57))   # 42-46 original + 47-56 extension (gnn pair only)
CONFIGS = ["ac_both_off", "ac_both_on", "ac_gnn_off", "ac_gnn_on"]
METRICS = ["pr_auc", "roc_auc", "f1@val_t", "mcc@val_t", "r@val_t"]

res = {c: {m: [] for m in METRICS} for c in CONFIGS}
for c in CONFIGS:
    for s in SEEDS:
        mp = os.path.join(HERE, "runs", "%s_s%d" % (c, s), "metrics.json")
        if not os.path.isfile(mp):
            continue
        with open(mp, encoding="utf-8") as f:
            t = json.load(f)["test"]
        for m in METRICS:
            res[c][m].append(t.get(m, float("nan")))


def ms(v):
    a = np.array(v)
    return "%.3f ± %.3f" % (a.mean(), a.std(ddof=1) if len(a) > 1 else 0.0)


print("Random-baseline PR-AUC on AC test = 48 / 5972 = %.4f\n" % (48 / 5972))
print("| Config | n | " + " | ".join(METRICS) + " |")
print("|---|---|" + "---|" * len(METRICS))
for c in CONFIGS:
    if res[c]["pr_auc"]:
        print("| %s | %d | %s |" % (c, len(res[c]["pr_auc"]),
                                    " | ".join(ms(res[c][m]) for m in METRICS)))

print("\n=== paired per-seed diffs (on - off) + significance ===")
from scipy import stats
for a, b in [("ac_both_on", "ac_both_off"), ("ac_gnn_on", "ac_gnn_off")]:
    for m in METRICS:
        if len(res[a][m]) == len(res[b][m]) and res[a][m]:
            d = np.array(res[a][m]) - np.array(res[b][m])
            wins, n = int((d > 0).sum()), len(d)
            sign_p = stats.binomtest(wins, n, 0.5, alternative="greater").pvalue
            try:
                wil_p = stats.wilcoxon(d, alternative="greater").pvalue
            except ValueError:
                wil_p = float("nan")
            print("%s - %s | %-10s mean %+0.4f | wins %d/%d | sign-test p=%.4f | wilcoxon p=%.4f"
                  % (a, b, m, d.mean(), wins, n, sign_p, wil_p))
            if n > 8:
                print("    per-seed:", np.round(d, 3).tolist())

out = {c: {m: res[c][m] for m in METRICS} for c in CONFIGS}
with open(os.path.join(HERE, "ac_experiment_summary.json"), "w", encoding="utf-8") as f:
    json.dump(out, f, indent=2)
print("\nsaved -> ac_experiment_summary.json")
