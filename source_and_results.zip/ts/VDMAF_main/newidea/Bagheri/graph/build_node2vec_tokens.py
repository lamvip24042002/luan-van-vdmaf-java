# -*- coding: utf-8 -*-
# Bagheri/VUDENC node2vec builder — token co-occurrence graph fallback.
#
# WHY: the VUDENC plain_<mode> "source" strings are whitespace-flattened
# (newlines/indentation stripped), so they are NOT parseable Python; Joern
# pysrc2cpg yields only empty <module> stubs (657/657 files fail ast.parse).
# A real CPG therefore cannot be built from the released dataset. The
# node2vec_model-300.model the VDMAF authors shipped for Reveal is keyed by
# CODE TOKENS, so we mirror that effective mechanism: per-source graph whose
# nodes are unique tokens and edges connect consecutive tokens, uniform
# random walks, then skip-gram — same hyperparams as the shipped artifact
# (sg=1, window=10, min_count=5, dim=300, epochs=5).
#
# Usage: python build_node2vec_tokens.py [mode]   (default: sql)
import json
import os
import random
import sys
from datetime import datetime

sys.path.insert(0, os.path.abspath("../train_model"))
import myutils  # same tokenizer as makemodel.py

from gensim.models import Word2Vec

mode = sys.argv[1] if len(sys.argv) > 1 else "sql"
WALKS_PER_NODE = 2
WALK_LEN = 20
random.seed(42)

print("=== %s token-graph node2vec  %s ===" % (mode, datetime.now().strftime("%H:%M:%S")))

with open('../dataset/plain_' + mode, 'r') as infile:
    data = json.load(infile)

walks_path = "walks_%s.txt" % mode
n_sources = 0
n_tokens_total = 0

with open(walks_path, "w", encoding="utf-8") as out:
    for r in data:
        for c in data[r]:
            if "files" not in data[r][c]:
                continue
            for f in data[r][c]["files"]:
                src = data[r][c]["files"][f].get("source")
                if not src:
                    continue
                tokens = [t for t in myutils.getTokens(src) if t.strip() != ""]
                if len(tokens) < 2:
                    continue
                # collapse to unique-token graph, edges = consecutive tokens
                adj = {}
                for a, b in zip(tokens, tokens[1:]):
                    adj.setdefault(a, set()).add(b)
                    adj.setdefault(b, set()).add(a)
                nodes = list(adj.keys())
                n_sources += 1
                n_tokens_total += len(nodes)
                for node in nodes:
                    for _ in range(WALKS_PER_NODE):
                        walk = [node]
                        cur = node
                        for _ in range(WALK_LEN - 1):
                            nxt = random.choice(list(adj[cur]))
                            walk.append(nxt)
                            cur = nxt
                        out.write(" ".join(walk) + "\n")

print("sources: %d | avg unique tokens/source: %.1f"
      % (n_sources, n_tokens_total / max(n_sources, 1)))
print("training skip-gram on walks...")

model = Word2Vec(corpus_file=walks_path, sg=1, window=10, min_count=5,
                 vector_size=300, epochs=5, workers=4, seed=42)
print("vocab:", len(model.wv.key_to_index))

outdir = "../model/" + mode
os.makedirs(outdir, exist_ok=True)
outpath = outdir + "/node2vec_model-300.model"
model.save(outpath)
print("saved ->", outpath)
print("=== DONE  %s ===" % datetime.now().strftime("%H:%M:%S"))
