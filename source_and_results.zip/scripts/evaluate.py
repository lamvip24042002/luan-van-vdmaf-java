"""Re-evaluate archived thesis checkpoints after cloning to any local directory.

The original trainer and historical metadata remain unchanged. This entry point
resolves package-relative paths, checks file hashes, loads state dictionaries
with weights_only=True, and uses the validation-selected threshold already saved
with each checkpoint. It never trains or selects a threshold on the test set.
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
from pathlib import Path, PurePosixPath
import re
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
EXPERIMENT = "output/seminar_20261011"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


class Package:
    """Validate the exact local bytes consumed, not historical machine paths."""

    def __init__(self, root):
        self.root = root.resolve()
        document = read_json(self.root / "MANIFEST.json")
        entries = document if isinstance(document, list) else document["files"]
        self.files = {}
        for entry in entries:
            name = entry["path"]
            path = PurePosixPath(name)
            require(isinstance(name, str) and "\\" not in name and ":" not in name
                    and not path.is_absolute() and ".." not in path.parts
                    and str(path) == name and name not in ("", "."),
                    f"Invalid package manifest path: {name!r}")
            require(name not in self.files, f"Duplicate manifest path: {name}")
            require(type(entry["size"]) is int and entry["size"] >= 0
                    and re.fullmatch(r"[0-9a-f]{64}", entry["sha256"]),
                    f"Invalid manifest metadata: {name}")
            self.files[name] = entry
        self.verified = {}

    def check(self, relative):
        relative = str(relative)
        require(relative in self.files, f"File absent from MANIFEST.json: {relative}")
        path = (self.root / relative).resolve()
        require(path.is_relative_to(self.root) and path.is_file(),
                f"Missing or escaped package file: {relative}")
        expected = self.files[relative]
        actual = sha256(path)
        require(path.stat().st_size == expected["size"] and actual == expected["sha256"],
                f"Package integrity failure: {relative}")
        self.verified[relative] = actual
        return path

    def json(self, relative):
        return read_json(self.check(relative))


def load_trainer(package):
    path = package.check("scripts/train_seminar_20261011.py")
    specification = importlib.util.spec_from_file_location("thesis_archived_trainer", path)
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module


def evaluate_run(package, trainer, protocol, arm, seed, args, device):
    np, torch = trainer.np, trainer.torch
    arm_name, scope, channels, fusion, edges = arm
    name = f"{arm_name}_s{seed}"
    run = f"{EXPERIMENT}/runs/{name}"
    data = f"{EXPERIMENT}/inputs/{scope}"
    spec = package.json(f"{run}/run_spec.json")
    saved = package.json(f"{run}/metrics.json")
    checkpoint = package.json(f"{run}/best_checkpoint.json")
    require(spec.get("status") == "completed", f"{name}: archived run is incomplete")
    config = spec["config"]
    expected_config = {"channels": channels, "fusion": fusion, "edges": edges,
                       "seed": seed, "pcf": False}
    expected_config.update({key: value for key, value in protocol["hyperparameters"].items()
                            if key != "weight_decay"})
    require(all(config.get(key) == value for key, value in expected_config.items()),
            f"{name}: configuration differs from protocol")
    require(saved["config"] == config and saved["splits"] == spec["splits"],
            f"{name}: saved metrics and run specification disagree")
    require(spec["script_sha256"] == protocol["trainer_sha256"]
            == package.verified["scripts/train_seminar_20261011.py"],
            f"{name}: trainer differs from the archived experiment")
    manifest_path = package.check(f"{data}/manifest.json")
    manifest_hash = package.verified[f"{data}/manifest.json"]
    require(manifest_hash == protocol["input_manifests"][scope]
            == spec["data_manifests"]["manifest.json"]["sha256"],
            f"{name}: original dataset manifest hash mismatch")
    manifest = read_json(manifest_path)
    require(manifest["vocab_scope"] == scope and all(manifest["invariants"].values()),
            f"{name}: invalid input scope or invariants")
    for filename in ("test.pt", "seq_test.pt", "vocab_joint.json"):
        path = package.check(f"{data}/{filename}")
        actual = package.verified[f"{data}/{filename}"]
        require(actual == spec["input_sha256"][filename]
                == manifest["artifacts"][filename]["sha256"],
                f"{name}: archived input hash mismatch for {filename}")
    vocabulary = read_json(package.root / data / "vocab_joint.json")
    trainer.validate_vocabulary(vocabulary)
    require(checkpoint["vocab_sha256"] == saved["vocab_sha256"]
            == package.verified[f"{data}/vocab_joint.json"],
            f"{name}: checkpoint vocabulary mismatch")
    require(checkpoint["epoch"] == spec["best_epoch"] == saved["best_epoch"],
            f"{name}: selected epoch mismatch")
    threshold = checkpoint["val_t"]
    require(isinstance(threshold, (float, int)) and math.isfinite(threshold)
            and 0 <= threshold <= 1 and threshold == saved["test"]["val_t"]
            == saved["val"]["val_t"], f"{name}: saved validation threshold mismatch")

    # Check serialized inputs and model before torch deserialization.
    model_path = package.check(f"{run}/model.pt")
    reference_path = package.check(f"{run}/test_predictions.csv")
    items, _, inventory = trainer.load_split(package.root / data, "test", len(vocabulary))
    require(inventory == spec["splits"]["test"], f"{name}: test IDs/labels changed")
    model = trainer.FusionModel(len(vocabulary), config["dim"], channels,
                                trainer.relation_count(edges), config["dropout"], fusion)
    require(sum(parameter.numel() for parameter in model.parameters()) == saved["parameter_count"],
            f"{name}: model parameter count mismatch")
    model.load_state_dict(torch.load(model_path, map_location="cpu", weights_only=True), strict=True)
    model.to(device)
    start = time.perf_counter()
    labels, probability = trainer.predict(model, items, args.batch or config["batch"], device, edges)
    elapsed = time.perf_counter() - start
    metrics = trainer.metrics_at_thresholds(labels, probability, threshold)
    with reference_path.open(encoding="utf-8-sig", newline="") as handle:
        reference = list(csv.DictReader(handle))
    require(len(reference) == len(items), f"{name}: reference prediction count mismatch")
    require(all(row["fid"] == item["fid"] and int(row["y"]) == int(label)
                and float(row["val_t"]) == threshold
                for row, (item, _), label in zip(reference, items, labels)),
            f"{name}: reference IDs, labels, or thresholds differ")
    expected_prob = np.array([float(row["prob"]) for row in reference], dtype=np.float64)
    require(np.isfinite(expected_prob).all() and ((0 <= expected_prob) & (expected_prob <= 1)).all(),
            f"{name}: invalid archived probabilities")
    # float32 reflects the original trainer's NumPy comparison behavior.
    replay = trainer.metrics_at_thresholds(labels, expected_prob.astype(np.float32), threshold)
    require(all(abs(float(replay[key]) - float(value)) <= 1e-12
                for key, value in saved["test"].items()),
            f"{name}: archived CSV probabilities do not reproduce saved metrics")
    deltas = {key: abs(float(value) - float(saved["test"][key])) for key, value in metrics.items()}
    metric_match = all(value <= args.metric_atol for value in deltas.values())
    probability_match = bool(np.allclose(probability, expected_prob,
                                         atol=args.probability_atol, rtol=args.probability_rtol))
    result = {
        "run": name, "status": "pass" if metric_match and probability_match else "different",
        "device": device, "batch": args.batch or config["batch"], "inference_seconds": elapsed,
        "test": metrics, "archived_test": saved["test"], "absolute_metric_differences": deltas,
        "metrics_within_tolerance": metric_match, "probabilities_within_tolerance": probability_match,
        "max_absolute_probability_difference": float(np.max(np.abs(probability - expected_prob))),
        "threshold_source": "archived validation-selected best_checkpoint.json; no test tuning",
        "checkpoint_sha256": package.verified[f"{run}/model.pt"],
        "test_inventory": inventory,
    }
    destination = args.out / name
    destination.mkdir()
    trainer.write_predictions(destination / "test_predictions.csv", items, labels, probability, threshold)
    trainer.atomic_json(destination / "metrics.json", result)
    print(f"{name}: {result['status']} | n={metrics['n']} AP={metrics['ap']:.9f} "
          f"F1={metrics['f1@val_t']:.9f} | max probability delta="
          f"{result['max_absolute_probability_difference']:.3g}", flush=True)
    return result


def parser():
    cli = argparse.ArgumentParser(description=__doc__)
    selection = cli.add_mutually_exclusive_group()
    selection.add_argument("--run", nargs="+", default=["train_full_s42"], help="Archived run name(s)")
    selection.add_argument("--all", action="store_true", help="Evaluate every run in the archived protocol")
    cli.add_argument("--out", type=Path, required=True, help="New or empty evaluation output directory")
    cli.add_argument("--device", choices=("cpu", "cuda", "auto"), default="cpu")
    cli.add_argument("--batch", type=int, help="Default: archived batch size (64)")
    cli.add_argument("--threads", type=int, default=4)
    cli.add_argument("--metric-atol", type=float, default=1e-4)
    cli.add_argument("--probability-atol", type=float, default=1e-5)
    cli.add_argument("--probability-rtol", type=float, default=1e-4)
    return cli


def main(argv=None):
    cli = parser()
    args = cli.parse_args(argv)
    if args.threads < 1 or (args.batch is not None and args.batch < 1):
        cli.error("--threads and --batch must be positive")
    if any(not math.isfinite(value) or value < 0 for value in
           (args.metric_atol, args.probability_atol, args.probability_rtol)):
        cli.error("comparison tolerances must be finite and nonnegative")
    args.out = args.out.resolve()
    if args.out == ROOT or args.out in ROOT.parents or args.out.is_relative_to(ROOT / "output"):
        cli.error("--out must not overwrite the package or archived output tree; use evaluation/<name>")
    if args.out.exists() and (not args.out.is_dir() or any(args.out.iterdir())):
        cli.error("--out must be new or empty; existing results are never overwritten")
    package = Package(ROOT)
    protocol = package.json(f"{EXPERIMENT}/protocol.json")["specification"]
    available = {f"{arm[0]}_s{seed}": (arm, seed)
                 for seed in protocol["seeds"] for arm in protocol["arms"]}
    names = list(available) if args.all else args.run
    require(len(names) == len(set(names)) and all(name in available for name in names),
            "Run names must be unique and present in the archived protocol")
    trainer = load_trainer(package)
    torch = trainer.torch
    torch.set_num_threads(args.threads)
    device = ("cuda" if torch.cuda.is_available() else "cpu") if args.device == "auto" else args.device
    require(device != "cuda" or torch.cuda.is_available(), "CUDA requested but unavailable; use --device cpu")
    args.out.mkdir(parents=True, exist_ok=True)
    results = []
    for name in names:
        arm, seed = available[name]
        results.append(evaluate_run(package, trainer, protocol, arm, seed, args, device))
    passed = all(result["status"] == "pass" for result in results)
    summary = {
        "status": "pass" if passed else "different",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "evaluation_script_sha256": sha256(Path(__file__).resolve()),
        "environment": {"python": sys.version, "torch": str(torch.__version__),
                        "torch_geometric": trainer.torch_geometric.__version__,
                        "numpy": trainer.np.__version__, "sklearn": trainer.sklearn.__version__,
                        "device": device, "torch_threads": torch.get_num_threads()},
        "tolerances": {"metric_atol": args.metric_atol, "probability_atol": args.probability_atol,
                       "probability_rtol": args.probability_rtol},
        "verified_inputs": package.verified, "runs": results,
        "note": "CPU/CUDA operations may differ numerically. Actual deltas are reported; archived results are unchanged.",
    }
    trainer.atomic_json(args.out / "summary.json", summary)
    print(f"Evaluation {summary['status']}: {len(results)} run(s); {args.out / 'summary.json'}", flush=True)
    return 0 if passed else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError, RuntimeError) as error:
        print(f"Evaluation failed: {error}", file=sys.stderr)
        raise SystemExit(2)
