$conda = "C:\Users\ADMIN\miniconda3\condabin\conda.bat"
$base = "C:\Users\ADMIN\Desktop\ts\VDMAF_main\newidea\Bagheri"
$modes = @("xss", "xsrf", "command_injection", "open_redirect", "path_disclosure", "remote_code_execution")
foreach ($m in $modes) {
    Write-Output "=== MODE $m  $(Get-Date -Format HH:mm:ss) ==="
    Set-Location "$base\w2v_embedding"
    & $conda run -n vdmaf python -u get_corpus.py $m
    & $conda run -n vdmaf python -u train_w2v_needed.py $m
    Set-Location "$base\graph"
    & $conda run -n vdmaf python -u build_node2vec_tokens.py $m
    Set-Location "$base\train_model"
    & $conda run -n vdmaf python -u makemodel.py $m
    Write-Output "=== MODE $m DONE  $(Get-Date -Format HH:mm:ss) ==="
}
Write-Output "=== ALL MODES DONE  $(Get-Date -Format HH:mm:ss) ==="
