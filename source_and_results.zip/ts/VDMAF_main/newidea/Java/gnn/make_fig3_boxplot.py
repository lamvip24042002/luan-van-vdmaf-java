# -*- coding: utf-8 -*-
# Figure 3 for the thesis: boxplot of PR-AUC (GNN-only, +-PCFinder flags) on the
# MegaVul access-control task, across 15 seeds. Colors the first 5 seeds
# (42-46, the ones that showed a 4/5-win trend) differently from the 10
# extension seeds (47-56) to visually show the trend evaporating once more
# seeds are added -- illustrates why the significance test (sign-test p=0.30)
# overturned the small-sample impression.
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.abspath(os.path.join(HERE, "..", "figures"))
os.makedirs(OUT, exist_ok=True)

with open(os.path.join(HERE, "ac_experiment_summary.json"), encoding="utf-8") as f:
    data = json.load(f)

off = np.array(data["ac_gnn_off"]["pr_auc"])
on = np.array(data["ac_gnn_on"]["pr_auc"])
n = len(off)

fig, ax = plt.subplots(figsize=(6.5, 5))
bp = ax.boxplot([off, on], tick_labels=["GNN, KHÔNG cờ\nPCFinder", "GNN, CÓ cờ\nPCFinder"],
                widths=0.45, showmeans=True, meanline=True,
                boxprops=dict(color="#444444", linewidth=1.3),
                medianprops=dict(color="#444444", linewidth=1.3),
                meanprops=dict(color="#c0392b", linewidth=1.5, linestyle="--"),
                whiskerprops=dict(color="#444444"), capprops=dict(color="#444444"))

rng = np.random.default_rng(0)
for i, vals in enumerate([off, on], start=1):
    x = i + rng.uniform(-0.09, 0.09, size=n)
    first5 = slice(0, 5)
    rest = slice(5, n)
    ax.scatter(x[first5], vals[first5], color="#2980b9", s=55, zorder=3,
               label="5 seed đầu (42–46)" if i == 1 else None,
               edgecolor="white", linewidth=0.6)
    ax.scatter(x[rest], vals[rest], color="#95a5a6", s=40, zorder=3,
               label="10 seed mở rộng (47–56)" if i == 1 else None,
               edgecolor="white", linewidth=0.6)

ax.set_ylabel("PR-AUC (tập test access-control, 48 mẫu dương)")
ax.set_title("PR-AUC theo 15 seed: đặc trưng PCFinder trên kênh GNN thuần\n"
              "(sign-test p = 0.30 — chênh lệch không có ý nghĩa thống kê)",
              fontsize=10.5)
ax.legend(loc="upper right", fontsize=8.5, framealpha=0.9)
ax.grid(axis="y", linestyle=":", alpha=0.5)
fig.tight_layout()

for ext in ("png", "svg"):
    path = os.path.join(OUT, "fig3_boxplot_pcfinder_ac_15seed.%s" % ext)
    fig.savefig(path, dpi=200)
    print("saved ->", path)
