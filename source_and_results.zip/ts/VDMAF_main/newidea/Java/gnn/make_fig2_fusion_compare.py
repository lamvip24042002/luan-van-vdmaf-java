# -*- coding: utf-8 -*-
# Figure 2: so sanh fusion TINH (VDMAF-artifact) vs fusion HOC DUOC (de xuat).
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.abspath(os.path.join(HERE, "..", "figures"))
os.makedirs(OUT, exist_ok=True)

fig, ax = plt.subplots(figsize=(11, 7.0))
ax.set_xlim(-0.5, 21.5)
ax.set_ylim(0.3, 10.8)
ax.axis("off")


def box(center, w, h, text, fc, ec, lw=1.4, fs=10, fw="normal"):
    x, y = center
    b = FancyBboxPatch((x - w / 2, y - h / 2), w, h,
                        boxstyle="round,pad=0.06,rounding_size=0.12",
                        facecolor=fc, edgecolor=ec, linewidth=lw, zorder=2)
    ax.add_patch(b)
    ax.text(x, y, text, ha="center", va="center", fontsize=fs, fontweight=fw,
            zorder=3, linespacing=1.35)
    return (x, y, w, h)


def varrow(src, dst, color="#333333", lw=1.3, ls="solid"):
    (x1, y1, w1, h1) = src
    (x2, y2, w2, h2) = dst
    p1 = (x1, y1 - h1 / 2) if y1 > y2 else (x1, y1 + h1 / 2)
    p2 = (x2, y2 + h2 / 2) if y1 > y2 else (x2, y2 - h2 / 2)
    a = FancyArrowPatch(p1, p2, arrowstyle="-|>", color=color, lw=lw,
                        linestyle=ls, mutation_scale=14, zorder=1)
    ax.add_patch(a)


RED_F, RED_E = "#fdecea", "#c0392b"
GRAY_F, GRAY_E = "#f4f6f7", "#7f8c8d"
BLUE_F, BLUE_E = "#eaf2fb", "#2980b9"
GREEN_F, GREEN_E = "#eafaf1", "#27ae60"
ORANGE_F, ORANGE_E = "#fdf2e9", "#e67e22"

# ---- LEFT PANEL: VDMAF-artifact (static fusion) ----
ax.text(5, 10.3, "VDMAF-artifact: FUSION TĨNH", ha="center", fontsize=12.5,
        fontweight="bold", color=RED_E)

a1 = box((2.3, 9.0), 4.0, 0.85, "word2vec[token]\n(bảng tra tĩnh)", GRAY_F, GRAY_E, fs=9.5)
a2 = box((7.2, 9.0), 4.0, 0.85, "node2vec[token]\n(bảng tra tĩnh)", GRAY_F, GRAY_E, fs=9.5)
a3 = box((4.75, 7.5), 8.6, 1.0, "MultiHeadAttention\n(trọng số KHỞI TẠO NGẪU NHIÊN)",
          RED_F, RED_E, lw=1.8, fw="bold")
a4 = box((4.75, 6.0), 8.6, 0.85, "reduce_sum → vector cố định\n(bảng tra 1 lần, dùng cho mọi mẫu)", GRAY_F, GRAY_E, fs=9.5)
a5 = box((4.75, 4.5), 8.6, 0.85, "BiLSTM 4 lớp → Dense → Sigmoid", GRAY_F, GRAY_E)

varrow(a1, a3); varrow(a2, a3); varrow(a3, a4); varrow(a4, a5)

# "no gradient" marker between a3 and a4
ax.annotate("", xy=(4.75, 6.55), xytext=(4.75, 7.0),
            arrowprops=dict(arrowstyle="-", color=RED_E, lw=2.4, linestyle=(0, (2, 2))))
ax.text(9.3, 6.78, "✗ không lan truyền\ngradient ngược", ha="left", va="center",
        fontsize=8.8, color=RED_E, fontweight="bold")

ax.text(4.75, 3.15,
        "→ Toàn bộ tham số fusion ĐÓNG BĂNG trong suốt huấn luyện,\n"
        "  giống nhau cho mọi mẫu bất kể ngữ cảnh của hàm",
        ha="center", va="center", fontsize=9.3, color=RED_E, style="italic",
        linespacing=1.4)

# ---- divider ----
ax.plot([10.5, 10.5], [0.6, 10.2], linestyle=(0, (4, 3)), color="#999999", lw=1.3)

# ---- RIGHT PANEL: proposed (learned fusion) ----
ax.text(16, 10.3, "Đề xuất: FUSION HỌC ĐƯỢC", ha="center", fontsize=12.5,
        fontweight="bold", color=ORANGE_E)

b1 = box((13.3, 9.0), 4.0, 0.85, "Trạng thái token\n(BiLSTM)", BLUE_F, BLUE_E, fs=9.5)
b2 = box((18.2, 9.0), 4.0, 0.85, "Trạng thái node\n(R-GCN)", GREEN_F, GREEN_E, fs=9.5)
b3 = box((15.75, 7.5), 8.6, 1.0, "Cross-Attention\nQuery = token,  Key/Value = node",
          ORANGE_F, ORANGE_E, lw=2.0, fw="bold")
b4 = box((15.75, 6.0), 8.6, 0.85, "Vector fusion (tính riêng cho từng mẫu)", GRAY_F, GRAY_E, fs=9.5)
b5 = box((15.75, 4.5), 8.6, 0.85, "MLP → Sigmoid", GRAY_F, GRAY_E)

varrow(b1, b3); varrow(b2, b3); varrow(b3, b4); varrow(b4, b5)

# gradient flows back — curved dashed arrow from b5 up to b3
grad = FancyArrowPatch((12.2, 4.7), (12.2, 7.3),
                       connectionstyle="arc3,rad=-0.35",
                       arrowstyle="-|>", color=ORANGE_E, lw=1.8,
                       linestyle=(0, (3, 2)), mutation_scale=14, zorder=1)
ax.add_patch(grad)
ax.text(10.9, 6.0, r"$\nabla$ backprop", ha="center", va="center",
        fontsize=9.3, color=ORANGE_E, fontweight="bold", rotation=90)

ax.text(15.75, 3.15,
        "→ Toàn bộ tham số fusion được CẬP NHẬT qua huấn luyện,\n"
        "  khác nhau theo ngữ cảnh CDG/DDG của từng hàm",
        ha="center", va="center", fontsize=9.3, color=ORANGE_E, style="italic",
        linespacing=1.4)

ax.text(10.5, 1.35,
        "Khác biệt cốt lõi: (trái) trọng số attention ngẫu nhiên và cố định —\n"
        "(phải) trọng số attention được huấn luyện end-to-end cùng bộ phân loại",
        ha="center", va="center", fontsize=10.5, fontweight="bold", linespacing=1.5)

ax.set_title("So sánh cơ chế fusion: VDMAF-artifact (tĩnh) và mô hình đề xuất (học được)",
              fontsize=13.5, fontweight="bold", pad=16)
fig.tight_layout()
for ext in ("png", "svg"):
    path = os.path.join(OUT, "fig2_fusion_tinh_vs_hoc_duoc.%s" % ext)
    fig.savefig(path, dpi=200)
    print("saved ->", path)
