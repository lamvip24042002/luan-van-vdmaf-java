# Multi-seed runs (seeds 43-46; seed 42 already exists) for the VDMAF-artifact
# baseline and all 4 v1 configs. Resumable: skips runs whose metrics exist.
$conda = "C:\Users\ADMIN\miniconda3\condabin\conda.bat"
$base = "C:\Users\ADMIN\Desktop\ts\VDMAF_main\newidea\Java"
# seed 42 baseline metrics -> per-seed naming for the aggregator
if ((Test-Path "$base\baseline_vdmaf\baseline_metrics_megavul_java.json") -and
    -not (Test-Path "$base\baseline_vdmaf\baseline_metrics_megavul_java_seed42.json")) {
    Copy-Item "$base\baseline_vdmaf\baseline_metrics_megavul_java.json" "$base\baseline_vdmaf\baseline_metrics_megavul_java_seed42.json"
}
$cfgs = @(
    @("v1_both",        "both", "all"),
    @("v1_gnn",         "gnn",  "all"),
    @("v1_seq",         "seq",  "all"),
    @("v1_both_cdgddg", "both", "cdg_ddg")
)
foreach ($seed in 43, 44, 45, 46) {
    Write-Output "=== SEED $seed START  $(Get-Date -Format HH:mm:ss) ==="
    if (-not (Test-Path "$base\baseline_vdmaf\baseline_metrics_megavul_java_seed$seed.json")) {
        Set-Location "$base\baseline_vdmaf"
        & $conda run -n vdmaf python -u makemodel_megavul.py $seed
    }
    Set-Location "$base\gnn"
    foreach ($c in $cfgs) {
        $name, $ch, $ed = $c
        if (Test-Path "$base\gnn\runs\${name}_s$seed\metrics.json") { continue }
        & $conda run -n vdmaf-gnn python -u train_v1.py --channels $ch --edges $ed --epochs 25 --patience 5 --seed $seed --out "runs/${name}_s$seed"
    }
    Write-Output "=== SEED $seed GROUP DONE  $(Get-Date -Format HH:mm:ss) ==="
}
Write-Output "=== MULTISEED ALL DONE  $(Get-Date -Format HH:mm:ss) ==="
