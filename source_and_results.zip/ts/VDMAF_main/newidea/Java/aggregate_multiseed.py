# -*- coding: utf-8 -*-
# Aggregate multi-seed test metrics (mean ± std) for the artifact baseline and
# the 4 proposed-model configs. Prints a markdown table and saves
# multiseed_summary.json. Runs in either env (needs numpy only).
import glob
import json
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
SEEDS = [42, 43, 44, 45, 46]
METRICS = ["pr_auc", "roc_auc", "f1@0.5", "mcc@0.5", "f1@val_t"]

models = {}

rows = []
for s in SEEDS:
    p = os.path.join(HERE, "baseline_vdmaf",
                     "baseline_metrics_megavul_java_seed%d.json" % s)
    if os.path.isfile(p):
        with open(p, encoding="utf-8") as f:
            rows.append(json.load(f)["test"])
models["VDMAF-artifact"] = rows

for cfg in ["v1_both", "v1_gnn", "v1_seq", "v1_both_cdgddg"]:
    rows = []
    for s in SEEDS:
        d = cfg if s == 42 else "%s_s%d" % (cfg, s)
        p = os.path.join(HERE, "gnn", "runs", d, "metrics.json")
        if os.path.isfile(p):
            with open(p, encoding="utf-8") as f:
                rows.append(json.load(f)["test"])
    models[cfg] = rows

summary = {}
print("| Model | n_seeds | " + " | ".join(METRICS) + " |")
print("|---|---|" + "---|" * len(METRICS))
for name, rows in models.items():
    if not rows:
        continue
    entry = {"n_seeds": len(rows)}
    cells = []
    for m in METRICS:
        vals = np.array([r[m] for r in rows])
        entry[m] = {"mean": float(vals.mean()), "std": float(vals.std(ddof=1) if len(vals) > 1 else 0.0),
                    "values": [float(v) for v in vals]}
        cells.append("%.3f ± %.3f" % (entry[m]["mean"], entry[m]["std"]))
    summary[name] = entry
    print("| %s | %d | %s |" % (name, len(rows), " | ".join(cells)))

with open(os.path.join(HERE, "multiseed_summary.json"), "w", encoding="utf-8") as f:
    json.dump(summary, f, indent=2)
print("\nsaved -> multiseed_summary.json")
