"""Download or import release assets, verify SHA256, and safely unpack them.

Examples:
  python scripts/prepare_data.py --download --profile test
  python scripts/prepare_data.py --assets-dir /path/to/downloaded/assets --profile full

test: all prepared tensor inputs plus five train_full checkpoints.
full: all prepared inputs, all 45 checkpoints, and raw reconstruction sources.
raw: raw reconstruction sources only. Code and small evidence files come from
the repository/core archive. Existing different files are never overwritten.
"""
from __future__ import annotations

import argparse
import hashlib
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import tempfile
import urllib.parse
import urllib.request
import zipfile

from evaluate import Package, ROOT, read_json, require, sha256


def safe_name(value, leaf=False):
    require(isinstance(value, str), "Asset paths must be strings")
    path = PurePosixPath(value)
    require(value not in ("", ".") and "\\" not in value and ":" not in value
            and not path.is_absolute() and ".." not in path.parts and str(path) == value,
            f"Unsafe asset path: {value!r}")
    require(not leaf or len(path.parts) == 1, f"Archive name must be a basename: {value!r}")
    return value


def download(asset, path, repo, tag):
    url = (f"https://github.com/{repo}/releases/download/"
           f"{urllib.parse.quote(tag, safe='')}/{urllib.parse.quote(asset['name'], safe='')}")
    path.parent.mkdir(parents=True, exist_ok=True)
    request = urllib.request.Request(url, headers={"User-Agent": "thesis-evaluation-package/1"})
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(prefix=path.name + ".", suffix=".part",
                                         dir=path.parent, delete=False) as target:
            temporary = Path(target.name)
            digest, count = hashlib.sha256(), 0
            with urllib.request.urlopen(request, timeout=60) as response:
                for block in iter(lambda: response.read(1024 * 1024), b""):
                    count += len(block)
                    require(count <= asset["size"], f"Downloaded archive exceeds declared size: {asset['name']}")
                    digest.update(block)
                    target.write(block)
            target.flush()
            os.fsync(target.fileno())
        require(count == asset["size"] and digest.hexdigest() == asset["sha256"],
                f"Downloaded archive failed SHA256/size verification: {asset['name']}")
        require(not path.exists(), f"Archive appeared during download; inspect before retry: {path}")
        temporary.rename(path)
        temporary = None
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def unpack(asset, archive, package, staging_root):
    # This check MUST precede opening/decompressing any archive content.
    require(archive.is_file() and archive.stat().st_size == asset["size"]
            and sha256(archive) == asset["sha256"],
            f"Archive SHA256/size mismatch: {archive}; obtain a fresh matching asset")
    expected = {}
    for entry in asset["members"]:
        name = safe_name(entry["path"])
        require(name not in expected, f"Duplicate asset member: {name}")
        require(package.files.get(name) == entry,
                f"Asset member differs from MANIFEST.json: {name}")
        expected[name] = entry
    written, retained = 0, 0
    with zipfile.ZipFile(archive) as source:
        infos = {}
        for info in source.infolist():
            if info.is_dir():
                safe_name(info.filename.rstrip("/"))
                continue
            name = safe_name(info.filename)
            require(name not in infos, f"Duplicate ZIP entry: {name}")
            mode = stat.S_IFMT(info.external_attr >> 16)
            require(mode in (0, stat.S_IFREG), f"Nonregular ZIP entry: {name}")
            require(not info.flag_bits & 1, f"Encrypted ZIP entry is unsupported: {name}")
            infos[name] = info
        require(set(infos) == set(expected), f"ZIP member list differs from ASSETS.json: {asset['name']}")
        missing = []
        # Preflight every destination before writing any destination file.
        for name, info in infos.items():
            entry = expected[name]
            require(info.file_size == entry["size"], f"ZIP uncompressed size mismatch: {name}")
            destination = (package.root / name).resolve()
            require(destination.is_relative_to(package.root), f"Destination escapes package: {name}")
            if destination.exists():
                require(destination.is_file() and destination.stat().st_size == entry["size"]
                        and sha256(destination) == entry["sha256"],
                        f"Refusing to overwrite different existing file: {destination}")
                retained += 1
            else:
                missing.append((name, info, destination))
        # Stage and hash complete decompressed content before committing files.
        with tempfile.TemporaryDirectory(prefix="verified-assets-", dir=staging_root) as temporary:
            staging = Path(temporary)
            for name, info, _ in missing:
                target = staging / name
                target.parent.mkdir(parents=True, exist_ok=True)
                digest, count = hashlib.sha256(), 0
                with source.open(info) as reader, target.open("wb") as writer:
                    for block in iter(lambda: reader.read(1024 * 1024), b""):
                        count += len(block)
                        require(count <= expected[name]["size"], f"Expanded size exceeds manifest: {name}")
                        writer.write(block)
                        digest.update(block)
                require(count == expected[name]["size"] and digest.hexdigest() == expected[name]["sha256"],
                        f"Extracted member failed SHA256/size verification: {name}")
            for name, _, destination in missing:
                require(not destination.exists(), f"File appeared during preparation: {destination}")
                destination.parent.mkdir(parents=True, exist_ok=True)
                require(destination.resolve().is_relative_to(package.root), f"Destination escaped package: {name}")
                # Exclusive creation prevents replacing a concurrently created file.
                with (staging / name).open("rb") as reader, destination.open("xb") as writer:
                    shutil.copyfileobj(reader, writer, length=1024 * 1024)
                written += 1
    return written, retained


def main(argv=None):
    cli = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    cli.add_argument("--assets-dir", type=Path, default=ROOT / "downloads")
    cli.add_argument("--download", action="store_true", help="Download missing archives from GitHub Releases")
    cli.add_argument("--repo", default="lamvip24042002/luan-van-vdmaf-java")
    cli.add_argument("--tag", default="v1.0-evaluation")
    cli.add_argument("--profile", choices=("test", "full", "raw"), default="test")
    args = cli.parse_args(argv)
    require(re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", args.repo), "Invalid GitHub owner/repository")
    require(bool(args.tag), "Release tag cannot be empty")
    package = Package(ROOT)
    document = read_json(ROOT / "ASSETS.json")
    require(document["schema_version"] == 1, "Unsupported ASSETS.json schema")
    assets = document["assets"]
    names = [safe_name(asset["name"], leaf=True) for asset in assets]
    require(len(names) == len(set(names)), "Duplicate asset archive names")
    selected = assets if args.profile == "full" else [asset for asset in assets if args.profile in asset["profiles"]]
    require(bool(selected), f"No assets for profile: {args.profile}")
    args.assets_dir = args.assets_dir.resolve()
    args.assets_dir.mkdir(parents=True, exist_ok=True)
    total = sum(asset["size"] for asset in selected)
    print(f"Profile {args.profile}: {len(selected)} archives, {total / 1024**2:.1f} MiB compressed", flush=True)
    for asset in selected:
        require(type(asset["size"]) is int and asset["size"] >= 0
                and re.fullmatch(r"[0-9a-f]{64}", asset["sha256"]), f"Invalid asset metadata: {asset['name']}")
        archive = args.assets_dir / asset["name"]
        if not archive.exists():
            require(args.download, f"Missing {archive}. Use --download or supply --assets-dir containing release ZIPs.")
            print(f"Downloading {asset['name']}...", flush=True)
            download(asset, archive, args.repo, args.tag)
        written, retained = unpack(asset, archive, package, args.assets_dir)
        print(f"Verified {asset['name']}: installed {written}, already identical {retained}", flush=True)
    print(f"Prepared {args.profile} assets successfully. Run scripts/evaluate.py for checkpoint evaluation.", flush=True)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError, zipfile.BadZipFile) as error:
        raise SystemExit(f"Asset preparation failed: {error}")
