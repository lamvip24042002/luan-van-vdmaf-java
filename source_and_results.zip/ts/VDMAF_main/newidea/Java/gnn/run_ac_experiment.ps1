# Access-control task before/after PCFinder: pos=AC-CWE vuln, neg=safe.
# 4 configs x 5 seeds on dataset_v2, only difference within pair is --pcf. Resumable.
$conda = "C:\Users\ADMIN\miniconda3\condabin\conda.bat"
Set-Location "C:\Users\ADMIN\Desktop\ts\VDMAF_main\newidea\Java\gnn"
foreach ($seed in 42, 43, 44, 45, 46) {
    Write-Output "=== AC SEED $seed START  $(Get-Date -Format HH:mm:ss) ==="
    $runs = @(
        @("ac_both_off", "both", ""),
        @("ac_both_on",  "both", "--pcf"),
        @("ac_gnn_off",  "gnn",  ""),
        @("ac_gnn_on",   "gnn",  "--pcf")
    )
    foreach ($r in $runs) {
        $name, $ch, $flag = $r
        $dir = "runs/${name}_s$seed"
        if (Test-Path "$dir/metrics.json") { continue }
        if ($flag -eq "--pcf") {
            & $conda run -n vdmaf-gnn python -u train_v1.py --ds dataset_v2 --channels $ch --edges all --epochs 30 --patience 6 --seed $seed --out $dir --ac_only --pcf
        } else {
            & $conda run -n vdmaf-gnn python -u train_v1.py --ds dataset_v2 --channels $ch --edges all --epochs 30 --patience 6 --seed $seed --out $dir --ac_only
        }
    }
    Write-Output "=== AC SEED $seed GROUP DONE  $(Get-Date -Format HH:mm:ss) ==="
}
Write-Output "=== AC EXPERIMENT ALL DONE  $(Get-Date -Format HH:mm:ss) ==="
