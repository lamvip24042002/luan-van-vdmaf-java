# Extend GNN±pcf pair on broadened AC to 20 seeds (52-61) to test robustness
# of the borderline p=0.032 seen at 10 seeds. Resumable.
$conda = "C:\Users\ADMIN\miniconda3\condabin\conda.bat"
Set-Location "C:\Users\ADMIN\Desktop\ts\VDMAF_main\newidea\Java\gnn"
foreach ($seed in 52,53,54,55,56,57,58,59,60,61) {
    Write-Output "=== ACBX SEED $seed START  $(Get-Date -Format HH:mm:ss) ==="
    foreach ($r in @(@("acb_gnn_off",""), @("acb_gnn_on","--pcf"))) {
        $name,$flag = $r
        $dir = "runs/${name}_s$seed"
        if (Test-Path "$dir/metrics.json") { continue }
        if ($flag -eq "--pcf") {
            & $conda run -n vdmaf-gnn python -u train_v1.py --ds dataset_v2 --channels gnn --edges all --epochs 30 --patience 6 --seed $seed --out $dir --ac_only --ac_broad --pcf
        } else {
            & $conda run -n vdmaf-gnn python -u train_v1.py --ds dataset_v2 --channels gnn --edges all --epochs 30 --patience 6 --seed $seed --out $dir --ac_only --ac_broad
        }
    }
    Write-Output "=== ACBX SEED $seed DONE  $(Get-Date -Format HH:mm:ss) ==="
}
Write-Output "=== ACBX ALL DONE  $(Get-Date -Format HH:mm:ss) ==="
