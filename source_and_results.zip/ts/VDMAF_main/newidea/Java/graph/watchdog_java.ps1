# RAM guard for the CPG batch run: logs every 30 s; if free RAM < 3 GB kills
# java+python; exits when driver log says ALL BATCHES DONE or after 6 h.
$log = "C:\Users\ADMIN\Desktop\ts\VDMAF_main\newidea\Java\graph\watchdog_java.log"
$driverlog = "C:\Users\ADMIN\Desktop\ts\VDMAF_main\newidea\Java\graph\run_batches_java.log"
$deadline = (Get-Date).AddHours(6)
Add-Content $log "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') java watchdog started"
while ((Get-Date) -lt $deadline) {
    $os = Get-CimInstance Win32_OperatingSystem
    $freeGB = [math]::Round($os.FreePhysicalMemory/1MB, 1)
    $procs = Get-Process java*, python* -ErrorAction SilentlyContinue
    $pGB = 0
    if ($procs) { $pGB = [math]::Round((($procs | Measure-Object WorkingSet64 -Sum).Sum)/1GB, 1) }
    Add-Content $log "$(Get-Date -Format HH:mm:ss) free=${freeGB}GB jvm+py=${pGB}GB"
    if ($freeGB -lt 3) {
        Add-Content $log "$(Get-Date -Format HH:mm:ss) LIMIT HIT (free=${freeGB}GB) -> killing java+python"
        if ($procs) { $procs | Stop-Process -Force }
    }
    if (Select-String -Path $driverlog -Pattern "ALL BATCHES DONE" -Quiet -ErrorAction SilentlyContinue) {
        Add-Content $log "$(Get-Date -Format HH:mm:ss) batch run finished -> watchdog exits"
        break
    }
    Start-Sleep -Seconds 30
}
