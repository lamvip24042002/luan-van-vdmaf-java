#!/usr/bin/env python3
"""Aggregate the paired legacy-VDMAF PCFinder experiment.

The primary inference is two-sided.  One-sided improvement p-values are emitted
as explicitly secondary diagnostics.  Runs are paired by seed, never by file
enumeration order.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import numpy as np

try:
    from scipy.stats import wilcoxon
except ImportError as exc:  # pragma: no cover - environment error, not a statistic
    raise SystemExit(
        "aggregate_compare.py requires scipy (available in the vdmaf-gnn env)."
    ) from exc


HERE = Path(__file__).resolve().parent
FULL_SEEDS = (42, 43, 44, 45, 46)
SMOKE_SEEDS = (42,)
METRICS = (
    "pr_auc",
    "roc_auc",
    "f1@0.5",
    "mcc@0.5",
    "f1@val_t",
    "mcc@val_t",
)
REQUIRED_TOP_LEVEL = ("config", "data", "word2vec", "training", "val", "test")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Aggregate paired legacy VDMAF runs with PCFinder off/on."
    )
    parser.add_argument("--mode", choices=("smoke", "full"), default="full")
    parser.add_argument(
        "--root",
        type=Path,
        default=None,
        help="Run root (default: runs_compare/<mode> beside this script).",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=None,
        help="Summary JSON path (default: <root>/compare_summary.json).",
    )
    parser.add_argument(
        "--allow-incomplete",
        action="store_true",
        help="Aggregate only complete pairs instead of failing on missing runs.",
    )
    return parser.parse_args()


def load_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"cannot read valid JSON: {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise ValueError(f"expected a JSON object: {path}")
    return value


def finite_number(value: Any, label: str) -> float:
    if isinstance(value, bool):
        raise ValueError(f"{label} must be numeric, not boolean")
    try:
        number = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{label} is not numeric: {value!r}") from exc
    if not math.isfinite(number):
        raise ValueError(f"{label} is not finite: {value!r}")
    return number


def validate_metrics(metrics: dict[str, Any], path: Path) -> dict[str, float]:
    missing_sections = [key for key in REQUIRED_TOP_LEVEL if key not in metrics]
    if missing_sections:
        raise ValueError(f"{path} lacks sections: {', '.join(missing_sections)}")
    test = metrics["test"]
    if not isinstance(test, dict):
        raise ValueError(f"{path}: test must be an object")
    missing_metrics = [key for key in METRICS if key not in test]
    if missing_metrics:
        raise ValueError(f"{path} lacks test metrics: {', '.join(missing_metrics)}")
    return {
        name: finite_number(test[name], f"{path}: test.{name}") for name in METRICS
    }


def normalized_config(config: Any) -> Any:
    """Remove only the treatment and output location from recorded config."""
    ignored = {"pcf", "out", "output", "output_dir", "run_dir"}
    if isinstance(config, dict):
        return {
            key: normalized_config(value)
            for key, value in config.items()
            if key not in ignored
        }
    if isinstance(config, list):
        return [normalized_config(value) for value in config]
    return config


def comparable_spec(spec: dict[str, Any]) -> dict[str, Any]:
    ignored = {"variant", "pcf"}
    return {key: value for key, value in spec.items() if key not in ignored}


def validate_pair(
    root: Path, seed: int, mode: str
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    loaded: dict[str, dict[str, Any]] = {}
    for variant, expected_pcf in (("off", False), ("on", True)):
        run_dir = root / f"{variant}_seed{seed}"
        spec_path = run_dir / "run_spec.json"
        metrics_path = run_dir / "metrics.json"
        if not spec_path.is_file() or not metrics_path.is_file():
            raise FileNotFoundError(
                f"missing {variant} seed={seed}: expected {spec_path} and {metrics_path}"
            )
        spec = load_json(spec_path)
        metrics = load_json(metrics_path)
        values = validate_metrics(metrics, metrics_path)
        if spec.get("experiment") != "legacy_vdmaf_pcf_paired":
            raise ValueError(f"unexpected experiment in {spec_path}")
        if spec.get("mode") != mode or int(spec.get("seed", -1)) != seed:
            raise ValueError(f"mode/seed mismatch in {spec_path}")
        if spec.get("variant") != variant or spec.get("pcf") is not expected_pcf:
            raise ValueError(f"treatment mismatch in {spec_path}")
        recorded_config = metrics["config"]
        if not isinstance(recorded_config, dict):
            raise ValueError(f"{metrics_path}: config must be an object")
        if recorded_config.get("pcf") is not expected_pcf:
            raise ValueError(f"recorded PCFinder treatment mismatch in {metrics_path}")
        try:
            recorded_seed = int(recorded_config.get("seed", -1))
        except (TypeError, ValueError) as exc:
            raise ValueError(f"invalid recorded seed in {metrics_path}") from exc
        if recorded_seed != seed:
            raise ValueError(f"recorded seed mismatch in {metrics_path}")
        loaded[variant] = {"spec": spec, "metrics": metrics, "values": values}

    off, on = loaded["off"], loaded["on"]
    audit = {
        "wrapper_specs_equal_except_treatment": comparable_spec(off["spec"])
        == comparable_spec(on["spec"]),
        "recorded_configs_equal_except_treatment": normalized_config(
            off["metrics"]["config"]
        )
        == normalized_config(on["metrics"]["config"]),
        "data_metadata_equal": off["metrics"]["data"] == on["metrics"]["data"],
        "word2vec_metadata_equal": off["metrics"]["word2vec"]
        == on["metrics"]["word2vec"],
        "model_metadata_equal_except_treatment": normalized_config(
            off["metrics"].get("model")
        ) == normalized_config(on["metrics"].get("model")),
        "initial_state_hash_equal": (
            off["metrics"].get("model", {}).get("initial_state_sha256")
            == on["metrics"].get("model", {}).get("initial_state_sha256")
            and bool(off["metrics"].get("model", {}).get("initial_state_sha256"))
        ),
    }
    failed = [name for name, passed in audit.items() if not passed]
    if failed:
        raise ValueError(
            f"seed {seed} is not a controlled pair; failed audit(s): {', '.join(failed)}"
        )
    return off, on, audit


def mean_std(values: Iterable[float]) -> dict[str, Any]:
    array = np.asarray(list(values), dtype=np.float64)
    return {
        "mean": float(array.mean()),
        "std": float(array.std(ddof=1)) if array.size > 1 else 0.0,
        "values": [float(value) for value in array],
    }


def exact_sign_test(differences: np.ndarray) -> dict[str, Any]:
    wins = int(np.count_nonzero(differences > 0.0))
    losses = int(np.count_nonzero(differences < 0.0))
    ties = int(np.count_nonzero(differences == 0.0))
    n = wins + losses
    if n == 0:
        return {
            "wins": wins,
            "losses": losses,
            "ties_excluded": ties,
            "n_effective": 0,
            "p_two_sided": 1.0,
            "p_greater_secondary": 1.0,
        }

    denominator = 2**n
    lower = sum(math.comb(n, k) for k in range(0, wins + 1)) / denominator
    upper = sum(math.comb(n, k) for k in range(wins, n + 1)) / denominator
    return {
        "wins": wins,
        "losses": losses,
        "ties_excluded": ties,
        "n_effective": n,
        "p_two_sided": float(min(1.0, 2.0 * min(lower, upper))),
        "p_greater_secondary": float(upper),
    }


def wilcoxon_tests(differences: np.ndarray) -> dict[str, Any]:
    if np.all(differences == 0.0):
        return {
            "statistic_two_sided": 0.0,
            "p_two_sided": 1.0,
            "statistic_greater_secondary": 0.0,
            "p_greater_secondary": 1.0,
            "zero_method": "wilcox",
            "method": "auto",
        }
    two_sided = wilcoxon(
        differences,
        alternative="two-sided",
        zero_method="wilcox",
        method="auto",
    )
    greater = wilcoxon(
        differences,
        alternative="greater",
        zero_method="wilcox",
        method="auto",
    )
    return {
        "statistic_two_sided": float(two_sided.statistic),
        "p_two_sided": float(two_sided.pvalue),
        "statistic_greater_secondary": float(greater.statistic),
        "p_greater_secondary": float(greater.pvalue),
        "zero_method": "wilcox",
        "method": "auto",
    }


def main() -> int:
    args = parse_args()
    expected_seeds = FULL_SEEDS if args.mode == "full" else SMOKE_SEEDS
    root = (args.root or (HERE / "runs_compare" / args.mode)).resolve()
    output = (args.output or (root / "compare_summary.json")).resolve()

    pairs: dict[int, dict[str, Any]] = {}
    missing: list[str] = []
    for seed in expected_seeds:
        try:
            off, on, audit = validate_pair(root, seed, args.mode)
        except FileNotFoundError as exc:
            missing.append(str(exc))
            continue
        pairs[seed] = {"off": off, "on": on, "audit": audit}

    if missing and not args.allow_incomplete:
        for message in missing:
            print(f"ERROR: {message}", file=sys.stderr)
        print(
            "Use --allow-incomplete only for an interim, non-final summary.",
            file=sys.stderr,
        )
        return 2
    if not pairs:
        print(f"ERROR: no complete pairs under {root}", file=sys.stderr)
        return 2

    paired_seeds = tuple(sorted(pairs))
    summary: dict[str, Any] = {
        "schema_version": 1,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "mode": args.mode,
        "root": str(root),
        "expected_seeds": list(expected_seeds),
        "paired_seeds": list(paired_seeds),
        "complete": not missing and paired_seeds == expected_seeds,
        "missing": missing,
        "inference": {
            "primary_alternative": "two-sided",
            "difference_direction": "pcf_on - pcf_off",
            "tests": "exact sign test (ties excluded) and paired Wilcoxon signed-rank",
            "multiple_testing_adjustment": None,
            "one_sided_values": "secondary diagnostics only",
            "interpretation": (
                "smoke mode validates plumbing only; do not use it for inference"
                if args.mode == "smoke"
                else "with five non-tied pairs, the smallest exact two-sided sign-test p-value is 0.0625"
            ),
        },
        "audit": {
            "all_pairs_controlled": True,
            "per_seed": {str(seed): pairs[seed]["audit"] for seed in paired_seeds},
        },
        "variants": {"off": {}, "on": {}},
        "paired": {},
    }

    for metric in METRICS:
        off_values = np.asarray(
            [pairs[seed]["off"]["values"][metric] for seed in paired_seeds],
            dtype=np.float64,
        )
        on_values = np.asarray(
            [pairs[seed]["on"]["values"][metric] for seed in paired_seeds],
            dtype=np.float64,
        )
        differences = on_values - off_values
        summary["variants"]["off"][metric] = mean_std(off_values)
        summary["variants"]["on"][metric] = mean_std(on_values)
        summary["paired"][metric] = {
            "mean_difference": float(differences.mean()),
            "std_difference": float(differences.std(ddof=1))
            if differences.size > 1
            else 0.0,
            "differences": {
                str(seed): float(value)
                for seed, value in zip(paired_seeds, differences)
            },
            "sign_test": exact_sign_test(differences),
            "wilcoxon": wilcoxon_tests(differences),
        }

    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    print(f"Controlled pairs: {len(paired_seeds)} ({', '.join(map(str, paired_seeds))})")
    print("Difference: PCFinder on - off; primary tests are TWO-SIDED")
    print(
        "| metric | off mean +/- std | on mean +/- std | paired mean diff "
        "| wins/losses/ties | sign p (2s) | Wilcoxon p (2s) |"
    )
    print("|---|---:|---:|---:|---:|---:|---:|")
    for metric in METRICS:
        off = summary["variants"]["off"][metric]
        on = summary["variants"]["on"][metric]
        paired = summary["paired"][metric]
        sign = paired["sign_test"]
        print(
            f"| {metric} | {off['mean']:.4f} +/- {off['std']:.4f} "
            f"| {on['mean']:.4f} +/- {on['std']:.4f} "
            f"| {paired['mean_difference']:+.4f} "
            f"| {sign['wins']}/{sign['losses']}/{sign['ties_excluded']} "
            f"| {sign['p_two_sided']:.4g} "
            f"| {paired['wilcoxon']['p_two_sided']:.4g} |"
        )
    if missing:
        print("WARNING: interim summary; missing expected pairs:")
        for message in missing:
            print(f"  - {message}")
    print(f"saved -> {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
