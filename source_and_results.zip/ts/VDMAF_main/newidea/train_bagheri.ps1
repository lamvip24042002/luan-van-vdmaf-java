$conda = "C:\Users\ADMIN\miniconda3\condabin\conda.bat"
Write-Output "=== Bagheri makemodel (sql)  $(Get-Date -Format HH:mm:ss) ==="
Set-Location "C:\Users\ADMIN\Desktop\ts\VDMAF_main\newidea\Bagheri\train_model"
& $conda run -n vdmaf python -u makemodel.py
Write-Output "=== BAGHERI DONE  $(Get-Date -Format HH:mm:ss) ==="
