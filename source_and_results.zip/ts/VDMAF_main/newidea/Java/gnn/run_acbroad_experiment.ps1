# Before/after PCFinder on the BROADENED access-control task (OWASP-A01/A07 CWE
# set: adds auth/CSRF/session to the strict authorization core). test positives
# 48 -> 66. 4 configs x 10 seeds (42-51). Resumable.
$conda = "C:\Users\ADMIN\miniconda3\condabin\conda.bat"
Set-Location "C:\Users\ADMIN\Desktop\ts\VDMAF_main\newidea\Java\gnn"
foreach ($seed in 42, 43, 44, 45, 46, 47, 48, 49, 50, 51) {
    Write-Output "=== ACB SEED $seed START  $(Get-Date -Format HH:mm:ss) ==="
    $runs = @(
        @("acb_both_off", "both", ""),
        @("acb_both_on",  "both", "--pcf"),
        @("acb_gnn_off",  "gnn",  ""),
        @("acb_gnn_on",   "gnn",  "--pcf")
    )
    foreach ($r in $runs) {
        $name, $ch, $flag = $r
        $dir = "runs/${name}_s$seed"
        if (Test-Path "$dir/metrics.json") { continue }
        if ($flag -eq "--pcf") {
            & $conda run -n vdmaf-gnn python -u train_v1.py --ds dataset_v2 --channels $ch --edges all --epochs 30 --patience 6 --seed $seed --out $dir --ac_only --ac_broad --pcf
        } else {
            & $conda run -n vdmaf-gnn python -u train_v1.py --ds dataset_v2 --channels $ch --edges all --epochs 30 --patience 6 --seed $seed --out $dir --ac_only --ac_broad
        }
    }
    Write-Output "=== ACB SEED $seed DONE  $(Get-Date -Format HH:mm:ss) ==="
}
Write-Output "=== ACB ALL DONE  $(Get-Date -Format HH:mm:ss) ==="
