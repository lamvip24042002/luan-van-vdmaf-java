# -*- coding: utf-8 -*-
# Figure 1: kien truc mo hinh de xuat (2 kenh + fusion hoc duoc).
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.abspath(os.path.join(HERE, "..", "figures"))
os.makedirs(OUT, exist_ok=True)

fig, ax = plt.subplots(figsize=(9.5, 9))
ax.set_xlim(-0.5, 12.5)
ax.set_ylim(-1.6, 12.3)
ax.axis("off")


def box(center, w, h, text, fc, ec, lw=1.4, fs=10.5, fw="normal", zorder=2):
    x, y = center
    b = FancyBboxPatch((x - w / 2, y - h / 2), w, h,
                        boxstyle="round,pad=0.06,rounding_size=0.12",
                        facecolor=fc, edgecolor=ec, linewidth=lw, zorder=zorder)
    ax.add_patch(b)
    ax.text(x, y, text, ha="center", va="center", fontsize=fs, fontweight=fw,
            zorder=zorder + 1, linespacing=1.35)
    return (x, y, w, h)


def arrow(src, dst, color="#333333", lw=1.3, style="-|>", ls="solid"):
    (x1, y1, w1, h1) = src
    (x2, y2, w2, h2) = dst
    p1 = (x1, y1 - h1 / 2) if y1 > y2 else (x1, y1 + h1 / 2)
    p2 = (x2, y2 + h2 / 2) if y1 > y2 else (x2, y2 - h2 / 2)
    a = FancyArrowPatch(p1, p2, arrowstyle=style, color=color, lw=lw,
                        linestyle=ls, mutation_scale=14, zorder=1)
    ax.add_patch(a)


BLUE_F, BLUE_E = "#eaf2fb", "#2980b9"
GREEN_F, GREEN_E = "#eafaf1", "#27ae60"
ORANGE_F, ORANGE_E = "#fdf2e9", "#e67e22"
GRAY_F, GRAY_E = "#f4f6f7", "#5d6d7e"

inp = box((6, 11.5), 5.6, 0.9, "Mã nguồn Java (một hàm)", GRAY_F, GRAY_E, fw="bold")

# Semantic channel headers
ax.text(3, 10.55, "KÊNH NGỮ NGHĨA", ha="center", fontsize=10.5, fontweight="bold", color=BLUE_E)
l1 = box((3, 9.9), 5.4, 1.0, "Tokenizer\n(giữ nguyên tên định danh)", BLUE_F, BLUE_E)
l2 = box((3, 8.5), 5.4, 0.9, "Embedding chung\n(vocab hợp nhất, 35.909 token)", BLUE_F, BLUE_E)
l3 = box((3, 7.1), 5.4, 0.9, "BiLSTM 2 chiều", BLUE_F, BLUE_E)
l4 = box((3, 5.7), 5.4, 0.9, "Trạng thái token\n" + r"$H_{seq} \in \mathbb{R}^{T \times D}$", BLUE_F, BLUE_E)

# Structure channel headers
ax.text(9, 10.55, "KÊNH CẤU TRÚC", ha="center", fontsize=10.5, fontweight="bold", color=GREEN_E)
r1 = box((9, 9.9), 5.4, 1.0, "Joern javasrc2cpg\n→ Code Property Graph", GREEN_F, GREEN_E)
r2 = box((9, 8.5), 5.4, 0.9, "PDG: cạnh AST / CFG / CDG / DDG", GREEN_F, GREEN_E)
r3 = box((9, 7.1), 5.4, 0.9, "Embedding chung (node,\ncùng vocab với kênh ngữ nghĩa)", GREEN_F, GREEN_E)
r4 = box((9, 5.7), 5.4, 0.9, "R-GCN 2 lớp\n(4 loại quan hệ: AST/CFG/CDG/DDG)", GREEN_F, GREEN_E)
r5 = box((9, 4.3), 5.4, 0.9, "Trạng thái node\n" + r"$H_{graph} \in \mathbb{R}^{N \times D}$", GREEN_F, GREEN_E)

fusion = box((6, 2.7), 8.2, 1.35,
             "Cross-Attention Fusion\nQuery = trạng thái token,  Key/Value = trạng thái node\n"
             "[TRỌNG SỐ HUẤN LUYỆN END-TO-END]",
             ORANGE_F, ORANGE_E, lw=2.2, fw="bold", fs=10.5)

pool = box((6, 1.3), 7.0, 0.8, "Mean-pool + concatenate [fusion, token, graph]", GRAY_F, GRAY_E)
mlp = box((6, 0.15), 4.2, 0.8, "MLP → Sigmoid", GRAY_F, GRAY_E)

arrow(inp, l1); arrow(inp, r1)
arrow(l1, l2); arrow(l2, l3); arrow(l3, l4)
arrow(r1, r2); arrow(r2, r3); arrow(r3, r4); arrow(r4, r5)
arrow(l4, fusion); arrow(r5, fusion)
arrow(fusion, pool); arrow(pool, mlp)

ax.text(6, -1.15, "Nhãn: Lỗ hổng (1) / An toàn (0)", ha="center", fontsize=11, fontweight="bold")
arrow(mlp, (6, -0.75, 0, 0))

ax.set_title("Kiến trúc mô hình đề xuất — VDMAF-Java", fontsize=13, fontweight="bold", pad=14)
fig.tight_layout()
for ext in ("png", "svg"):
    path = os.path.join(OUT, "fig1_kien_truc_de_xuat.%s" % ext)
    fig.savefig(path, dpi=200)
    print("saved ->", path)
