# Generate CPG + graph dump for every MegaVul-Java batch. Resumable: skips
# batches whose dump already exists. Cleans CPG + joern workspace per batch.
param(
    [string]$JoernHome = "C:\tools\joern-cli",
    [string]$DumpDir = "dumps_v2"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$g = $PSScriptRoot
$joern = [System.IO.Path]::GetFullPath($JoernHome)
$dumpRoot = if ([System.IO.Path]::IsPathRooted($DumpDir)) {
    [System.IO.Path]::GetFullPath($DumpDir)
} else {
    [System.IO.Path]::GetFullPath((Join-Path $g $DumpDir))
}

if (-not (Test-Path -LiteralPath "$joern\javasrc2cpg.bat")) {
    throw "javasrc2cpg.bat not found under JoernHome: $joern"
}
if (-not (Test-Path -LiteralPath "$joern\joern.bat")) {
    throw "joern.bat not found under JoernHome: $joern"
}
Set-Location $g
New-Item -ItemType Directory -Force $dumpRoot | Out-Null

$batches = Get-ChildItem "$g\src_all" -Directory | Sort-Object Name
$total = $batches.Count
$i = 0

function Test-DumpComplete([string]$DumpFile, [string]$LogFile) {
    if (-not (Test-Path -LiteralPath $DumpFile -PathType Leaf)) { return $false }
    if ((Get-Item -LiteralPath $DumpFile).Length -eq 0) { return $false }

    # New dumps contain an explicit sentinel.  Accept historical dumps only
    # when Joern's corresponding log records the successful final message.
    $lastLine = Get-Content -LiteralPath $DumpFile -Tail 1
    if ($lastLine -match '^#DONE\t\d+$') { return $true }
    if (Test-Path -LiteralPath $LogFile -PathType Leaf) {
        return [bool](Select-String -LiteralPath $LogFile -Pattern 'dumped \d+ methods ->' -Quiet)
    }
    return $false
}

foreach ($b in $batches) {
    $i++
    $name = $b.Name
    $dumpFile = Join-Path $dumpRoot "graph_$name.txt"
    $dumpLog = Join-Path $dumpRoot "dump_$name.log"
    if (Test-DumpComplete $dumpFile $dumpLog) {
        Write-Output "=== BATCH $name SKIP (validated complete) ==="
        continue
    }
    $t0 = Get-Date
    try {
        & "$joern\javasrc2cpg.bat" $b.FullName --output "$g\tmp_$name.cpg" *> (Join-Path $dumpRoot "parse_$name.log")
        if ($LASTEXITCODE -ne 0) {
            throw "javasrc2cpg failed for $name (exit $LASTEXITCODE); see parse_$name.log"
        }
        & "$joern\joern.bat" --script "$g\dump_graph_java.sc" --param """cpgFile=$g\tmp_$name.cpg""" --param """outFile=$dumpFile""" *> $dumpLog
        if ($LASTEXITCODE -ne 0) {
            throw "Joern dump failed for $name (exit $LASTEXITCODE); see dump_$name.log"
        }
        $dt = [math]::Round(((Get-Date) - $t0).TotalSeconds)
        if (Test-DumpComplete $dumpFile $dumpLog) {
            Write-Output "=== BATCH $name DONE ($i/$total) ${dt}s ==="
        } else {
            throw "Batch $name returned without a validated complete dump"
        }
    } finally {
        Remove-Item "$g\tmp_$name.cpg" -Force -ErrorAction SilentlyContinue
        Remove-Item "$g\workspace" -Recurse -Force -ErrorAction SilentlyContinue
    }
}
Write-Output "=== ALL BATCHES DONE  $(Get-Date -Format HH:mm:ss) ==="
