# -*- coding: utf-8 -*-
# Dataset v2 = dataset v1 + 4 PCFinder-inspired node feature flags, built from
# the v2 dumps (N lines carry node kind). REUSES vocab.json from v1 so token
# ids stay identical — the before/after experiment differs ONLY in x_flags.
#
# Flags (float 0/1), reconstruction documented in PCFinder_phan_tich mục 2.6:
#   0 is_credential_like : token contains a credential root word (PCFinder's
#       initial roots role/pass/permiss + extensions exemplified in the paper;
#       english_rules.py in the released code is empty, so this is our
#       documented reconstruction).
#   1 is_privileged_op   : CALL node whose name is a DB/file/network privileged
#       operation (reconstruction of PCFinder's 42-JDK-API idea by method name).
#   2 is_interruption    : CONTROL_STRUCTURE 'throw', RETURN node, or CALL to
#       redirect/forward-style APIs (PCFinder's 3 interruption types).
#   3 flows_from_param   : node reachable from a METHOD_PARAMETER_IN over
#       directed REACHING_DEF edges (intra-function proxy of PCFinder's
#       user-controllability analysis).
import glob
import json
import os
from collections import deque

import torch

HERE = os.path.dirname(os.path.abspath(__file__))
DUMPS = sorted(glob.glob(os.path.join(HERE, "..", "graph", "dumps_v2", "graph_batch_*.txt")))
LABELS = os.path.join(HERE, "..", "graph", "labels_all.tsv")
OUT = os.path.join(HERE, "dataset_v2")
os.makedirs(OUT, exist_ok=True)

MAX_NODES = 2000
EDGE_TYPES = {"AST": 0, "CFG": 1, "CDG": 2, "REACHING_DEF": 3}
SKIP_METHODS = {"<init>", "<clinit>"}

CRED_ROOTS = [
    # PCFinder initial naming model (paper §IV-A1)
    "role", "pass", "permiss",
    # extensions exemplified in the paper (§III-A/IV-A2: id-suffix pattern via
    # userId/memberId/roleId; isAdmin; secretToken; ownsAllRight) + common
    # access-control vocabulary
    "auth", "token", "admin", "user", "member", "login", "owner",
    "priv", "right", "secret", "session", "account", "credential",
]
PRIV_OPS = {
    # database (JDBC + common mapper verbs)
    "executeQuery", "executeUpdate", "executeBatch", "execute",
    "prepareStatement", "createStatement", "query", "insert", "update",
    "delete", "selectOne", "selectList", "save", "saveOrUpdate", "remove",
    # file handling
    "write", "read", "mkdir", "mkdirs", "createNewFile", "renameTo",
    "transferTo", "deleteOnExit",
    # network
    "openConnection", "openStream", "connect", "getOutputStream",
}
REDIRECT_OPS = {"sendRedirect", "redirect", "forward", "sendError"}

labels = {}
with open(LABELS, encoding="utf-8") as f:
    next(f)
    for line in f:
        p = line.rstrip("\n").split("\t")
        labels[p[0]] = (p[1], int(p[2]))

with open(os.path.join(HERE, "dataset", "vocab.json"), encoding="utf-8") as f:
    vocab = json.load(f)
print("reusing v1 vocab:", len(vocab))

cred_cache = {}


def is_cred(tok):
    v = cred_cache.get(tok)
    if v is None:
        low = tok.lower()
        v = any(r in low for r in CRED_ROOTS)
        cred_cache[tok] = v
    return v


def node_flags(tok, kind):
    f0 = 1.0 if is_cred(tok) else 0.0
    f1 = 1.0 if (kind == "CALL" and tok in PRIV_OPS) else 0.0
    f2 = 1.0 if ((kind == "CONTROL_STRUCTURE" and tok == "throw")
                 or kind == "RETURN"
                 or (kind == "CALL" and tok in REDIRECT_OPS)) else 0.0
    return f0, f1, f2


def fid_of(path):
    base = os.path.basename(path)
    return base[:-5] if base.endswith(".java") else None


def iter_methods():
    for path in DUMPS:
        with open(path, encoding="utf-8") as f:
            name, fid, nodes, edges = None, None, {}, []
            for line in f:
                if line.startswith("#M"):
                    if name is not None:
                        yield fid, name, nodes, edges
                    p = line.rstrip("\n").split("\t")
                    name, fid, nodes, edges = p[1], fid_of(p[2]), {}, []
                elif line.startswith("N"):
                    p = line.rstrip("\n").split("\t")
                    kind = p[3] if len(p) > 3 else ""
                    nodes[p[1]] = (p[2], kind)
                elif line.startswith("E"):
                    p = line.rstrip("\n").split("\t")
                    edges.append((p[1], p[2], p[3]))
            if name is not None:
                yield fid, name, nodes, edges


print("building graphs with flags...")
graphs = {}
for fid, name, nodes, edges in iter_methods():
    if fid is None or fid not in labels or name in SKIP_METHODS:
        continue
    g = graphs.setdefault(fid, {"tokens": [], "flags": [], "kinds": [],
                                "edges": [], "id2idx": {}})
    id2idx = g["id2idx"]
    for nid, (tok, kind) in nodes.items():
        if nid not in id2idx and len(g["tokens"]) < MAX_NODES:
            id2idx[nid] = len(g["tokens"])
            g["tokens"].append(vocab.get(tok, 1))
            g["flags"].append(list(node_flags(tok, kind)))
            g["kinds"].append(kind)
    for s, d, t in edges:
        si, di = id2idx.get(s), id2idx.get(d)
        if si is not None and di is not None:
            g["edges"].append((si, di, EDGE_TYPES[t]))

data = {"train": [], "validation": [], "test": []}
skipped_empty = 0
flag_totals = [0, 0, 0, 0]
for fid, (split, y) in labels.items():
    g = graphs.get(fid)
    if g is None or len(g["tokens"]) == 0 or len(g["edges"]) == 0:
        skipped_empty += 1
        continue
    n = len(g["tokens"])
    # flag 3: BFS from METHOD_PARAMETER_IN nodes over directed REACHING_DEF
    adj = {}
    for si, di, t in g["edges"]:
        if t == 3:
            adj.setdefault(si, []).append(di)
    seen = set(i for i, k in enumerate(g["kinds"]) if k == "METHOD_PARAMETER_IN")
    dq = deque(seen)
    while dq:
        u = dq.popleft()
        for v in adj.get(u, ()):
            if v not in seen:
                seen.add(v)
                dq.append(v)
    flags = g["flags"]
    for i in seen:
        flags[i] = flags[i][:3] + [1.0] if len(flags[i]) == 3 else flags[i]
    for i in range(n):
        if len(flags[i]) == 3:
            flags[i] = flags[i] + [0.0]
    e = torch.tensor(g["edges"], dtype=torch.long)
    x_flags = torch.tensor(flags, dtype=torch.float)
    for k in range(4):
        flag_totals[k] += int(x_flags[:, k].sum())
    data[split].append({
        "fid": fid,
        "x": torch.tensor(g["tokens"], dtype=torch.long),
        "x_flags": x_flags,
        "edge_index": e[:, :2].t().contiguous(),
        "edge_type": e[:, 2].contiguous(),
        "y": y,
    })

for split, items in data.items():
    torch.save(items, os.path.join(OUT, split + ".pt"))
    nv = sum(it["y"] for it in items)
    print("%-11s graphs=%6d  vul=%5d" % (split, len(items), nv))

total_nodes = sum(len(it["x"]) for s in data.values() for it in s)
print("skipped_empty:", skipped_empty, "| total nodes:", total_nodes)
for k, nm in enumerate(["cred_like", "privileged_op", "interruption", "flows_from_param"]):
    print("flag %-17s %8d nodes (%.2f%%)" % (nm, flag_totals[k],
                                             100.0 * flag_totals[k] / total_nodes))
# copy seq files reference: seq_*.pt stay in dataset/ (unchanged, shared)
print("saved ->", OUT, "(seq_*.pt and vocab shared from dataset/)")
