# 10 extra seeds (47-56) for the MegaVul-AC GNN±flags pair only — the specific
# hypothesis to strengthen statistically. Resumable.
$conda = "C:\Users\ADMIN\miniconda3\condabin\conda.bat"
Set-Location "C:\Users\ADMIN\Desktop\ts\VDMAF_main\newidea\Java\gnn"
foreach ($seed in 47, 48, 49, 50, 51, 52, 53, 54, 55, 56) {
    Write-Output "=== ACX SEED $seed START  $(Get-Date -Format HH:mm:ss) ==="
    foreach ($r in @(@("ac_gnn_off", ""), @("ac_gnn_on", "--pcf"))) {
        $name, $flag = $r
        $dir = "runs/${name}_s$seed"
        if (Test-Path "$dir/metrics.json") { continue }
        if ($flag -eq "--pcf") {
            & $conda run -n vdmaf-gnn python -u train_v1.py --ds dataset_v2 --channels gnn --edges all --epochs 30 --patience 6 --seed $seed --out $dir --ac_only --pcf
        } else {
            & $conda run -n vdmaf-gnn python -u train_v1.py --ds dataset_v2 --channels gnn --edges all --epochs 30 --patience 6 --seed $seed --out $dir --ac_only
        }
    }
    Write-Output "=== ACX SEED $seed DONE  $(Get-Date -Format HH:mm:ss) ==="
}
Write-Output "=== ACX ALL DONE  $(Get-Date -Format HH:mm:ss) ==="
