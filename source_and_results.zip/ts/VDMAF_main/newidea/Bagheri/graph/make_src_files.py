# -*- coding: utf-8 -*-
# Write every source file of a VUDENC plain_<mode> dataset to its own .py
# file so Joern pysrc2cpg can parse them (batched for memory safety).
# Usage: python make_src_files.py [mode] [batch_size]
import json
import os
import sys

mode = sys.argv[1] if len(sys.argv) > 1 else "sql"
batch = int(sys.argv[2]) if len(sys.argv) > 2 else 500

with open('../dataset/plain_' + mode, 'r') as infile:
    data = json.load(infile)

outroot = 'src_' + mode
i = 0
for r in data:                      # repository
    for c in data[r]:               # commit
        if "files" not in data[r][c]:
            continue
        for f in data[r][c]["files"]:
            src = data[r][c]["files"][f].get("source")
            if not src:
                continue
            d = os.path.join(outroot, "batch_%02d" % (i // batch))
            os.makedirs(d, exist_ok=True)
            with open(os.path.join(d, "file_%d.py" % i), 'w',
                      encoding='utf-8') as fp:
                fp.write(src)
            i += 1

print("wrote", i, "files under", outroot)
