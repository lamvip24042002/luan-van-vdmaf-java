// Verify DDG quality: does `username` reach the executeQuery sink in findUser
// (vulnerable) and how does findUserSafe compare?
@main def exec(cpgFile: String) = {
  importCpg(cpgFile)
  run.ossdataflow
  val src  = cpg.method("findUser").parameter.name("username")
  val sink = cpg.call.name("executeQuery").argument
  val flows = sink.reachableByFlows(src).l
  println("=== findUser: flows username -> executeQuery: " + flows.size)
  flows.take(2).foreach(f => println(f.elements.map(e => e.code).mkString("  ->  ")))
  val src2  = cpg.method("findUserSafe").parameter.name("username")
  val sink2 = cpg.method("findUserSafe").ast.isCall.name("executeQuery").argument
  println("=== findUserSafe: flows username -> executeQuery: " + sink2.reachableByFlows(src2).size)
}
