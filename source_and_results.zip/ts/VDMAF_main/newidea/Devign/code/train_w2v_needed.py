# -*- coding: utf-8 -*-
# Train only the word2vec model that makemodel.py actually loads
# (CodeXGLUE_word2vec_5-100-300.model), with the exact same preprocessing
# and hyperparameters as train_w2vmodel.py.
import os.path
import pickle
import nltk
from gensim.models import Word2Vec

print("Loading corpus")
with open('corpus', 'r', encoding="utf-8") as file:
    Cdata = file.read().lower().replace('\n', ' ')
print("Length of the training file: " + str(len(Cdata)))

if os.path.isfile('Ccorpus_processed'):
    with open('Ccorpus_processed', 'rb') as fp:
        all_words = pickle.load(fp)
    print("loaded processed corpus.")
else:
    print("tokenizing...")
    all_sentences = nltk.sent_tokenize(Cdata)
    all_words = [nltk.word_tokenize(sent) for sent in all_sentences]
    with open('Ccorpus_processed', 'wb') as fp:
        pickle.dump(all_words, fp)
print("sentences:", len(all_words))

fname = "CodeXGLUE_word2vec_5-100-300.model"
if os.path.isfile(fname):
    print("model already exists.")
else:
    print("training w2v (min_count=5, epochs=100, size=300)...")
    model = Word2Vec(all_words, vector_size=300, min_count=5, epochs=100,
                     workers=6)
    print("vocab:", len(model.wv.key_to_index))
    model.save(fname)
    print("saved ->", fname)
