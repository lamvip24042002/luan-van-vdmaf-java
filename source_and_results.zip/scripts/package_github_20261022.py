"""Build the curated thesis evaluation package without modifying research inputs.

Run once to copy source/data and make release assets. Use --refresh after editing
submission documentation/evaluation scripts: it updates hashes and the core ZIP
without copying originals again or recompressing the eleven large data assets.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import zipfile


ROOT = Path(__file__).resolve().parents[1]
PACKAGE = ROOT / "github_submission"
RELEASE = ROOT / "github_release_assets"
SEMINAR = Path("output/seminar_20261011")
JAVA = Path("ts/VDMAF_main/newidea/Java")
EXCLUDE_DIRS = {".git", "__pycache__", ".venv", ".pytest_cache", "evaluation_outputs", "downloads"}
EXCLUDE_FILES = {"MANIFEST.json", "ASSETS.json"}


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def write_json(path: Path, value) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def copy_file(relative: Path) -> None:
    source = ROOT / relative
    target = PACKAGE / relative
    if not source.is_file():
        raise FileNotFoundError(source)
    if not target.exists():
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)


def curate() -> None:
    PACKAGE.mkdir(parents=True, exist_ok=True)
    names = [
        "build_seminar_inputs_20261011.py", "train_seminar_20261011.py",
        "run_seminar_20261011.py", "analyze_seminar_20261011.py",
        "plot_seminar_results_20261011.py", "plot_ac_terminology_20261011.py",
        "test_build_seminar_inputs_20261011.py", "test_train_seminar_20261011.py",
        "requirements_seminar_20261011.txt", "package_github_20261022.py",
    ]
    for name in names:
        copy_file(Path("scripts") / name)

    source_root = ROOT / "ts/VDMAF_main/newidea"
    source_suffixes = {".py", ".sc", ".scala", ".ps1", ".md"}
    for source in sorted(source_root.rglob("*")):
        parts = source.relative_to(source_root).parts
        if any(part.startswith("src_") or part in {
            "juliet", "sample_src", ".idea", "__pycache__", "runs", "model",
        } for part in parts):
            continue
        if source.is_file() and (source.suffix in source_suffixes or source.name == "requirements.txt"):
            copy_file(source.relative_to(ROOT))

    for name in ["BAO_CAO_THAY_DOI_SOURCE_CODE.md", "DOI_CHIEU_CODE_GOC_VS_SUA.md",
                 "HUONG_DAN_TAI_LAP_THI_NGHIEM.md", "PCFinder_phan_tich_ap_dung_VDMAF.md",
                 "baseline_report.md", "code_diffs_vs_upstream.txt"]:
        copy_file(Path("ts") / name)
    pcfinder = ROOT / "ts/PCFinder-main"
    for subfolder in ("python", "codeql"):
        for source in sorted((pcfinder / subfolder).rglob("*")):
            if source.is_file() and source.suffix in {".py", ".ql", ".qll", ".yml", ".yaml", ".md"}:
                copy_file(source.relative_to(ROOT))
    copy_file(Path("ts/PCFinder-main/README.md"))

    for folder in ("inputs", "runs"):
        for source in sorted((ROOT / SEMINAR / folder).rglob("*")):
            if source.is_file() and source.suffix in {".pt", ".json", ".csv", ".jsonl", ".log"}:
                copy_file(source.relative_to(ROOT))
    for name in ("protocol.json", "environment_freeze.txt", "completion_manifest.json", "status.json",
                 "provenance_history_vs_new.txt", "historical_relative_improvement_audit.json"):
        copy_file(SEMINAR / name)
    for source in sorted((ROOT / SEMINAR / "analysis").rglob("*")):
        if source.is_file() and source.suffix in {".csv", ".json", ".txt"}:
            copy_file(source.relative_to(ROOT))

    for split in ("train", "validation", "test"):
        copy_file(JAVA / "megavul" / f"{split}-00000-of-00001.parquet")
    copy_file(JAVA / "graph/labels_all.tsv")
    dumps = sorted((ROOT / JAVA / "graph/dumps_v2").glob("graph_batch_*.txt"))
    if len(dumps) != 21:
        raise ValueError(f"Expected 21 graph dumps, found {len(dumps)}")
    for source in dumps:
        copy_file(source.relative_to(ROOT))
    for name in ("vocab.json", "vocab_joint.json"):
        copy_file(JAVA / "gnn/dataset" / name)


def package_files():
    return [path for path in sorted(PACKAGE.rglob("*"))
            if path.is_file() and path.name not in EXCLUDE_FILES
            and not any(part in EXCLUDE_DIRS for part in path.relative_to(PACKAGE).parts)
            and path.suffix not in {".pyc", ".pyo"}]


def make_manifest():
    files = []
    for path in package_files():
        files.append({"path": path.relative_to(PACKAGE).as_posix(),
                      "size": path.stat().st_size, "sha256": digest(path)})
    document = {
        "schema_version": 1,
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "purpose": "Exact content identity for the curated thesis evaluation package",
        "excluded": ["MANIFEST.json", "ASSETS.json", ".git/", "__pycache__/", ".venv/",
                     ".pytest_cache/", "evaluation_outputs/", "downloads/"],
        "file_count": len(files), "total_size": sum(item["size"] for item in files), "files": files,
    }
    write_json(PACKAGE / "MANIFEST.json", document)
    return {item["path"]: item for item in files}


def create_zip(name: str, paths: list[str]) -> Path:
    target = RELEASE / name
    partial = target.with_suffix(".zip.partial")
    with zipfile.ZipFile(partial, "w", zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as archive:
        for name_in_zip in sorted(paths):
            path = PACKAGE / name_in_zip
            info = zipfile.ZipInfo(name_in_zip, date_time=(2026, 10, 22, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            with path.open("rb") as source, archive.open(info, "w", force_zip64=True) as member:
                shutil.copyfileobj(source, member, 8 * 1024 * 1024)
    partial.replace(target)
    print(f"Created {target.name}: {target.stat().st_size:,} bytes ({len(paths)} members)", flush=True)
    return target


def make_assets(manifest):
    inputs_prefix = (SEMINAR / "inputs").as_posix() + "/"
    input_files = [name for name in manifest if name.startswith(inputs_prefix) and name.endswith(".pt")]
    groups = [("data_inputs.zip", ["test", "full"], input_files)]
    runs = sorted((PACKAGE / SEMINAR / "runs").glob("*/model.pt"))
    by_arm = {}
    for path in runs:
        arm = path.parent.name.rsplit("_s", 1)[0]
        by_arm.setdefault(arm, []).append(path.relative_to(PACKAGE).as_posix())
    if len(by_arm) != 9 or any(len(values) != 5 for values in by_arm.values()):
        raise ValueError("Expected nine arms and five checkpoints per arm")
    for arm, values in sorted(by_arm.items()):
        groups.append((f"models_{arm}.zip", ["test", "full"] if arm == "train_full" else ["full"], values))
    raw = [name for name in manifest if name.startswith((JAVA / "graph/dumps_v2").as_posix() + "/")
           or name.startswith((JAVA / "megavul").as_posix() + "/") and name.endswith(".parquet")]
    groups.append(("raw_sources.zip", ["raw", "full"], raw))
    assets = []
    for name, profiles, paths in groups:
        target = create_zip(name, paths)
        assets.append({"name": name, "size": target.stat().st_size, "sha256": digest(target),
                       "profiles": profiles, "members": [manifest[path] for path in sorted(paths)]})
    document = {"schema_version": 1, "repository": "lamvip24042002/luan-van-vdmaf-java",
                "tag": "v1.0-evaluation", "assets": assets,
                "note": "Archive member paths are relative to package root. The core source ZIP checksum is in SHA256SUMS.txt."}
    write_json(PACKAGE / "ASSETS.json", document)
    write_json(RELEASE / "ASSETS.json", document)
    return document


def refresh_assets(manifest):
    document = json.loads((PACKAGE / "ASSETS.json").read_text(encoding="utf-8"))
    for asset in document["assets"]:
        target = RELEASE / asset["name"]
        if not target.is_file() or target.stat().st_size != asset["size"]:
            raise ValueError(f"Missing/changed archive {asset['name']}; rebuild package normally")
        for item in asset["members"]:
            if manifest.get(item["path"]) != item:
                raise ValueError(f"Large-asset member changed: {item['path']}; rebuild package normally")
    write_json(RELEASE / "ASSETS.json", document)
    return document


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--refresh", action="store_true", help="Refresh manifest/core only; retain data archives")
    args = cli.parse_args()
    RELEASE.mkdir(parents=True, exist_ok=True)
    if not args.refresh:
        curate()
    print("Hashing curated package files...", flush=True)
    manifest = make_manifest()
    assets = refresh_assets(manifest) if args.refresh else make_assets(manifest)
    large_paths = {item["path"] for asset in assets["assets"] for item in asset["members"]}
    core_paths = sorted(set(manifest) - large_paths) + ["MANIFEST.json", "ASSETS.json"]
    core = create_zip("source_and_results.zip", core_paths)
    checksums = [(asset["sha256"], asset["name"]) for asset in assets["assets"]]
    checksums.extend([(digest(core), core.name), (digest(RELEASE / "ASSETS.json"), "ASSETS.json")])
    (RELEASE / "SHA256SUMS.txt").write_text("".join(f"{checksum}  {name}\n" for checksum, name in sorted(checksums, key=lambda item: item[1])), encoding="utf-8")
    print(json.dumps({"package": str(PACKAGE), "release_assets": str(RELEASE),
                      "files": len(manifest), "bytes": sum(item["size"] for item in manifest.values()),
                      "archives": len(assets["assets"]) + 1}, indent=2), flush=True)


if __name__ == "__main__":
    main()
