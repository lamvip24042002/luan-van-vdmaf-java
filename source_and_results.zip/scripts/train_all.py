"""Retrain the nine thesis configurations in a fresh, portable experiment folder.

The archived trainer and archived results are never changed. This is a new
training experiment; results can differ across hardware and optimization runs.
Download the prepared inputs first with scripts/prepare_data.py --profile test.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from evaluate import EXPERIMENT, Package, ROOT, read_json, require, sha256


def write_json(path, document):
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(document, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def validate_inputs(inputs, archived, package):
    result = {}
    package_inputs = (ROOT / EXPERIMENT / "inputs").resolve()
    for scope in ("all", "train"):
        directory = inputs / scope
        manifest_path = directory / "manifest.json"
        manifest = read_json(manifest_path)
        require(manifest["vocab_scope"] == scope and all(manifest["invariants"].values()),
                f"Invalid {scope} input manifest")
        required = {"vocab_joint.json", "vocab.json", "stats.json"} | {
            filename for split in ("train", "validation", "test")
            for filename in (f"{split}.pt", f"seq_{split}.pt")}
        require(required <= set(manifest["artifacts"]), f"{scope}: missing required artifacts")
        for filename, metadata in manifest["artifacts"].items():
            require(Path(filename).name == filename and "/" not in filename
                    and "\\" not in filename and ":" not in filename and filename not in (".", ".."),
                    f"Unsafe input artifact filename: {filename!r}")
            path = directory / filename
            require(path.is_file() and sha256(path) == metadata["sha256"]
                    and ("bytes" not in metadata or path.stat().st_size == metadata["bytes"]),
                    f"Input artifact SHA256/size mismatch: {path}")
            if inputs == package_inputs:
                package.check(f"{EXPERIMENT}/inputs/{scope}/{filename}")
        digest = sha256(manifest_path)
        if inputs == package_inputs:
            package.check(f"{EXPERIMENT}/inputs/{scope}/manifest.json")
            require(digest == archived["input_manifests"][scope], f"{scope}: archived manifest changed")
        result[scope] = digest
    return result


def main(argv=None):
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--inputs", type=Path, default=ROOT / EXPERIMENT / "inputs")
    cli.add_argument("--out", type=Path, default=ROOT / "evaluation_outputs" / "retrained")
    cli.add_argument("--device", choices=("cpu", "cuda", "auto"), default="cuda")
    cli.add_argument("--seeds", type=int, nargs="+", default=list(range(42, 47)))
    cli.add_argument("--threads", type=int, default=4)
    cli.add_argument("--plan-only", action="store_true", help="Verify inputs and print the plan without creating output")
    args = cli.parse_args(argv)
    require(args.threads > 0 and len(args.seeds) == len(set(args.seeds))
            and all(0 <= seed < 2**32 for seed in args.seeds), "Threads/seeds must be valid; duplicate seeds are forbidden")
    args.out, args.inputs = args.out.resolve(), args.inputs.resolve()
    require(args.out != ROOT and args.out not in ROOT.parents
            and not args.out.is_relative_to(ROOT / "output")
            and not args.out.is_relative_to(args.inputs) and not args.inputs.is_relative_to(args.out),
            "Output must be separate from archived outputs and inputs; use evaluation_outputs/retrained")
    require(not args.out.exists() or (args.out.is_dir() and not any(args.out.iterdir())),
            f"Output must be new or empty; existing experiments are never overwritten: {args.out}")
    package = Package(ROOT)
    trainer = package.check("scripts/train_seminar_20261011.py")
    archived = package.json(f"{EXPERIMENT}/protocol.json")["specification"]
    require(sha256(trainer) == archived["trainer_sha256"], "Trainer differs from archived protocol")
    manifests = validate_inputs(args.inputs, archived, package)
    specification = dict(archived)
    specification.update(seeds=args.seeds, planned_runs=len(archived["arms"]) * len(args.seeds),
                         input_manifests=manifests, cpu_threads=args.threads,
                         inputs_directory=str(args.inputs), outputs_directory=str(args.out),
                         requested_device=args.device,
                         purpose="Independent retraining; archived thesis evidence remains unchanged")
    if args.plan_only:
        print(json.dumps(specification, indent=2, ensure_ascii=False))
        return 0
    args.out.mkdir(parents=True, exist_ok=True)
    logs = args.out / "launcher_logs"
    logs.mkdir()
    write_json(args.out / "protocol.json", {"created_utc_before_training": datetime.now(timezone.utc).isoformat(),
                                            "specification": specification})
    completed, started = [], time.perf_counter()
    for seed in args.seeds:
        for arm, scope, channels, fusion, edges in archived["arms"]:
            name = f"{arm}_s{seed}"
            destination = args.out / "runs" / name
            require(sha256(trainer) == specification["trainer_sha256"], "Trainer changed during experiment")
            require(sha256(args.inputs / scope / "manifest.json") == manifests[scope],
                    f"Input manifest changed before {name}")
            command = [sys.executable, "-u", str(trainer), "--data", str(args.inputs / scope),
                       "--out", str(destination), "--channels", channels, "--fusion", fusion,
                       "--edges", edges, "--seed", str(seed), "--device", args.device]
            for key, value in archived["hyperparameters"].items():
                if key != "weight_decay":
                    command.extend([f"--{key}", str(value)])
            env = dict(os.environ, PYTHONHASHSEED=str(seed), PYTHONIOENCODING="utf-8",
                       PYTHONUNBUFFERED="1", OMP_NUM_THREADS=str(args.threads), MKL_NUM_THREADS=str(args.threads))
            status = {"status": "running", "current": name, "completed": completed,
                      "planned": specification["planned_runs"], "command": command}
            write_json(args.out / "status.json", status)
            print(f"START {name} ({len(completed) + 1}/{specification['planned_runs']})", flush=True)
            with (logs / f"{name}.log").open("w", encoding="utf-8") as log:
                child = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT,
                                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            if child.returncode or not (destination / "metrics.json").is_file():
                status.update(status="failed", exit_code=child.returncode)
                write_json(args.out / "status.json", status)
                raise RuntimeError(f"Training failed: {name}. Inspect {logs / (name + '.log')}")
            metrics = read_json(destination / "metrics.json")
            completed.append(name)
            print(f"FINISH {name}: test AP={metrics['test']['ap']:.9f}", flush=True)
    write_json(args.out / "status.json", {"status": "completed", "completed": completed,
                                          "planned": specification["planned_runs"],
                                          "elapsed_seconds": time.perf_counter() - started})
    print(f"Completed {len(completed)} new training runs in {args.out}", flush=True)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError, RuntimeError) as error:
        raise SystemExit(f"Training launcher failed: {error}")
