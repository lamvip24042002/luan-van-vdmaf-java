# Before/after PCFinder-features experiment: 4 configs x 5 seeds on dataset_v2.
# Only difference within each pair is --pcf (the 4 node flags). Resumable.
$conda = "C:\Users\ADMIN\miniconda3\condabin\conda.bat"
Set-Location "C:\Users\ADMIN\Desktop\ts\VDMAF_main\newidea\Java\gnn"
foreach ($seed in 42, 43, 44, 45, 46) {
    Write-Output "=== PCF SEED $seed START  $(Get-Date -Format HH:mm:ss) ==="
    $runs = @(
        @("pcf_both_off", "both", ""),
        @("pcf_both_on",  "both", "--pcf"),
        @("pcf_gnn_off",  "gnn",  ""),
        @("pcf_gnn_on",   "gnn",  "--pcf")
    )
    foreach ($r in $runs) {
        $name, $ch, $flag = $r
        $dir = "runs/${name}_s$seed"
        if (Test-Path "$dir/metrics.json") { continue }
        if ($flag -eq "--pcf") {
            & $conda run -n vdmaf-gnn python -u train_v1.py --ds dataset_v2 --channels $ch --edges all --epochs 25 --patience 5 --seed $seed --out $dir --pcf
        } else {
            & $conda run -n vdmaf-gnn python -u train_v1.py --ds dataset_v2 --channels $ch --edges all --epochs 25 --patience 5 --seed $seed --out $dir
        }
    }
    Write-Output "=== PCF SEED $seed GROUP DONE  $(Get-Date -Format HH:mm:ss) ==="
}
Write-Output "=== PCF EXPERIMENT ALL DONE  $(Get-Date -Format HH:mm:ss) ==="
