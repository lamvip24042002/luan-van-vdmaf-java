# -*- coding: utf-8 -*-
# Build the node2vec-style graph embedding model from the Joern graph dumps.
#
# Per method: collapse CPG nodes by token (one graph node per unique token),
# connect tokens by the dumped AST/CFG/CDG/REACHING_DEF edges (undirected),
# run uniform random walks, then train skip-gram word2vec on the walks with
# the same hyperparameters as the authors' artifact
# (sg=1, window=10, min_count=5, vector_size=300, epochs=5).
#
# Usage: python build_node2vec.py <dump_glob> <out_model>
#   e.g.  python build_node2vec.py "graph_batch_*.txt" ../code/node2vec_model-300.model
import glob
import random
import sys
from gensim.models import Word2Vec

WALKS_PER_NODE = 2
WALK_LENGTH = 20

dump_glob = sys.argv[1] if len(sys.argv) > 1 else "graph_batch_*.txt"
out_model = sys.argv[2] if len(sys.argv) > 2 else "node2vec_model-300.model"

random.seed(42)
walks_path = "walks.txt"
n_methods = 0
n_tokens_total = 0

with open(walks_path, "w", encoding="utf-8") as wout:
    for path in sorted(glob.glob(dump_glob)):
        print("processing", path)
        id2tok = {}
        adj = {}

        def flush():
            global n_methods, n_tokens_total
            if adj:
                n_methods += 1
                nodes = list(adj.keys())
                n_tokens_total += len(nodes)
                for start in nodes:
                    for _ in range(WALKS_PER_NODE):
                        walk = [start]
                        cur = start
                        for _ in range(WALK_LENGTH - 1):
                            nbrs = adj.get(cur)
                            if not nbrs:
                                break
                            cur = random.choice(nbrs)
                            walk.append(cur)
                        if len(walk) > 1:
                            wout.write(" ".join(walk) + "\n")
            id2tok.clear()
            adj.clear()

        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                parts = line.rstrip("\n").split("\t")
                if parts[0] == "#M":
                    flush()
                elif parts[0] == "N":
                    id2tok[parts[1]] = parts[2]
                elif parts[0] == "E":
                    a = id2tok.get(parts[1])
                    b = id2tok.get(parts[2])
                    if a is None or b is None or a == b:
                        continue
                    adj.setdefault(a, []).append(b)
                    adj.setdefault(b, []).append(a)
        flush()

print("methods:", n_methods, "| avg unique tokens/method:",
      (n_tokens_total / max(n_methods, 1)))

print("training word2vec on walks...")
model = Word2Vec(corpus_file=walks_path, sg=1, window=10, min_count=5,
                 vector_size=300, epochs=5, workers=6)
print("vocab:", len(model.wv.key_to_index))
model.save(out_model)
print("saved ->", out_model)
