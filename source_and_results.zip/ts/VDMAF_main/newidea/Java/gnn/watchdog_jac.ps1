# RAM guard for multi-seed runs; exits on JAC EXPERIMENT ALL DONE or after 6 h.
$log = "C:\Users\ADMIN\Desktop\ts\VDMAF_main\newidea\Java\gnn\watchdog_jac.log"
$driverlog = "C:\Users\ADMIN\Desktop\ts\VDMAF_main\newidea\Java\gnn\run_jac_experiment.log"
$deadline = (Get-Date).AddHours(6)
Add-Content $log "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') multiseed watchdog started"
while ((Get-Date) -lt $deadline) {
    $os = Get-CimInstance Win32_OperatingSystem
    $freeGB = [math]::Round($os.FreePhysicalMemory/1MB, 1)
    $pys = Get-Process python* -ErrorAction SilentlyContinue
    $pyGB = 0
    if ($pys) { $pyGB = [math]::Round((($pys | Measure-Object WorkingSet64 -Sum).Sum)/1GB, 1) }
    Add-Content $log "$(Get-Date -Format HH:mm:ss) free=${freeGB}GB python=${pyGB}GB"
    if ($freeGB -lt 3) {
        Add-Content $log "$(Get-Date -Format HH:mm:ss) LIMIT HIT (free=${freeGB}GB) -> killing python"
        if ($pys) { $pys | Stop-Process -Force }
    }
    if (Select-String -Path $driverlog -Pattern "JAC EXPERIMENT ALL DONE" -Quiet -ErrorAction SilentlyContinue) {
        Add-Content $log "$(Get-Date -Format HH:mm:ss) multiseed finished -> watchdog exits"
        break
    }
    Start-Sleep -Seconds 30
}
