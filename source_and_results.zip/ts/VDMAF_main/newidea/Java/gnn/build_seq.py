# -*- coding: utf-8 -*-
# Semantic-channel input: tokenize every MegaVul-Java function (regex tokenizer
# in the spirit of VDMAF's language-agnostic getTokens) -> id sequences over a
# JOINT vocabulary (graph vocab.json extended with frequent sequence tokens, so
# both channels share one embedding table).
# Output: vocab_joint.json, seq_train.pt / seq_validation.pt / seq_test.pt
# (dict fid -> LongTensor, 'pre'-truncated to MAXLEN like VDMAF pad_sequences).
import json
import os
import re
from collections import Counter

import pandas as pd
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
MEGA = os.path.abspath(os.path.join(HERE, "..", "megavul"))
OUT = os.path.join(HERE, "dataset")
MAXLEN = 200
MIN_COUNT = 5

TOKEN_RE = re.compile(
    r'[A-Za-z_$][A-Za-z0-9_$]*'            # identifiers/keywords
    r'|\d+\.?\d*[fFdDlL]?'                 # numbers
    r'|"(?:\\.|[^"\\])*"'                  # string literals
    r"|'(?:\\.|[^'\\])*'"                  # char literals
    r'|==|!=|<=|>=|&&|\|\||\+\+|--|<<=|>>=|<<|>>>|>>'
    r'|\+=|-=|\*=|/=|%=|&=|\|=|\^=|->|::'
    r'|[{}()\[\];,.<>+\-*/%=!&|^~?:@]')


def tokenize(code):
    return TOKEN_RE.findall(code)


splits = {
    "train": "train-00000-of-00001.parquet",
    "validation": "validation-00000-of-00001.parquet",
    "test": "test-00000-of-00001.parquet",
}
frames = []
for name, fn in splits.items():
    df = pd.read_parquet(os.path.join(MEGA, fn))
    df["split"] = name
    frames.append(df)
df = pd.concat(frames, ignore_index=True)
print("functions:", len(df))

# pass 1: frequencies
cnt = Counter()
tok_cache = []
for code in df["input"]:
    toks = tokenize(code)
    tok_cache.append(toks)
    cnt.update(toks)

with open(os.path.join(OUT, "vocab.json"), encoding="utf-8") as f:
    vocab = json.load(f)
base = len(vocab)
for tok, c in cnt.most_common():
    if c >= MIN_COUNT and tok not in vocab:
        vocab[tok] = len(vocab)
with open(os.path.join(OUT, "vocab_joint.json"), "w", encoding="utf-8") as f:
    json.dump(vocab, f)
total = sum(cnt.values())
unk = sum(c for t, c in cnt.items() if t not in vocab)
print("joint vocab: %d (graph %d + %d new) | seq UNK rate %.2f%%"
      % (len(vocab), base, len(vocab) - base, 100.0 * unk / total))

# pass 2: id sequences, 'pre' truncation (keep last MAXLEN, VDMAF-compatible)
seqs = {"train": {}, "validation": {}, "test": {}}
lens = []
for gid, toks in enumerate(tok_cache):
    fid = "F%06d" % gid
    ids = [vocab.get(t, 1) for t in toks][-MAXLEN:]
    if not ids:
        ids = [1]
    lens.append(len(ids))
    seqs[df.at[gid, "split"]][fid] = torch.tensor(ids, dtype=torch.long)

for split, d in seqs.items():
    torch.save(d, os.path.join(OUT, "seq_%s.pt" % split))
    print("seq_%s.pt: %d" % (split, len(d)))
lens.sort()
print("seq len p50/p90/max: %d/%d/%d | truncated: %d"
      % (lens[len(lens) // 2], lens[int(len(lens) * 0.9)], lens[-1],
         sum(1 for t in tok_cache if len(t) > MAXLEN)))
