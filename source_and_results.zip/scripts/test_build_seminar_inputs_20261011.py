"""Small adversarial tests for the seminar vocabulary intervention."""
import tempfile
from pathlib import Path
import unittest

import pandas as pd
import torch

import build_seminar_inputs_20261011 as builder


class ControlledInputsTest(unittest.TestCase):
    def test_vocab_scope_cap_and_graph_before_joint_policy(self):
        dump = (
            "#M\tm\tC:\\src\\F000000.java\n"
            "N\t1\tcommon\tIDENTIFIER\nN\t2\tcommon\tIDENTIFIER\n"
            "N\t3\tseqOnly\tIDENTIFIER\nN\t4\toverflow\tIDENTIFIER\n"
            "E\t1\t2\tAST\nE\t2\t3\tCFG\nE\t3\t4\tAST\n"
            "#M\tlambda\tC:\\src\\F000000.java\n"
            "N\t5\toverflow\tIDENTIFIER\n"
            "#M\t<init>\tC:\\src\\F000000.java\n"
            "N\t6\tignored\tIDENTIFIER\nN\t7\tignored\tIDENTIFIER\n"
            "#M\tm\tC:\\src\\F000001.java\n"
            "N\t8\theldout\tIDENTIFIER\nN\t9\theldout\tIDENTIFIER\nE\t8\t9\tAST\n"
            "#M\tm\tC:\\src\\F000002.java\n"
            "N\t10\theldout\tIDENTIFIER\nN\t11\tcommon\tIDENTIFIER\nE\t10\t11\tAST\n"
        )
        labels = {"F000000": ("train", 0), "F000001": ("validation", 0), "F000002": ("test", 1)}
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "graph_batch_0.txt"
            path.write_text(dump, encoding="utf-8")
            counters = builder.count_graph_tokens([path], labels)
            graph_vocabs = {scope: builder.make_vocab(counter, min_count=2) for scope, counter in counters.items()}
            self.assertIn("heldout", graph_vocabs["all"])
            self.assertNotIn("heldout", graph_vocabs["train"])
            self.assertIn("overflow", graph_vocabs["train"], "Counts must precede node cap")
            self.assertNotIn("ignored", graph_vocabs["all"])
            all_graphs, skipped = builder.encode_graphs([path], labels, graph_vocabs["all"], max_nodes=3)
            self.assertFalse(any(skipped.values()))
            self.assertEqual(all_graphs["train"][0]["x"].numel(), 3)
            self.assertEqual(all_graphs["train"][0]["edge_index"].shape[1], 2)
            graphs = {"all": all_graphs, "train": builder.remap_graphs(all_graphs, graph_vocabs["all"], graph_vocabs["train"])}
            direct_train, direct_skipped = builder.encode_graphs([path], labels, graph_vocabs["train"], max_nodes=3)
            self.assertEqual(skipped, direct_skipped)
            for split in builder.SPLITS:
                for remapped, direct in zip(graphs["train"][split], direct_train[split]):
                    self.assertTrue(torch.equal(remapped["x"], direct["x"]))
                    self.assertTrue(torch.equal(remapped["edge_index"], direct["edge_index"]))
                    self.assertTrue(torch.equal(remapped["edge_type"], direct["edge_type"]))
        frame = pd.DataFrame([
            {"fid": "F000000", "split": "train", "input": "seqOnly seqOnly common", "is_vulnerable": 0},
            {"fid": "F000001", "split": "validation", "input": "heldout common", "is_vulnerable": 0},
            {"fid": "F000002", "split": "test", "input": "heldout common", "is_vulnerable": 1},
        ])
        counters = builder.count_sequence_tokens(frame)
        joint = {scope: builder.extend_vocab(graph_vocabs[scope], counters[scope], min_count=2) for scope in graph_vocabs}
        self.assertIn("seqOnly", joint["train"])
        self.assertNotIn("heldout", joint["train"])
        self.assertEqual(int(graphs["train"]["train"][0]["x"][2]), 1,
                         "Graph-only UNK must not be retroactively upgraded from joint sequence vocab")
        seqs, _ = builder.make_sequence_items(frame, joint, maxlen=2)
        self.assertEqual(seqs["train"]["train"]["F000000"].tolist(), [joint["train"]["seqOnly"], joint["train"]["common"]])
        builder.assert_scope_invariants(graphs, seqs, joint, graph_vocabs)
        stats = builder.unknown_stats([torch.tensor([1, 2, 1]), torch.tensor([2])])
        self.assertEqual(stats["unk_token_rate"], 0.5)
        self.assertEqual(stats["sample_with_unk_rate"], 0.5)

    def test_duplicates_use_exact_strings_and_train_or_validation_union(self):
        rows = [
            ("F0", "train", "a b", 0), ("F1", "train", "a b", 1),
            ("F2", "validation", "other", 0),
            ("F3", "test", "a b", 1), ("F4", "test", "ab", 0),
            ("F5", "test", "other", 0), ("F6", "test", "new", 1),
        ]
        frame = pd.DataFrame(rows, columns=["fid", "split", "input", "is_vulnerable"])
        audit, fids = builder.duplicate_audit(frame)
        self.assertEqual(fids, ["F4", "F6"], "Whitespace differences must remain distinct")
        self.assertEqual(audit["pairs"]["train__test"]["train_rows"], 2)
        self.assertEqual(audit["test_excluding_exact_train_or_validation"]["excluded_positive"], 1)


if __name__ == "__main__":
    unittest.main()
