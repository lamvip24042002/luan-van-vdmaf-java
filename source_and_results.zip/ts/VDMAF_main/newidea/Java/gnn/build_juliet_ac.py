# -*- coding: utf-8 -*-
# Build a standalone Juliet access-control dataset (CWE-566 auth-bypass +
# CWE-601 open-redirect) for a controlled before/after PCFinder experiment.
# Unit = one dumped method. Label by Juliet naming: name contains 'bad' -> 1,
# 'good' -> 0; skip <init>/<clinit>/main/helpers. Reuses v1 vocab.json and the
# same 4 PCFinder flags as dataset_v2. Produces dataset_juliet_ac/{train,
# validation,test}.pt + seq_*.pt (seq = method token stream in node order).
import json
import os
import random
from collections import deque

import torch

HERE = os.path.dirname(os.path.abspath(__file__))
DUMP = os.path.join(HERE, "..", "juliet_ac", "graph_juliet_ac.txt")
OUT = os.path.join(HERE, "dataset_juliet_ac")
os.makedirs(OUT, exist_ok=True)
random.seed(42)

MAX_NODES = 2000
MAXLEN = 200
EDGE_TYPES = {"AST": 0, "CFG": 1, "CDG": 2, "REACHING_DEF": 3}
CRED_ROOTS = ["role", "pass", "permiss", "auth", "token", "admin", "user",
              "member", "login", "owner", "priv", "right", "secret",
              "session", "account", "credential", "key", "id"]
PRIV_OPS = {"executeQuery", "executeUpdate", "executeBatch", "execute",
            "prepareStatement", "createStatement", "query", "insert", "update",
            "delete", "write", "read", "openConnection", "openStream", "connect",
            "getOutputStream"}
REDIRECT_OPS = {"sendRedirect", "redirect", "forward", "sendError"}

with open(os.path.join(HERE, "dataset", "vocab.json"), encoding="utf-8") as f:
    vocab = json.load(f)


def label_of(name):
    ln = name.lower()
    if name in ("<init>", "<clinit>", "main", "action") or "private" in ln:
        return None
    if "good" in ln:
        return 0
    if "bad" in ln:
        return 1
    return None


def flags(tok, kind):
    low = tok.lower()
    f0 = 1.0 if any(r in low for r in CRED_ROOTS) else 0.0
    f1 = 1.0 if (kind == "CALL" and tok in PRIV_OPS) else 0.0
    f2 = 1.0 if ((kind == "CONTROL_STRUCTURE" and tok == "throw")
                 or kind == "RETURN"
                 or (kind == "CALL" and tok in REDIRECT_OPS)) else 0.0
    return [f0, f1, f2]


def iter_methods():
    with open(DUMP, encoding="utf-8") as f:
        name, nodes, edges = None, {}, []
        for line in f:
            if line.startswith("#M"):
                if name is not None:
                    yield name, nodes, edges
                name, nodes, edges = line.rstrip("\n").split("\t")[1], {}, []
            elif line.startswith("N"):
                p = line.rstrip("\n").split("\t")
                nodes[p[1]] = (p[2], p[3] if len(p) > 3 else "")
            elif line.startswith("E"):
                p = line.rstrip("\n").split("\t")
                edges.append((p[1], p[2], p[3]))
        if name is not None:
            yield name, nodes, edges


items = []
idx = 0
for name, nodes, edges in iter_methods():
    y = label_of(name)
    if y is None or len(nodes) == 0 or len(edges) == 0:
        continue
    id2idx, toks, flg, kinds = {}, [], [], []
    for nid, (tok, kind) in nodes.items():
        if nid not in id2idx and len(toks) < MAX_NODES:
            id2idx[nid] = len(toks)
            toks.append(vocab.get(tok, 1))
            flg.append(flags(tok, kind))
            kinds.append(kind)
    ei = []
    for s, d, t in edges:
        si, di = id2idx.get(s), id2idx.get(d)
        if si is not None and di is not None:
            ei.append((si, di, EDGE_TYPES[t]))
    if not ei:
        continue
    n = len(toks)
    # flag 3: BFS from METHOD_PARAMETER_IN over directed REACHING_DEF
    adj = {}
    for si, di, t in ei:
        if t == 3:
            adj.setdefault(si, []).append(di)
    seen = set(i for i, k in enumerate(kinds) if k == "METHOD_PARAMETER_IN")
    dq = deque(seen)
    while dq:
        u = dq.popleft()
        for v in adj.get(u, ()):
            if v not in seen:
                seen.add(v)
                dq.append(v)
    x_flags = [flg[i] + [1.0 if i in seen else 0.0] for i in range(n)]
    e = torch.tensor(ei, dtype=torch.long)
    fid = "J%06d" % idx
    idx += 1
    items.append({
        "fid": fid,
        "x": torch.tensor(toks, dtype=torch.long),
        "x_flags": torch.tensor(x_flags, dtype=torch.float),
        "edge_index": e[:, :2].t().contiguous(),
        "edge_type": e[:, 2].contiguous(),
        "y": y,
        "seq": torch.tensor(toks[:MAXLEN] if toks else [1], dtype=torch.long),
    })

random.shuffle(items)
n = len(items)
c1, c2 = int(0.7 * n), int(0.85 * n)
splits = {"train": items[:c1], "validation": items[c1:c2], "test": items[c2:]}
for split, lst in splits.items():
    graphs = [{k: it[k] for k in ("fid", "x", "x_flags", "edge_index", "edge_type", "y")} for it in lst]
    seqs = {it["fid"]: it["seq"] for it in lst}
    torch.save(graphs, os.path.join(OUT, split + ".pt"))
    torch.save(seqs, os.path.join(OUT, "seq_%s.pt" % split))
    nv = sum(it["y"] for it in lst)
    print("%-11s n=%4d  vul=%4d (%.1f%%)" % (split, len(lst), nv, 100.0 * nv / max(len(lst), 1)))
print("total labeled methods:", n, "-> saved", OUT)
