"""Verify and aggregate only the prespecified 45 seminar experiment runs.

Default behavior rejects incomplete experiments. --allow-partial writes a
separately named exploratory directory, never the final analysis directory.
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import statistics
import tempfile

import numpy as np
from sklearn.metrics import (average_precision_score, f1_score,
                             matthews_corrcoef, precision_score,
                             recall_score, roc_auc_score)


ARMS = [
    ("all_full", "all", "both", "attention", "all"),
    ("train_full", "train", "both", "attention", "all"),
    ("train_seq", "train", "seq", "attention", "all"),
    ("train_gnn", "train", "gnn", "attention", "all"),
    ("train_concat", "train", "both", "concat", "all"),
    ("train_cdg_ddg", "train", "both", "attention", "cdg_ddg"),
    ("train_untyped", "train", "both", "attention", "untyped"),
    ("train_no_cdg", "train", "both", "attention", "no_cdg"),
    ("train_no_ddg", "train", "both", "attention", "no_ddg"),
]
SEEDS = list(range(42, 47))
METRICS = ("ap", "roc_auc", "f1@val_t", "p@val_t", "r@val_t", "mcc@val_t")
REQUIRED_INPUTS = ["vocab_joint.json"] + [name for split in ("train", "validation", "test")
                   for name in (f"{split}.pt", f"seq_{split}.pt")]
LIMITATIONS = [
    "Mean và SD mẫu qua seed mô tả biến thiên do tối ưu hóa trên cùng phép chia dữ liệu; không phải bất định tổng quát hóa sang dữ liệu mới.",
    "Kiểm định dấu hai phía trên chênh lệch AP theo seed chỉ là thống kê mô tả bổ sung, n tối đa 5; tất cả 5 cùng dấu vẫn có p=0,0625. Không hiệu chỉnh đa so sánh và không dùng để tuyên bố ý nghĩa thống kê.",
    "Tập test loại trùng nguyên văn là phân tích độ nhạy sau huấn luyện, giữ checkpoint và ngưỡng validation gốc; không phải phép chia mới đã khử rò rỉ, tách dự án hoặc tách thời gian.",
    "Concat và untyped thay đổi số tham số; đây là ablation thiết kế, chưa phải đối chứng cân bằng số tham số.",
    "Train-only vocabulary không loại bỏ mọi trùng lặp hoặc quan hệ giữa dự án trong phép chia gốc.",
    "Tất cả kết quả trong báo cáo được đọc từ protocol seminar hiện tại; không gộp checkpoint hoặc chỉ số lịch sử.",
]


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def equal_number(actual, expected, context):
    require(np.isfinite(actual) and np.isclose(actual, expected, rtol=1e-8, atol=1e-10),
            f"{context}: {actual!r} != {expected!r}")


def metrics(labels, probabilities, threshold):
    require(set(labels.tolist()) == {0, 1}, "Both classes required for evaluation")
    prediction = (probabilities > threshold).astype(np.int64)
    return {
        "ap": float(average_precision_score(labels, probabilities)),
        "roc_auc": float(roc_auc_score(labels, probabilities)),
        "f1@val_t": float(f1_score(labels, prediction, zero_division=0)),
        "p@val_t": float(precision_score(labels, prediction, zero_division=0)),
        "r@val_t": float(recall_score(labels, prediction, zero_division=0)),
        "mcc@val_t": float(matthews_corrcoef(labels, prediction)),
        "f1@0.5": float(f1_score(labels, probabilities > 0.5, zero_division=0)),
        "mcc@0.5": float(matthews_corrcoef(labels, probabilities > 0.5)),
        "n": int(len(labels)), "positive": int(labels.sum()),
        "prevalence": float(labels.mean()), "val_t": float(threshold),
    }


def validation_threshold(labels, probabilities):
    best_f1, threshold = 0.0, 0.5
    for value in np.linspace(0.05, 0.95, 19):
        candidate = f1_score(labels, probabilities > value, zero_division=0)
        if candidate > best_f1:
            best_f1, threshold = float(candidate), float(value)
    return threshold


def read_predictions(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    require(bool(rows), f"Empty predictions: {path}")
    required = {"fid", "y", "prob", "pred_0.5", "pred_val_t", "val_t"}
    require(required <= rows[0].keys(), f"Missing prediction columns: {path}")
    fids = [row["fid"] for row in rows]
    require(len(fids) == len(set(fids)), f"Duplicated fid in {path}")
    labels = np.asarray([int(row["y"]) for row in rows], dtype=np.int64)
    # Trainer sigmoid outputs are float32. Preserve that dtype: under NumPy's
    # scalar-promotion rules float64 would change strict > decisions near .4/.9.
    probabilities = np.asarray([float(row["prob"]) for row in rows], dtype=np.float32)
    thresholds = np.asarray([float(row["val_t"]) for row in rows], dtype=np.float64)
    require(np.isfinite(probabilities).all() and ((0 <= probabilities) & (probabilities <= 1)).all(),
            f"Invalid probabilities: {path}")
    require(np.isfinite(thresholds).all() and np.all(thresholds == thresholds[0]),
            f"Nonconstant or invalid validation threshold: {path}")
    require(set(labels.tolist()) == {0, 1}, f"Invalid/one-class labels: {path}")
    threshold = float(thresholds[0])
    require(np.array_equal(probabilities > 0.5, [int(row["pred_0.5"]) for row in rows]),
            f"Invalid saved predictions at 0.5: {path}")
    require(np.array_equal(probabilities > threshold, [int(row["pred_val_t"]) for row in rows]),
            f"Invalid saved predictions at validation threshold: {path}")
    fingerprint = hashlib.sha256(json.dumps(list(zip(fids, labels.tolist())), ensure_ascii=False,
                                             separators=(",", ":")).encode("utf-8")).hexdigest()
    return fids, labels, probabilities, threshold, fingerprint


def descriptive(values, seeds=None):
    values = [float(value) for value in values]
    result = {"n": len(values), "mean": statistics.mean(values) if values else None,
              "sample_sd": statistics.stdev(values) if len(values) >= 2 else None,
              "min": min(values) if values else None, "max": max(values) if values else None}
    if seeds is not None:
        result["values_by_seed"] = {str(seed): value for seed, value in zip(seeds, values)}
    return result


def exact_sign_test(differences):
    positive = sum(value > 0 for value in differences)
    negative = sum(value < 0 for value in differences)
    n = positive + negative
    lower = min(positive, negative)
    probability = min(1.0, 2 * sum(math.comb(n, count) for count in range(lower + 1)) / 2 ** n) if n else 1.0
    return {"two_sided_p": probability, "positive": positive, "negative": negative,
            "zero_ties": len(differences) - n, "n_nonzero": n,
            "scope": "optimization variability conditional on one fixed test set; descriptive; unadjusted for multiple comparisons"}


def group_summary(records, section):
    result = {}
    for arm, scope, *_ in ARMS:
        rows = sorted((row for row in records if row["arm"] == arm), key=lambda row: row["seed"])
        seeds = [row["seed"] for row in rows]
        result[arm] = {"scope": scope, "seeds": seeds,
                       "metrics": {metric: descriptive([row[section][metric] for row in rows], seeds)
                                   for metric in METRICS},
                       "parameter_count": descriptive([row["parameter_count"] for row in rows], seeds),
                       "total_seconds": descriptive([row["timing"]["total_seconds"] for row in rows], seeds),
                       "training_with_validation_seconds": descriptive(
                           [row["timing"]["training_with_validation_seconds"] for row in rows], seeds)}
        if rows:
            result[arm].update({key: rows[0][section][key] for key in ("n", "positive", "prevalence")})
    return result


def paired_comparisons(records):
    indexed = {(row["arm"], row["seed"]): row for row in records}
    comparisons = []
    for other, *_ in ARMS:
        if other == "train_full":
            continue
        seeds = [seed for seed in SEEDS if ("train_full", seed) in indexed and (other, seed) in indexed]
        for metric in METRICS:
            differences = [indexed[("train_full", seed)]["test"][metric] - indexed[(other, seed)]["test"][metric]
                           for seed in seeds]
            row = {"left": "train_full", "right": other, "metric": metric,
                   "direction": "left_minus_right", "paired_seeds": seeds,
                   **descriptive(differences, seeds)}
            if metric == "ap":
                row["exact_sign_test"] = exact_sign_test(differences)
            comparisons.append(row)
    return comparisons


def verify_inputs(root, experiment, protocol):
    trainer = root / "scripts" / "train_seminar_20261011.py"
    require(sha256(trainer) == protocol["trainer_sha256"], "Current trainer differs from prespecified trainer hash")
    scopes = {}
    for scope in ("all", "train"):
        directory = experiment / "inputs" / scope
        manifest_path = directory / "manifest.json"
        require(sha256(manifest_path) == protocol["input_manifests"][scope], f"Changed {scope} manifest")
        manifest = load_json(manifest_path)
        require(manifest["vocab_scope"] == scope, f"Wrong vocabulary scope: {scope}")
        require(all(manifest["invariants"].values()), f"Failed input invariants: {scope}")
        hashes = {name: sha256(directory / name) for name in REQUIRED_INPUTS}
        for name, digest in hashes.items():
            require(manifest["artifacts"][name]["sha256"] == digest, f"Changed input artifact: {scope}/{name}")
        require(manifest["artifacts"]["stats.json"]["sha256"] == sha256(directory / "stats.json"),
                f"Changed OOV statistics: {scope}")
        scopes[scope] = {"manifest": manifest, "manifest_sha256": sha256(manifest_path),
                         "hashes": hashes, "stats": load_json(directory / "stats.json")}
    return scopes


def analyze(root, experiment, allow_partial=False):
    protocol_path = experiment / "protocol.json"
    protocol_document = load_json(protocol_path)
    protocol = protocol_document["specification"]
    require(protocol["arms"] == [list(arm) for arm in ARMS] and protocol["seeds"] == SEEDS
            and protocol["planned_runs"] == 45, "Protocol is not the prespecified 9 arms x 5 seeds")
    incomplete = []
    completed = []
    for seed in SEEDS:
        for arm in ARMS:
            name = f"{arm[0]}_s{seed}"
            directory = experiment / "runs" / name
            required = ("metrics.json", "run_spec.json", "validation_predictions.csv", "test_predictions.csv", "best_checkpoint.json")
            missing = [filename for filename in required if not (directory / filename).is_file()]
            if missing:
                incomplete.append({"run": name, "reason": "missing files", "files": missing})
                continue
            spec = load_json(directory / "run_spec.json")
            if spec.get("status") != "completed":
                incomplete.append({"run": name, "reason": f"status={spec.get('status')}"})
                continue
            completed.append((seed, arm, directory, spec))
    if incomplete and not allow_partial:
        raise RuntimeError(f"Experiment incomplete: {len(completed)}/45 completed; no analysis written. "
                           "Use --allow-partial only for a separately labelled exploratory analysis.")
    require(bool(completed), "No completed runs available; no analysis written")
    inputs = verify_inputs(root, experiment, protocol)
    sensitivity_path = experiment / "inputs" / "test_exact_disjoint_fids.json"
    sensitivity_fids = load_json(sensitivity_path)
    require(isinstance(sensitivity_fids, list) and len(sensitivity_fids) == len(set(sensitivity_fids)),
            "Invalid exact-disjoint sensitivity fid list")
    sensitivity_set = set(sensitivity_fids)
    duplicate_audit = load_json(experiment / "inputs" / "duplicate_audit.json")
    original_labels = {}
    label_path = root / "ts" / "VDMAF_main" / "newidea" / "Java" / "graph" / "labels_all.tsv"
    expected_label_hashes = {source["sha256"] for scope in inputs.values()
                             for source in scope["manifest"]["sources"]
                             if Path(source["path"]).resolve() == label_path.resolve()}
    require(expected_label_hashes == {sha256(label_path)}, "Original labels differ from builder provenance")
    with label_path.open(encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            original_labels[row["fid"]] = (row["split"], int(row["label"]))
    references, training_inventory, records, provenance = {}, None, [], {}
    reference_environment = None
    for seed, arm_spec, directory, spec in completed:
        arm, scope, channels, fusion, edges = arm_spec
        name = directory.name
        config = spec["config"]
        expected = {"seed": seed, "channels": channels, "fusion": fusion, "edges": edges,
                    "pcf": False, "device": "cuda"}
        expected.update({key: value for key, value in protocol["hyperparameters"].items() if key != "weight_decay"})
        for key, value in expected.items():
            require(config.get(key) == value, f"{name}: config {key} differs from protocol")
        require(Path(config["data"]).resolve() == (experiment / "inputs" / scope).resolve(), f"{name}: wrong data path")
        require(Path(config["out"]).resolve() == directory.resolve(), f"{name}: wrong output path")
        require(spec["script_sha256"] == protocol["trainer_sha256"], f"{name}: trainer hash mismatch")
        require(spec["input_sha256"] == inputs[scope]["hashes"], f"{name}: input hash mismatch")
        require(spec["data_manifests"]["manifest.json"]["sha256"] == inputs[scope]["manifest_sha256"],
                f"{name}: input manifest mismatch")
        require(spec["optimizer"]["weight_decay"] == protocol["hyperparameters"]["weight_decay"],
                f"{name}: optimizer differs")
        require(spec["warm_start"] is None and spec["selection"]["test_threshold_search"] is False,
                f"{name}: unexpected warm start or test selection")
        require(spec["environment"]["device"] == "cuda", f"{name}: did not run on CUDA")
        require(spec["environment"]["torch_num_threads"] == protocol["cpu_threads"], f"{name}: thread setting differs")
        require(spec["environment"]["pythonhashseed"] == str(seed), f"{name}: hash seed differs")
        environment = {key: spec["environment"][key] for key in (
            "python", "torch", "torch_geometric", "numpy", "sklearn", "cuda_runtime", "device", "gpu_name",
            "cudnn_deterministic", "cudnn_benchmark", "deterministic_algorithms", "torch_num_threads")}
        if reference_environment is None:
            reference_environment = environment
        require(environment == reference_environment, f"{name}: runtime/hardware differs across experimental runs")
        if training_inventory is None:
            training_inventory = spec["splits"]["train"]
        require(spec["splits"]["train"] == training_inventory, f"{name}: different training IDs/labels")
        saved = load_json(directory / "metrics.json")
        require(saved["config"] == config and saved["splits"] == spec["splits"], f"{name}: metrics/spec config mismatch")
        require(saved["vocab_sha256"] == inputs[scope]["hashes"]["vocab_joint.json"], f"{name}: metrics vocabulary mismatch")
        require(saved["parameter_count"] == spec["parameter_count"], f"{name}: parameter count mismatch")
        require(saved["epochs_completed"] == spec["epochs_completed"]
                and 1 <= saved["best_epoch"] <= saved["epochs_completed"] <= protocol["hyperparameters"]["epochs"],
                f"{name}: invalid epoch counts")
        checkpoint = load_json(directory / "best_checkpoint.json")
        require(checkpoint["epoch"] == saved["best_epoch"] == spec["best_epoch"], f"{name}: selected epoch mismatch")
        require(checkpoint["vocab_sha256"] == saved["vocab_sha256"], f"{name}: checkpoint vocabulary mismatch")
        row = {"run": name, "arm": arm, "scope": scope, "seed": seed,
               "parameter_count": saved["parameter_count"], "vocab_size": spec["vocab_size"],
               "best_epoch": saved["best_epoch"], "epochs_completed": saved["epochs_completed"],
               "timing": saved["timing"], "gpu": saved["gpu"]}
        selected_threshold = None
        for split, result_key in (("validation", "val"), ("test", "test")):
            fids, labels, probabilities, threshold, fingerprint = read_predictions(directory / f"{split}_predictions.csv")
            require(fingerprint == spec["splits"][split]["ordered_fid_label_sha256"], f"{name}: {split} fid/label fingerprint differs")
            require(all(original_labels.get(fid) == (split, int(label)) for fid, label in zip(fids, labels)),
                    f"{name}: {split} label differs from original source")
            require(len(fids) == inputs[scope]["manifest"]["splits"][split]["samples"], f"{name}: missing {split} samples")
            if split not in references:
                references[split] = (fids, labels)
            require(fids == references[split][0] and np.array_equal(labels, references[split][1]),
                    f"{name}: {split} samples differ across arms/seeds")
            recomputed = metrics(labels, probabilities, threshold)
            for metric in (*METRICS, "f1@0.5", "mcc@0.5", "n", "positive", "val_t"):
                equal_number(recomputed[metric], saved[result_key][metric], f"{name}/{split}/{metric}")
            equal_number(saved[result_key]["pr_auc"], recomputed["ap"], f"{name}/{split}/AP alias")
            row[result_key] = recomputed
            if split == "validation":
                selected_threshold = validation_threshold(labels, probabilities)
                equal_number(threshold, selected_threshold, f"{name}: threshold not selected on validation")
                equal_number(threshold, checkpoint["val_t"], f"{name}: checkpoint threshold mismatch")
                equal_number(recomputed["ap"], checkpoint["validation_ap"], f"{name}: checkpoint AP mismatch")
            else:
                equal_number(threshold, selected_threshold, f"{name}: test threshold differs from validation")
                require(sensitivity_set <= set(fids), f"{name}: sensitivity contains unknown test IDs")
                keep = np.asarray([fid in sensitivity_set for fid in fids])
                row["sensitivity"] = metrics(labels[keep], probabilities[keep], threshold)
        records.append(row)
        provenance[name] = {filename: sha256(directory / filename) for filename in
                            ("metrics.json", "run_spec.json", "validation_predictions.csv", "test_predictions.csv", "best_checkpoint.json")}
    excluded_fids = duplicate_audit["test_excluding_exact_train_or_validation"]["excluded_fids"]
    require(len(excluded_fids) == len(set(excluded_fids)) and set(excluded_fids) <= set(references["test"][0]),
            "Invalid duplicate exclusion IDs")
    require(sensitivity_set == set(references["test"][0]) - set(excluded_fids),
            "Sensitivity list is not exactly test minus audit exclusion IDs")
    retained = records[0]["sensitivity"]
    for key, audit_key in (("n", "retained_samples"), ("positive", "retained_positive")):
        require(retained[key] == duplicate_audit["test_excluding_exact_train_or_validation"][audit_key],
                f"Sensitivity {key} differs from duplicate audit")
    exploratory = bool(incomplete) or allow_partial
    summary = {
        "status": "exploratory_partial" if incomplete else ("exploratory_complete" if allow_partial else "complete"),
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "planned_runs": 45, "completed_runs": len(records), "incomplete_runs": incomplete,
        "exploratory": exploratory, "protocol": protocol_document,
        "primary_metric": "average precision (AP)", "sd_definition": "sample SD, ddof=1 across optimization seeds",
        "primary": group_summary(records, "test"), "paired_comparisons": paired_comparisons(records),
        "sensitivity": {"definition": LIMITATIONS[2], "duplicate_audit": duplicate_audit,
                        "fid_list_sha256": sha256(sensitivity_path), "by_arm": group_summary(records, "sensitivity")},
        "vocabulary_and_oov": {scope: inputs[scope]["stats"] for scope in inputs},
        "runs": records, "environment": reference_environment, "limitations": LIMITATIONS,
        "provenance": {"protocol_sha256": sha256(protocol_path), "analysis_script_sha256": sha256(__file__),
                       "trainer_sha256": protocol["trainer_sha256"], "runs": provenance,
                       "input_manifests": protocol["input_manifests"]},
    }
    output = experiment / ("analysis_exploratory" if exploratory else "analysis")
    output.mkdir(parents=True, exist_ok=True)
    write_outputs(output, summary)
    print(f"Verified {len(records)}/45 runs; {summary['status']}; saved {output}", flush=True)
    return summary


def write_csv(path, rows):
    rows = list(rows)
    require(bool(rows), f"Cannot write empty table: {path}")
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def format_mean_sd(statistic):
    if not statistic["n"]:
        return "chưa có lượt hoàn thành"
    sd = f"{statistic['sample_sd']:.6f}" if statistic["sample_sd"] is not None else "NA"
    return f"{statistic['mean']:.6f} ± {sd} (n={statistic['n']})"


def write_outputs(output, summary):
    partial_label = summary["status"]
    rows = []
    sensitivity_rows = []
    for run in summary["runs"]:
        base = {"analysis_status": partial_label, "run": run["run"], "arm": run["arm"],
                "scope": run["scope"], "seed": run["seed"], "parameter_count": run["parameter_count"],
                "vocab_size": run["vocab_size"], "best_epoch": run["best_epoch"],
                "epochs_completed": run["epochs_completed"], **run["timing"]}
        rows.append({**base, **run["test"], "validation_ap": run["val"]["ap"]})
        sensitivity_rows.append({**base, "evaluation": "post_training_exact_duplicate_sensitivity",
                                 **run["sensitivity"]})
    paired = []
    for row in summary["paired_comparisons"]:
        paired.append({"analysis_status": partial_label,
                       **{key: row[key] for key in ("left", "right", "metric", "direction", "n", "mean", "sample_sd", "min", "max")},
                       **{f"difference_seed_{seed}": row["values_by_seed"].get(str(seed)) for seed in SEEDS},
                       "ap_exact_sign_test_two_sided_p": row.get("exact_sign_test", {}).get("two_sided_p"),
                       "ap_sign_test_nonzero_pairs": row.get("exact_sign_test", {}).get("n_nonzero")})
    write_csv(output / "per_run.csv", rows)
    write_csv(output / "paired_comparisons.csv", paired)
    write_csv(output / "sensitivity.csv", sensitivity_rows)
    lines = ["BÁO CÁO THỰC NGHIỆM BỔ SUNG SAU SEMINAR", "",
             f"Trạng thái: {summary['status']}; hoàn thành {summary['completed_runs']}/45 lượt."]
    if summary["exploratory"]:
        lines.extend(["KẾT QUẢ THĂM DÒ: không dùng thay báo cáo protocol hoàn chỉnh.",
                      "Các cấu hình/seed chưa hoàn thành được liệt kê trong summary.json."])
    lines.extend(["Chỉ sử dụng các lượt chạy theo protocol hiện tại. AP là average precision, không phải diện tích PR tính bằng quy tắc hình thang.",
                  "Ngưỡng F1/precision/recall/MCC được chọn từ validation và giữ nguyên khi đánh giá test.", "", "KẾT QUẢ TRÊN TEST GỐC"])
    for arm, *_ in ARMS:
        group = summary["primary"][arm]
        lines.append(f"{arm}: AP {format_mean_sd(group['metrics']['ap'])}; ROC-AUC {format_mean_sd(group['metrics']['roc_auc'])}; "
                     f"F1 {format_mean_sd(group['metrics']['f1@val_t'])}; MCC {format_mean_sd(group['metrics']['mcc@val_t'])}.")
        if group["seeds"]:
            lines.append(f"  Mẫu test={group['n']}, dương={group['positive']}, tỷ lệ dương={group['prevalence']:.6%}; "
                         f"tham số={group['parameter_count']['mean']:.0f}; tổng thời gian/lượt={group['total_seconds']['mean']:.2f} giây.")
    lines.extend(["", "CHÊNH LỆCH AP THEO CẶP SEED: TRAIN_FULL TRỪ CẤU HÌNH SO SÁNH"])
    for row in summary["paired_comparisons"]:
        if row["metric"] == "ap":
            lines.append(f"train_full - {row['right']}: {format_mean_sd(row)}; "
                         f"p kiểm định dấu hai phía={row['exact_sign_test']['two_sided_p']:.6f}; "
                         f"chênh lệch từng seed={row['values_by_seed']}.")
    lines.extend(["", "PHÂN TÍCH ĐỘ NHẠY SAU HUẤN LUYỆN"])
    for arm, *_ in ARMS:
        group = summary["sensitivity"]["by_arm"][arm]
        if group["seeds"]:
            lines.append(f"{arm}: giữ {group['n']} mẫu, {group['positive']} dương ({group['prevalence']:.6%}); "
                         f"AP {format_mean_sd(group['metrics']['ap'])}; F1 {format_mean_sd(group['metrics']['f1@val_t'])}; "
                         f"MCC {format_mean_sd(group['metrics']['mcc@val_t'])}.")
    lines.extend(["", "TỪ VỰNG VÀ UNK TRÊN ĐẦU VÀO THỰC DÙNG"])
    for scope, stats in summary["vocabulary_and_oov"].items():
        lines.append(f"{scope}: vocab đồ thị={stats['graph_vocab_size']}, vocab chung={stats['joint_vocab_size']}.")
        for split, details in stats["splits"].items():
            graph, sequence = details["graph_used_input"], details["sequence_used_input"]
            lines.append(f"  {split}: graph UNK theo token={graph['unk_token_rate']:.6%}, theo mẫu={graph['sample_with_unk_rate']:.6%}; "
                         f"sequence UNK theo token={sequence['unk_token_rate']:.6%}, theo mẫu={sequence['sample_with_unk_rate']:.6%}.")
    lines.extend(["", "GIỚI HẠN DIỄN GIẢI", *summary["limitations"]])
    (output / "bao_cao_thuc_nghiem.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    (output / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def self_test():
    """Exercise metric conventions and the no-partial-output boundary."""
    require(exact_sign_test([1, 1, 1, 1, 1])["two_sided_p"] == 0.0625, "Five-seed sign test regression")
    require(exact_sign_test([1, -1])["two_sided_p"] == 1.0, "Two-sided sign test regression")
    require(exact_sign_test([0, 0])["n_nonzero"] == 0, "Sign-test tie handling regression")
    require(descriptive([1, 2, 3])["sample_sd"] == 1.0, "Sample SD must use ddof=1")
    require(descriptive([1])["sample_sd"] is None, "One-seed SD must remain undefined")
    labels = np.asarray([0, 1, 0, 1], dtype=np.int64)
    probabilities = np.asarray([0.1, 0.9, 0.2, 0.8], dtype=np.float32)
    calculated = metrics(labels, probabilities, 0.5)
    require(all(calculated[key] == 1.0 for key in METRICS), "Perfect-ranking/classification metric regression")
    with tempfile.TemporaryDirectory(prefix="seminar-analysis-test-") as temporary:
        directory = Path(temporary)
        prediction_path = directory / "predictions.csv"
        write_csv(prediction_path, [
            {"fid": f"F{index}", "y": int(label), "prob": float(probability),
             "pred_0.5": int(probability > 0.5), "pred_val_t": int(probability > 0.5), "val_t": 0.5}
            for index, (label, probability) in enumerate(zip(labels, probabilities))])
        _, loaded_labels, loaded_probabilities, loaded_threshold, _ = read_predictions(prediction_path)
        require(np.array_equal(labels, loaded_labels) and np.array_equal(probabilities, loaded_probabilities)
                and loaded_threshold == 0.5, "Prediction CSV roundtrip regression")
        boundary_path = directory / "threshold_boundaries.csv"
        boundary_scores = np.asarray([0.4, 0.9], dtype=np.float32)
        boundary_threshold = 0.4
        boundary_pred_half = boundary_scores > 0.5
        boundary_pred_val = boundary_scores > boundary_threshold
        write_csv(boundary_path, [
            {"fid": f"B{index}", "y": index, "prob": float(score),
             "pred_0.5": int(boundary_pred_half[index]), "pred_val_t": int(boundary_pred_val[index]),
             "val_t": boundary_threshold} for index, score in enumerate(boundary_scores)])
        _, _, restored_scores, restored_threshold, _ = read_predictions(boundary_path)
        require(restored_scores.dtype == np.float32 and not bool((restored_scores > restored_threshold)[0]),
                "Float32 threshold comparator parity regression")
        protocol = {"specification": {"arms": [list(arm) for arm in ARMS], "seeds": SEEDS, "planned_runs": 45}}
        (directory / "protocol.json").write_text(json.dumps(protocol), encoding="utf-8")
        try:
            analyze(directory, directory, allow_partial=False)
        except RuntimeError as error:
            require("Experiment incomplete" in str(error), "Unexpected partial-run rejection")
        else:
            raise AssertionError("Incomplete experiment was not rejected")
        require(not (directory / "analysis").exists(), "Incomplete experiment wrote final analysis")
    print("Analyzer self-tests passed: metric conventions, exact sign test, prediction CSV, partial-run rejection", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--experiment", type=Path)
    parser.add_argument("--allow-partial", action="store_true")
    parser.add_argument("--self-test", action="store_true", help="Run small synthetic checks without reading experiment data")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    root = args.root.resolve()
    experiment = args.experiment.resolve() if args.experiment else root / "output" / "seminar_20261011"
    analyze(root, experiment, args.allow_partial)


if __name__ == "__main__":
    main()
