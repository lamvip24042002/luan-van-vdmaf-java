import myutils
import sys
import os.path
import json
from datetime import datetime
import random
import numpy
from keras.layers import Bidirectional, Dropout, Embedding
from keras.layers import LSTM
from tensorflow.keras.preprocessing import sequence
from tensorflow.keras.losses import BinaryCrossentropy
from sklearn.metrics import confusion_matrix, matthews_corrcoef
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score
from sklearn.utils import class_weight
from sklearn.metrics import roc_curve
from sklearn.metrics import auc
from gensim.models import Word2Vec
from keras.models import Sequential
from keras.layers import Dense
import numpy as np
import tensorflow as tf

numpy.set_printoptions(suppress=True)
numpy.set_printoptions(threshold=numpy.inf)

os.environ["CUDA_VISIBLE_DEVICES"] = "0"

# fixed seeds so the (untrained) MHA fusion is reproducible across runs
random.seed(42)
np.random.seed(42)
tf.random.set_seed(42)

# dwce
def dynamic_weighted_binary_crossentropy(y_true, y_pred):
    batch_size = tf.cast(tf.size(y_true), tf.float32)
    positive_weight = tf.reduce_sum(y_true) / batch_size
    negative_weight = 1.0 - positive_weight
    bce = BinaryCrossentropy(from_logits=False)
    loss = positive_weight * bce(y_true, y_pred) + negative_weight * bce(y_true, y_pred)
    return loss

mode = sys.argv[1] if len(sys.argv) > 1 else "sql"
# modes: sql, xsrf, xss, command_injection, open_redirect, path_disclosure, remote_code_execution
print("=== mode:", mode, "===")

progress = 0
count = 0
step = 5
fulllength = 200
mode2 = str(step) + "_" + str(fulllength)

mincount = 5
iterationen = 100
s = 300
w = "withString"

w2v = "word2vec_" + w + str(mincount) + "-" + str(iterationen) + "-" + str(s)
w2vmodel = "../model/" + mode + "/" + w2v + ".model"

if not (os.path.isfile(w2vmodel)):
    print("word2vec model is still being created...")
    sys.exit()

w2v_model = Word2Vec.load(w2vmodel)
word_vectors = w2v_model.wv

allblocks = []
with open('../dataset/plain_' + mode, 'r') as infile:
    data = json.load(infile)

now = datetime.now()
nowformat = now.strftime("%H:%M")
print("finished loading. ", nowformat)

node2vec_model = Word2Vec.load("../model/" + mode + "/node2vec_model-" + str(s) + ".model")
node_vectors = node2vec_model.wv
node_id = "if"
print(f"Embedding for node {node_id}: {node_vectors[str(node_id)]}")

common_tokens = set(word_vectors.key_to_index.keys()).intersection(set(node_vectors.key_to_index.keys()))

word_vectors_common = []
node_vectors_common = []

for token in common_tokens:
    word_vectors_common.append(word_vectors[token])
    node_vectors_common.append(node_vectors[token])

word_vectors_common_array = np.array(word_vectors_common)
node_vectors_common_array = np.array(node_vectors_common)


def scaled_dot_product_attention(q, k, v, mask):
    matmul_qk = tf.matmul(q, k, transpose_b=True)
    dk = tf.cast(tf.shape(k)[-1], tf.float32)
    scaled_attention_logits = matmul_qk / tf.math.sqrt(dk)
    if mask is not None:
        scaled_attention_logits += (mask * -1e9)
    attention_weights = tf.nn.softmax(scaled_attention_logits, axis=-1)
    output = tf.matmul(attention_weights, v)
    return output, attention_weights

class MultiHeadAttention(tf.keras.layers.Layer):
    def __init__(self, num_heads, d_model):
        super(MultiHeadAttention, self).__init__()
        self.num_heads = num_heads
        self.d_model = d_model
        assert d_model % num_heads == 0
        self.depth = d_model // num_heads
        self.wq = tf.keras.layers.Dense(d_model)
        self.wk = tf.keras.layers.Dense(d_model)
        self.wv = tf.keras.layers.Dense(d_model)
        self.dense = tf.keras.layers.Dense(d_model)

    def split_heads(self, x, batch_size):
        x = tf.reshape(x, (batch_size, -1, self.num_heads, self.depth))
        return tf.transpose(x, perm=[0, 2, 1, 3])

    def call(self, q, k, v, mask):
        batch_size = tf.shape(q)[0]
        q = self.wq(q)
        k = self.wk(k)
        v = self.wv(v)
        q = self.split_heads(q, batch_size)
        k = self.split_heads(k, batch_size)
        v = self.split_heads(v, batch_size)
        scaled_attention, attention_weights = scaled_dot_product_attention(q, k, v, mask)
        scaled_attention = tf.transpose(scaled_attention, perm=[0, 2, 1, 3])
        concat_attention = tf.reshape(scaled_attention, (batch_size, -1, self.d_model))
        output = self.dense(concat_attention)
        return output, attention_weights

multihead_attn = MultiHeadAttention(num_heads=10, d_model=300)
X, _ = multihead_attn(word_vectors_common_array, node_vectors_common_array, node_vectors_common_array, mask=None)

# 输出融合向量
merged_vector = tf.reduce_sum(X, axis=1)
# sum
# merged_vector = np.sum(np.array(word_vectors_common), axis=0) + np.sum(np.array(node_vectors_common), axis=0)
# max
# merged_vector = np.maximum(np.array(word_vectors_common), np.array(node_vectors_common))
# mean
# merged_vector = (np.array(word_vectors_common) + np.array(node_vectors_common)) / 2
# #bilstm
# combined_features = np.concatenate((word_vectors_common_array, node_vectors_common_array), axis=-1)
# combined_features = combined_features.reshape((combined_features.shape[0], combined_features.shape[1], 1))  # 形状为 (n, 600, 1)
# model = Sequential()
# model.add(Bidirectional(LSTM(150, return_sequences=False), input_shape=(combined_features.shape[1], combined_features.shape[2])))  # 输出为 (n, 300)
# model.add(Dense(300, activation='relu'))
# model.compile(loss='mean_squared_error', optimizer='adam', metrics=['accuracy'])
# model.fit(combined_features, np.random.rand(combined_features.shape[0], 300), epochs=10, batch_size=32)
# merged_vector = model.predict(combined_features)
print("Merged Vector Shape:", merged_vector.shape)

print(len(merged_vector))

# 将 TensorFlow 张量转换为 NumPy 数组 (EagerTensor has no .tolist())
merged_vector_np = np.array(merged_vector)

# dict lookup instead of list(...).index() — same order as the loop that
# built word_vectors_common/node_vectors_common above
common_tokens_index = {t: i for i, t in enumerate(common_tokens)}

# frozen embedding table: row 0 = padding (zero vector), row i+1 = fused vector
# of token i. Samples are fed as int32 index sequences so the dense
# (n_samples, 100, 300) tensor never sits in RAM.
emb_matrix = np.zeros((len(common_tokens) + 1, 300), dtype=np.float32)
emb_matrix[1:] = np.asarray(merged_vector_np, dtype=np.float32)

# 获取特定单词的向量
def get_token_vector(token, common_tokens, merged_vector_np):
    idx = common_tokens_index.get(token)
    if idx is not None:
        return merged_vector_np[idx]
    return None

if_vector = get_token_vector("if", common_tokens, merged_vector_np)
print("Vector for 'if':", if_vector)
print("Shape of the vector for 'if':", if_vector.shape if if_vector is not None else "Token not found")

for r in data:
    progress = progress + 1
    for c in data[r]:
        if "files" in data[r][c]:
            for f in data[r][c]["files"]:
                if not "source" in data[r][c]["files"][f]:
                    continue
                if "source" in data[r][c]["files"][f]:
                    sourcecode = data[r][c]["files"][f]["source"]
                    allbadparts = []
                    for change in data[r][c]["files"][f]["changes"]:
                        badparts = change["badparts"]
                        count = count + len(badparts)
                        for bad in badparts:
                            pos = myutils.findposition(bad, sourcecode)
                            if not -1 in pos:  # 表示在源代码中找到了bad代码
                                allbadparts.append(bad)
                    if (len(allbadparts) > 0):
                        positions = myutils.findpositions(allbadparts, sourcecode)
                        blocks = myutils.getblocks(sourcecode, positions, step, fulllength, mode)
                        for b in blocks:
                            allblocks.append(b)

# reuse the saved split when it exists so runs stay comparable
if os.path.isfile('key_data/keystrain_data_' + mode + '.npy'):
    keystrain = numpy.load('key_data/keystrain_data_' + mode + '.npy').tolist()
    keystest = numpy.load('key_data/keystest_data_' + mode + '.npy').tolist()
    keysfinaltest = numpy.load('key_data/keysfinaltest_data_' + mode + '.npy').tolist()
    print("loaded saved split:", len(keystrain), len(keystest), len(keysfinaltest))
else:
    keys = []
    for i in range(len(allblocks)):
        keys.append(i)
    random.shuffle(keys)
    cutoff = round(0.7 * len(keys))
    cutoff2 = round(0.85 * len(keys))
    print("cutoff " + str(cutoff))
    print("cutoff2 " + str(cutoff2))
    keystrain = keys[:cutoff]
    keystest = keys[cutoff:cutoff2]
    keysfinaltest = keys[cutoff2:]

    keystrain_data = numpy.array(keystrain)
    keystest_data = numpy.array(keystest)
    keysfinaltest_data = numpy.array(keysfinaltest)

    numpy.save('key_data/keystrain_data_' + mode + '.npy', keystrain_data)
    numpy.save('key_data/keystest_data_' + mode + '.npy', keystest_data)
    numpy.save('key_data/keysfinaltest_data_' + mode + '.npy', keysfinaltest_data)


TrainX = []
TrainY = []
ValidateX = []
ValidateY = []
FinaltestX = []
FinaltestY = []

# token -> index+1 sequence (same filter as before: token must be in BOTH vocabs)
def to_index_seq(code):
    idxs = []
    for t in myutils.getTokens(code):
        if t == " ":
            continue
        i = common_tokens_index.get(t)
        if i is not None:
            idxs.append(i + 1)
    return idxs

print("Creating training dataset... (" + mode + ")")
for k in keystrain:
    block = allblocks[k]
    TrainX.append(to_index_seq(block[0]))
    TrainY.append(block[1])

print("Creating validation dataset...")
for k in keystest:
    block = allblocks[k]
    ValidateX.append(to_index_seq(block[0]))
    ValidateY.append(block[1])

print("Creating finaltest dataset...")
for k in keysfinaltest:
    block = allblocks[k]
    FinaltestX.append(to_index_seq(block[0]))
    FinaltestY.append(block[1])

print("Train length: " + str(len(TrainX)))
print("Test length: " + str(len(ValidateX)))
print("Finaltesting length: " + str(len(FinaltestX)))
now = datetime.now()
nowformat = now.strftime("%H:%M")
print("time: ", nowformat)

# int32 index matrices — pad/truncate 'pre', identical semantics to the old
# dense pipeline (leading zeros -> zero vectors from embedding row 0)
X_train = sequence.pad_sequences(TrainX, maxlen=100)
X_test = sequence.pad_sequences(ValidateX, maxlen=100)
X_finaltest = sequence.pad_sequences(FinaltestX, maxlen=100)
y_train = numpy.asarray(TrainY).astype(numpy.float32)
y_test = numpy.asarray(ValidateY).astype(numpy.float32)
y_finaltest = numpy.asarray(FinaltestY).astype(numpy.float32)

now = datetime.now()  # current date and time
nowformat = now.strftime("%H:%M")
print("numpy array done. ", nowformat)

print(str(len(X_train)) + " samples in the training set.")
print(str(len(X_test)) + " samples in the validation set.")
print(str(len(X_finaltest)) + " samples in the final test set.")

csum = 0
for a in y_train:
    csum = csum + a
print("percentage of vulnerable samples: " + str(int((csum / len(X_train)) * 10000) / 100) + "%")

testvul = 0
for y in y_test:
    if y == 1:
        testvul = testvul + 1
print("absolute amount of vulnerable samples in test set: " + str(testvul))

max_length = fulllength

dropout = 0.2
neurons = 100
optimizer = "adam"
epochs = 100
batchsize = 256

now = datetime.now()
nowformat = now.strftime("%H:%M")
print("Starting LSTM: ", nowformat)

print("Dropout: " + str(dropout))
print("Neurons: " + str(neurons))
print("Optimizer: " + optimizer)
print("Epochs: " + str(epochs))
print("Batch Size: " + str(batchsize))
print("max length: " + str(max_length))


# 创建模型
model = Sequential()
# frozen lookup of the fused vectors — replaces the precomputed dense input
model.add(Embedding(input_dim=emb_matrix.shape[0], output_dim=300, input_length=100,
                    weights=[emb_matrix], trainable=False))
model.add(Bidirectional(LSTM(neurons, return_sequences=True)))
model.add(Dropout(dropout))
model.add((LSTM(neurons, activation='tanh', return_sequences=True)))
model.add(Dropout(dropout))
model.add((LSTM(neurons, activation='tanh', return_sequences=True)))
model.add(Dropout(dropout))
model.add((LSTM(neurons, activation='tanh')))
model.add(Dropout(dropout))
model.add(Dense(1, activation='sigmoid'))


now = datetime.now()
nowformat = now.strftime("%H:%M")
print("Compiled LSTM: ", nowformat)

# 考虑到数据的不平衡性，使用class_weights进行训练  调试加
class_weights = class_weight.compute_class_weight('balanced', classes=numpy.unique(y_train), y=y_train)
class_weights_dict = {i: weight for i, weight in enumerate(class_weights)}
print(class_weights_dict)
# MSE
model.compile(loss='mean_squared_error', optimizer=optimizer, metrics=['accuracy', myutils.precision, myutils.recall, myutils.f1])

# DWSE
# model.compile(loss=dynamic_weighted_binary_crossentropy, optimizer=optimizer, metrics=['accuracy', myutils.precision, myutils.recall, myutils.f1])

# 训练模型 — class_weight enabled: VUDENC block data is heavily imbalanced
history = model.fit(X_train, y_train, epochs=epochs, batch_size=batchsize, class_weight=class_weights_dict)

fname = "../model/" + mode + "_model.h5"
model.save(fname)

results = {}
for dataset in ["train", "test", "finaltest"]:
    print("Now predicting on " + dataset + " set (" + str(dropout) + " dropout)")

    if dataset == "train":
        yhat = model.predict(X_train, verbose=0)
        yhat_classes = (yhat > 0.5).astype(int)
        accuracy = accuracy_score(y_train, yhat_classes)
        precision = precision_score(y_train, yhat_classes)
        recall = recall_score(y_train, yhat_classes)
        F1Score = f1_score(y_train, yhat_classes)
        tn, fp, fn, tp = confusion_matrix(y_train, yhat_classes).ravel()
        FPR = fp / (fp + tn)
        FNR = fn / (fn + tp)
        MCC = matthews_corrcoef(y_train, yhat_classes)

    if dataset == "test":
        yhat = model.predict(X_test, verbose=0)
        yhat_classes = (yhat > 0.5).astype(int)
        accuracy = accuracy_score(y_test, yhat_classes)
        precision = precision_score(y_test, yhat_classes)
        recall = recall_score(y_test, yhat_classes)
        F1Score = f1_score(y_test, yhat_classes)
        tn, fp, fn, tp = confusion_matrix(y_test, yhat_classes).ravel()
        FPR = fp / (fp + tn)
        FNR = fn / (fn + tp)
        MCC = matthews_corrcoef(y_test, yhat_classes)

    if dataset == "finaltest":
        yhat = model.predict(X_finaltest, verbose=0)
        yhat_classes = (yhat > 0.5).astype(int)
        accuracy = accuracy_score(y_finaltest, yhat_classes)
        precision = precision_score(y_finaltest, yhat_classes)
        recall = recall_score(y_finaltest, yhat_classes)
        F1Score = f1_score(y_finaltest, yhat_classes)
        tn, fp, fn, tp = confusion_matrix(y_finaltest, yhat_classes).ravel()
        FPR = fp / (fp + tn)
        FNR = fn / (fn + tp)
        MCC = matthews_corrcoef(y_finaltest, yhat_classes)

    print("Accuracy: " + str(accuracy))
    print("Precision: " + str(precision))
    print("Recall: " + str(recall))
    print('F1 score: %f' % F1Score)
    print("FPR: " + str(FPR))
    print("FNR: " + str(FNR))
    print("MCC: " + str(MCC))
    print("\n")
    results[dataset] = dict(accuracy=float(accuracy), precision=float(precision),
                            recall=float(recall), f1=float(F1Score),
                            fpr=float(FPR), fnr=float(FNR), mcc=float(MCC))

y_pred_lstm = model.predict(X_finaltest).ravel()
fpr_lstm, tpr_lstm, thresholds_lstm = roc_curve(y_finaltest, y_pred_lstm)
auc_lstm = auc(fpr_lstm, tpr_lstm)
print (auc_lstm)

results["finaltest"]["auc"] = float(auc_lstm)
results["mode"] = mode
results["split_sizes"] = dict(train=len(X_train), validation=len(X_test),
                              finaltest=len(X_finaltest))
with open("baseline_metrics_bagheri_" + mode + ".json", "w") as jf:
    json.dump(results, jf, indent=2)
print("saved -> baseline_metrics_bagheri_" + mode + ".json")
