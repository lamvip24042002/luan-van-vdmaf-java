"""Run the prespecified vocabulary/architecture experiment on the local GPU."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'output' / 'seminar_20261011'
TRAINER = ROOT / 'scripts' / 'train_seminar_20261011.py'
ARMS = [
    ('all_full', 'all', 'both', 'attention', 'all'),
    ('train_full', 'train', 'both', 'attention', 'all'),
    ('train_seq', 'train', 'seq', 'attention', 'all'),
    ('train_gnn', 'train', 'gnn', 'attention', 'all'),
    ('train_concat', 'train', 'both', 'concat', 'all'),
    ('train_cdg_ddg', 'train', 'both', 'attention', 'cdg_ddg'),
    ('train_untyped', 'train', 'both', 'attention', 'untyped'),
    ('train_no_cdg', 'train', 'both', 'attention', 'no_cdg'),
    ('train_no_ddg', 'train', 'both', 'attention', 'no_ddg'),
]


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for part in iter(lambda: f.read(1024 * 1024), b''):
            h.update(part)
    return h.hexdigest()


def write_json(path, data):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    os.replace(temporary, path)


def validate_resume(old, expected, specification, scope, manifest, name):
    expected_config = dict(expected)
    expected_config.update({key: value for key, value in specification['hyperparameters'].items()
                            if key != 'weight_decay'})
    required_inputs = ['vocab_joint.json'] + [filename for split in ('train', 'validation', 'test')
                       for filename in (f'{split}.pt', f'seq_{split}.pt')]
    expected_inputs = {filename: manifest['artifacts'][filename]['sha256'] for filename in required_inputs}
    expected_optimizer = {'name': 'AdamW', 'lr': specification['hyperparameters']['lr'],
                          'weight_decay': specification['hyperparameters']['weight_decay']}
    if (old.get('status') != 'completed'
            or old.get('script_sha256') != specification['trainer_sha256']
            or any(old.get('config', {}).get(key) != value for key, value in expected_config.items())
            or old.get('optimizer') != expected_optimizer
            or old.get('input_sha256') != expected_inputs
            or old.get('data_manifests', {}).get('manifest.json', {}).get('sha256')
                != specification['input_manifests'][scope]):
        raise RuntimeError(f'Existing run provenance differs: {name}')


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--plan-only', action='store_true')
    cli.add_argument('--seeds', type=int, nargs='+', default=list(range(42, 47)))
    args = cli.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    protocol_path = OUT / 'protocol.json'
    specification = {
        'seeds': args.seeds, 'arms': ARMS,
        'trainer_sha256': sha(TRAINER),
        'input_manifests': {scope: sha(OUT / 'inputs' / scope / 'manifest.json') for scope in ('all', 'train')},
        'hyperparameters': {'dim': 128, 'epochs': 25, 'patience': 5, 'batch': 64,
                            'lr': 0.001, 'dropout': 0.3, 'weight_decay': 0.0001},
        'cpu_threads': 4,
        'primary_metric': 'average precision (AP), not trapezoidal PR area',
        'selection': 'checkpoint by validation AP; threshold by validation F1 only',
        'primary_evaluation': 'fixed original test IDs and labels, unchanged prevalence',
        'secondary_evaluation': 'same trained checkpoints, test subset excluding exact input matches in train or validation; descriptive sensitivity analysis',
        'comparison_policy': 'all planned arms reported regardless of direction; mean/sample-SD and paired seed differences; no selection on test',
        'limitations': ['single original split', 'GPU operations may not be bitwise deterministic',
                       'concat/untyped reduce parameter count; these are design ablations, not parameter-matched controls',
                       'test subset is not a new project-disjoint or chronological evaluation'],
        'planned_runs': len(ARMS) * len(args.seeds),
    }
    # JSON round trip normalizes tuples to lists for exact resume checks.
    specification = json.loads(json.dumps(specification))
    if protocol_path.exists():
        existing = json.loads(protocol_path.read_text(encoding='utf-8'))
        if existing['specification'] != specification:
            raise RuntimeError('Protocol/source/input changed; refusing to mix experimental runs')
    else:
        write_json(protocol_path, {'created_utc_before_training': now(), 'specification': specification})
    if args.plan_only:
        print(f'Protocol saved: {specification["planned_runs"]} runs', flush=True)
        return
    (OUT / 'launcher_logs').mkdir(exist_ok=True)
    completed, started = [], time.perf_counter()
    for seed in args.seeds:
        for arm, scope, channels, fusion, edges in ARMS:
            name = f'{arm}_s{seed}'
            if sha(TRAINER) != specification['trainer_sha256']:
                raise RuntimeError(f'Trainer source changed during experiment before {name}')
            manifest_path = OUT / 'inputs' / scope / 'manifest.json'
            if sha(manifest_path) != specification['input_manifests'][scope]:
                raise RuntimeError(f'Input manifest changed during experiment before {name}')
            destination = OUT / 'runs' / name
            metrics_path = destination / 'metrics.json'
            if metrics_path.exists():
                old = json.loads((destination / 'run_spec.json').read_text(encoding='utf-8'))
                expected = {'seed': seed, 'channels': channels, 'fusion': fusion, 'edges': edges,
                            'data': str((OUT / 'inputs' / scope).resolve()),
                            'out': str(destination.resolve()), 'pcf': False, 'device': 'cuda'}
                manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
                validate_resume(old, expected, specification, scope, manifest, name)
                completed.append(name)
                print('VERIFIED_SKIP', name, flush=True)
                continue
            if destination.exists() and any(destination.iterdir()):
                raise RuntimeError(f'Incomplete run requires inspection before retry: {destination}')
            command = [sys.executable, '-u', str(TRAINER), '--data', str(OUT / 'inputs' / scope),
                       '--out', str(destination), '--channels', channels, '--fusion', fusion,
                       '--edges', edges, '--seed', str(seed), '--device', 'cuda']
            env = dict(os.environ, PYTHONHASHSEED=str(seed), PYTHONIOENCODING='utf-8',
                       PYTHONUNBUFFERED='1', OMP_NUM_THREADS='4', MKL_NUM_THREADS='4')
            status = {'status': 'running', 'current': name, 'completed': completed,
                      'planned': specification['planned_runs'], 'updated_utc': now(),
                      'elapsed_seconds': time.perf_counter() - started, 'command': command}
            write_json(OUT / 'status.json', status)
            print('START', name, f'({len(completed)+1}/{specification["planned_runs"]})', now(), flush=True)
            with (OUT / 'launcher_logs' / f'{name}.log').open('w', encoding='utf-8') as log:
                child = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT,
                                       creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            if child.returncode or not metrics_path.exists():
                status.update(status='failed', exit_code=child.returncode, updated_utc=now())
                write_json(OUT / 'status.json', status)
                raise RuntimeError(f'Run failed: {name}. Inspect launcher log.')
            completed.append(name)
            metrics = json.loads(metrics_path.read_text(encoding='utf-8'))
            print('FINISH', name, 'seconds', round(metrics['timing']['total_seconds'], 1),
                  'test_AP', round(metrics['test']['ap'], 6), flush=True)
    write_json(OUT / 'status.json', {'status': 'completed', 'completed': completed,
                                   'planned': specification['planned_runs'], 'updated_utc': now(),
                                   'elapsed_seconds': time.perf_counter() - started})
    print('ALL_COMPLETED', len(completed), flush=True)


if __name__ == '__main__':
    main()
