$conda = "C:\Users\ADMIN\miniconda3\condabin\conda.bat"
Write-Output "=== creating env vdmaf-gnn  $(Get-Date -Format HH:mm:ss) ==="
& $conda create -n vdmaf-gnn -y python=3.10
Write-Output "=== installing torch cu121  $(Get-Date -Format HH:mm:ss) ==="
& $conda run -n vdmaf-gnn pip install --no-input torch --index-url https://download.pytorch.org/whl/cu121
Write-Output "=== installing pyg + tools  $(Get-Date -Format HH:mm:ss) ==="
& $conda run -n vdmaf-gnn pip install --no-input torch_geometric numpy pandas pyarrow scikit-learn gensim tqdm
Write-Output "=== verify  $(Get-Date -Format HH:mm:ss) ==="
& $conda run -n vdmaf-gnn python -c "import torch, torch_geometric; print('torch', torch.__version__, '| cuda', torch.cuda.is_available(), '| pyg', torch_geometric.__version__)"
Write-Output "=== ENV SETUP DONE  $(Get-Date -Format HH:mm:ss) ==="
