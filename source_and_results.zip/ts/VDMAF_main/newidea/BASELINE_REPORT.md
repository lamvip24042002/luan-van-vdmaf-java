# Báo cáo baseline VDMAF tái lập trên 3 tập dữ liệu

Ngày chốt: 2026-07-04. Môi trường: conda env `vdmaf` (TF 2.10.1, GPU RTX 3060 12GB).
Toàn bộ split được lưu trong `*/key_data/*.npy` để mọi thí nghiệm sau so sánh được.
Seed cố định 42 (fusion MHA không huấn luyện → cần seed để tái lập).

## 1. Kết quả (finaltest, ngưỡng 0.5)

| Tập | Ngôn ngữ | Acc | P | R | F1 | MCC | AUC | F1 bài báo | Chênh lệch F1 |
|---|---|---|---|---|---|---|---|---|---|
| Reveal (v2) | C | 88.5 | 38.4 | 27.1 | **31.8** | 0.262 | 0.763 | 56.8 | −25.0 |
| Devign | C | 54.6 | 49.8 | 53.9 | **51.8** | 0.090 | 0.584 | 65.3 | −13.5 |
| Bagheri (7 mode, TB macro) | Python | 98.1 | 93.5 | 98.3 | **95.9** | 0.947 | 0.998 | 96.5 | −0.6 |

### Bagheri/VUDENC chi tiết 7 mode (finaltest, chạy 2026-07-04, tổng ~4.5 giờ máy)

| Mode | Acc | P | R | F1 | MCC | AUC | F1 bài báo | Δ F1 |
|---|---|---|---|---|---|---|---|---|
| sql | 97.3 | 94.1 | 97.3 | **95.7** | 0.937 | 0.997 | 96.5 | −0.8 |
| xss | 97.5 | 88.1 | 98.2 | **92.9** | 0.916 | 0.997 | 90.2 | **+2.7** |
| xsrf | 97.9 | 93.1 | 98.6 | **95.8** | 0.945 | 0.998 | 98.7 | −2.9 |
| command_injection | 98.5 | 94.3 | 99.1 | **96.6** | 0.957 | 0.998 | 95.1 | **+1.5** |
| open_redirect | 97.2 | 91.2 | 97.8 | **94.4** | 0.927 | 0.996 | 98.8 | −4.4 |
| path_disclosure | 98.8 | 96.4 | 98.3 | **97.4** | 0.966 | 0.999 | 97.0 | **+0.4** |
| remote_code_execution | 99.4 | 97.6 | 98.9 | **98.2** | 0.978 | 0.999 | 98.9 | −0.7 |
| **Trung bình macro** | **98.1** | **93.5** | **98.3** | **95.9** | **0.947** | **0.998** | **96.5** | **−0.6** |

File số liệu: `Reveal/code/baseline_metrics_reveal.json`, `Devign/code/baseline_metrics_devign.json`,
`Bagheri/train_model/baseline_metrics_bagheri_<mode>.json` (7 file).

Nhận xét:
- **Bagheri tái lập được trọn vẹn** (F1 trung bình 95.9 vs 96.5, chênh −0.6; 3/7 mode vượt bài báo,
  lệch lớn nhất −4.4 ở open_redirect): với dữ liệu block-level dễ (pattern cục bộ), pipeline
  artifact đạt số bài báo dù kênh đồ thị chỉ là token co-occurrence.
- **Devign hụt 13.5 điểm F1**: train Acc 94.3 nhưng test ~54.6 (gần ngẫu nhiên với tập 46% dương)
  → mô hình chỉ ghi nhớ, không khái quát. Nhất quán với fusion không được huấn luyện.
- **Reveal hụt 25 điểm F1**, đặc biệt Recall 27.1 vs 93.1 của bài báo: với tập mất cân bằng 10%,
  kênh "cấu trúc" dạng bảng tra token không cung cấp tín hiệu đủ để kéo recall.

## 2. Khoảng cách bài báo vs mã nguồn công bố (đóng góp phân tích cho luận văn)

1. **GGNN không tồn tại trong artifact.** Bài báo mô tả GGNN 2 lớp trên CPG (Joern); code công bố
   chỉ load file gensim Word2Vec `node2vec_model-300.model` **keyed theo token mã nguồn**.
2. **Fusion multi-head attention không được huấn luyện.** Reveal: output MHA bị bỏ, dùng
   `np.maximum`. Devign/Bagheri: `reduce_sum(MHA(...))` với trọng số ngẫu nhiên = phép chiếu
   ngẫu nhiên của vector node2vec; word2vec chỉ đóng góp qua phần giao từ vựng.
3. **Nguồn VUDENC (Bagheri) không parse được**: trường `source` bị làm phẳng mất xuống dòng/thụt lề
   (657/657 file fail `ast.parse`) → không thể sinh CPG bằng Joern như bài báo mô tả cho Python.
4. Lỗi kỹ thuật trong code: corpus Reveal bị cắt bởi debug leftovers (fix → vocab 1,063 → 43,254);
   `EagerTensor.tolist()` crash; loss "DWCE" thực chất là BCE thường; MSE cho phân loại nhị phân.

## 3. Pipeline tự xây (thay phần code tác giả không công bố)

- **Devign (C):** `Devign/graph/`: xuất 27,318 hàm → Joern `c2cpg` (batch) → `dump_graph.sc`
  (node/edge theo method; token = identifier/call/literal/operator; cạnh AST/CFG/CDG/REACHING_DEF)
  → `build_node2vec.py` (gộp node theo token, walk đều 2×20, skip-gram sg=1/w=10/mc=5/300d/5ep)
  → vocab 122,404.
- **Bagheri (Python):** CPG bất khả thi (mục 2.3) → `Bagheri/graph/build_node2vec_tokens.py`:
  đồ thị kề token trên từng source (cạnh = token liên tiếp), cùng tham số walk/skip-gram
  → vocab 19,556. Cơ chế này phản ánh đúng bản chất token-keyed của model tác giả phát hành cho Reveal.

## 4. Bài học vận hành (RAM)

Pipeline gốc tiền tính vector dày đặc bằng Python list lồng nhau → Devign cần 30–40 GB RAM
(đã từng làm treo máy 32 GB). Đã viết lại toàn bộ: **chuỗi chỉ số token int32 + Embedding đóng băng**
(hàng 0 = PAD; hàng i+1 = vector fusion token i) — tương đương toán học, ~50 MB RAM, nhanh hơn
(Devign 50 epoch ≈ 4 phút). `ram_watchdog.ps1` giám sát và tự ngắt python nếu RAM trống < 3 GB.

## 5. Trạng thái & việc còn lại

- ✅ 7/7 mode VUDENC đã chạy xong (batch `run_bagheri_modes.ps1`, 11:35–14:41 ngày 2026-07-04,
  makemodel tự xuất JSON số liệu; toàn bộ pipeline nhận tham số `mode`).
- LVDA (Java/Android): bài báo có tập thứ 4 nhưng dataset + code không được công bố — đây chính là
  chỗ luận văn thay bằng pipeline Java tự xây (Joern `javasrc2cpg`). **→ Bước tiếp theo của đề tài.**
