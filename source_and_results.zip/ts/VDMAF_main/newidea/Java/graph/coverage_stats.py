# -*- coding: utf-8 -*-
# Coverage + graph statistics for the full MegaVul-Java CPG dump run.
# Streams the 21 dump files (RAM-light), joins with labels_all.tsv via the
# filename column, and reports per-split coverage + edge-type totals.
import glob
import os
import re

d = os.path.dirname(os.path.abspath(__file__))

labels = {}   # fid -> (split, label, func_name)
with open(os.path.join(d, "labels_all.tsv"), encoding="utf-8") as f:
    next(f)
    for line in f:
        p = line.rstrip("\n").split("\t")
        labels[p[0]] = (p[1], int(p[2]), p[3])

# fid -> set of method names found in that file's dump
file_methods = {}
file_has_node = set()
file_has_edge = set()
edge_counts = {}
n_methods = 0
n_nodes = 0
cur_fid = None
cur_kept = False
cur_nodes = set()
skip = {"<init>", "<clinit>"}

for path in sorted(glob.glob(os.path.join(d, "dumps_v2", "graph_batch_*.txt"))):
    with open(path, encoding="utf-8") as f:
        for line in f:
            if line.startswith("#M"):
                p = line.rstrip("\n").split("\t")
                n_methods += 1
                m = re.match(r"(F\d{6})\.java$", os.path.basename(p[2]))
                cur_fid = m.group(1) if m else None
                cur_kept = cur_fid is not None and p[1] not in skip
                cur_nodes = set()
                if cur_fid is not None:
                    file_methods.setdefault(cur_fid, set()).add(p[1])
            elif line.startswith("N"):
                n_nodes += 1
                if cur_kept:
                    node_id = line.split("\t", 2)[1]
                    cur_nodes.add(node_id)
                    file_has_node.add(cur_fid)
            elif line.startswith("E"):
                p = line.rstrip("\n").split("\t")
                t = p[3]
                edge_counts[t] = edge_counts.get(t, 0) + 1
                # Tensor builders retain an edge only when both endpoint nodes
                # were emitted as token-bearing N records in a kept method.
                if cur_kept and p[1] in cur_nodes and p[2] in cur_nodes:
                    file_has_edge.add(cur_fid)

print("dumped methods: %d | nodes: %d" % (n_methods, n_nodes))
for t, c in sorted(edge_counts.items(), key=lambda x: -x[1]):
    print("edge %-13s %d" % (t, c))

stats = {}   # split -> [total, has_any_real_method, has_named_match]
for fid, (split, label, fname) in labels.items():
    s = stats.setdefault(split, [0, 0, 0, 0, 0])
    s[0] += 1
    ms = file_methods.get(fid, set())
    # Builders keep lambdas/anonymous bodies and skip constructors only.
    real = {m for m in ms if m not in skip}
    # Match the tensor builders: a usable graph needs a retained method plus
    # at least one token node and one edge.
    if real and fid in file_has_node and fid in file_has_edge:
        s[1] += 1
        if label == 1:
            s[3] += 1
    if fname in ms:
        s[2] += 1
    if label == 1:
        s[4] += 1

print("\n%-11s %8s %14s %12s %20s" % ("split", "total", "has_graph", "name_match", "vul_with_graph/vul"))
tot = [0, 0, 0, 0, 0]
for split in ("train", "validation", "test"):
    s = stats[split]
    for i in range(5):
        tot[i] += s[i]
    print("%-11s %8d %9d (%.2f%%) %12d %14d/%d" %
          (split, s[0], s[1], 100.0 * s[1] / s[0], s[2], s[3], s[4]))
print("%-11s %8d %9d (%.2f%%) %12d %14d/%d" %
      ("ALL", tot[0], tot[1], 100.0 * tot[1] / tot[0], tot[2], tot[3], tot[4]))
